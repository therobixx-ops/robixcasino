# Deploying ROBIX KING CS to EdgeOne

## What changed in this build

- **Fixed the EdgeOne build itself.** The app was shipped with `output: 'export'`
  in `next.config.js` (required for EdgeOne Pages) but the room page lived at
  the dynamic route `app/room/[id]/page.tsx` with no `generateStaticParams`.
  Static export requires every dynamic segment to be known at build time, so
  `npm run build` failed outright. The room code was never actually read from
  that `[id]` segment anyway (it's tracked in React state), so the route is
  now the static page `app/room/page.tsx`, and the app links to it as
  `/room?code=XXXXXX` instead of `/room/XXXXXX`. This is the fix that makes
  the project buildable/deployable on EdgeOne at all.
- **Fixed `edgeone.json` / `next.config.js` output-directory mismatch.**
  `next.config.js` set `distDir: 'dist'` while `edgeone.json` pointed at
  `.next` — neither matched where a static export actually lands. Removed
  the custom `distDir` and pointed `edgeone.json` at `out`, which is where
  `next build` writes the exported site by default.
- **Solo Mode** (new): a "Play Solo" option on the lobby now runs a full game
  (Neon Roulette or Vault Heist) entirely in the browser, with 1-12 total
  players — any empty seats are filled by simple AI bots. It needs **no**
  Socket.IO server at all, so it works the instant you deploy this zip to
  EdgeOne Pages, even before you set up the realtime backend below.
- **Fixed the infinite "Loading…" freeze**: Create/Join Room now time out
  after 8 seconds with a clear error message instead of spinning forever.
  That freeze was happening because the frontend was deployed without a
  reachable Socket.IO server (see below) — the create-room request had
  nowhere to go and no timeout, so the button just spun forever.
- **Fixed a bug that silently blocked starting a game with fewer than 2
  players** even on the real multiplayer path.
- Max players range is unchanged (2-12 for real rooms); Solo Mode adds a
  separate 1-12 range since it doesn't need other humans.

## Two ways to run this

1. **Solo Mode only** — just deploy the frontend (step 2 below). No backend
   needed. Good enough if you mainly want "play alone" to work.
2. **Real multiplayer with friends** — you also need the Socket.IO server
   running somewhere with a public URL (step 1 below). Skipping this step is
   what causes "Create Room" / "Join Room" to fail — Solo Mode will still
   work fine either way.

ROBIX KING CS has two pieces that must be deployed separately:

1. **Frontend (Next.js 14)** → EdgeOne Pages
2. **Realtime backend (Socket.IO server)** → any Node.js host (Railway, Render, Fly.io,. Fly Machines, a VPS, etc.) — only needed for real multiplayer, not for Solo Mode

EdgeOne Pages runs the Next.js frontend at the edge. It **cannot** host the
Socket.IO server, because WebSocket game rooms need a long-lived Node process
with shared in-memory state.

---

## 1. Deploy the Socket.IO server (do this first)

You need a public HTTPS URL for the Socket.IO server before the frontend can
talk to it.

```bash
# Locally, verify it builds & runs
npm install
npm run server        # listens on :3001
```

Deploy `server/index.ts` (entry point) to any Node host. Minimum config:

- Node 20+
- Start command: `npm run server`
- Expose port `3001` (or map the host's `$PORT` — the server reads it)
- Environment variables:
  ```
  ADMIN_USERNAME=<your admin login>
  ADMIN_PASSWORD=<your admin password>
  ADMIN_SESSION_SECRET=<openssl rand -hex 32>
  CORS_ORIGIN=https://<your-edgeone-domain>
  ```

After deploy, note the public URL, e.g. `https://robixkingcs-realtime.up.railway.app`.

Test it:
```
curl https://robixkingcs-realtime.up.railway.app/socket.io/?EIO=4&transport=polling
```
You should get a Socket.IO handshake response.

---

## 2. Deploy the frontend to EdgeOne Pages

1. Push this repo to GitHub / GitLab.
2. In EdgeOne Console → **Pages** → **New Project** → import the repo.
3. EdgeOne auto-detects Next.js from `edgeone.json`. Confirm:
   - Framework: **Next.js**
   - Build command: `npm run build`
   - Output directory: `out`
   - Node version: `20`
4. Add environment variable:
   ```
   NEXT_PUBLIC_SOCKET_URL=https://robixkingcs-realtime.up.railway.app
   ```
   (the public URL of the Socket.IO server from step 1)
5. Click **Deploy**.

Once the build finishes you'll get a URL like
`https://robixkingcs.edgeone.app`. Open it, create a room, share the link, play.

---

## 3. Custom domain (optional)

In EdgeOne Pages → Project → **Domains** → add `robixkingcs.app` and follow
the DNS instructions. Update `CORS_ORIGIN` on the Socket.IO server to
match the new domain.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| "Create Room" / "Join Room" button spins then shows an error after ~8s | Expected if the Socket.IO server isn't deployed/reachable yet — use **Play Solo** instead, or complete step 1. |
| Frontend loads but "Connecting…" never resolves | `NEXT_PUBLIC_SOCKET_URL` is wrong or the Socket.IO server is down. |
| CORS error in the browser console | Set `CORS_ORIGIN` on the Socket.IO server to the exact EdgeOne domain (including `https://`). |
| Admin login fails | `ADMIN_USERNAME` / `ADMIN_PASSWORD` / `ADMIN_SESSION_SECRET` not set on the Socket.IO server. |
| WebSocket disconnects on mobile | Ensure the Socket.IO host supports WebSocket upgrades (Railway/Render/Fly do by default). |
