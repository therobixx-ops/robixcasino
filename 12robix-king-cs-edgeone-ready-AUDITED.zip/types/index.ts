export interface Player {
  id: string;
  name: string;
  avatar: string;
  chips: number;
  isReady: boolean;
  isHost: boolean;
  ping: number;
  winStreak: number;
  isSpectator?: boolean;
  title?: string;
  coinsWon?: number;
  coinsLost?: number;
  totalBets?: number;
  totalWins?: number;
  totalLosses?: number;
}

export interface Room {
  id: string;
  code: string;
  name: string;
  hostId: string;
  players: Player[];
  maxPlayers: number;
  isLocked: boolean;
  password?: string;
  currentGame: GameType | null;
  gameState: GameState | null;
  chat: ChatMessage[];
  settings: RoomSettings;
  createdAt: number;
}

export interface RoomSettings {
  maxPlayers: number;
  roundTimer: number;
  enableEffects: boolean;
  theme: string;
}

export type GameType = "neon-roulette" | "vault-heist" | "coin-flip" | "dice";

export interface GameState {
  status: "waiting" | "countdown" | "playing" | "ended";
  countdown: number;
  round: number;
  results?: any;
  history: any[];
}

export interface ChatMessage {
  id: string;
  playerId: string;
  playerName: string;
  text: string;
  type: "text" | "emoji" | "reaction" | "system";
  timestamp: number;
}

export interface RouletteState extends GameState {
  wheelRotation: number;
  ballPosition: number;
  winningNumber: number | null;
  bets: Record<string, Bet[]>;
  phase: "betting" | "spinning" | "result";
  adPayload?: AdPayload | null;
}

export interface Bet {
  playerId: string;
  amount: number;
  type: string;
  value: string | number;
}

export interface VaultHeistState extends GameState {
  phase: "choosing" | "locked" | "event" | "revealing" | "result";
  vaults: Vault[];
  playerChoices: Record<string, string>;
  aiEvent: AIEvent | null;
  rewards: Record<string, number>;
  adPayload?: AdPayload | null;
}

export interface Vault {
  id: string;
  name: string;
  emoji: string;
  baseReward: number;
  risk: number;
  isGolden: boolean;
  isGhost: boolean;
}

export interface AIEvent {
  id: string;
  name: string;
  description: string;
  effect: string;
  multiplier: number;
}

export interface CoinFlipState extends GameState {
  phase: "betting" | "flipping" | "result";
  bets: Record<string, Bet[]>;
  coinResult: "heads" | "tails" | null;
  adPayload?: AdPayload | null;
}

export interface DiceState extends GameState {
  phase: "betting" | "rolling" | "result";
  bets: Record<string, Bet[]>;
  dice: [number, number] | null;
  total: number | null;
  adPayload?: AdPayload | null;
}

export type QuickReaction = "😂" | "😭" | "🔥" | "💀" | "👀" | "💰" | "GG" | "Lucky!" | "No way!" | "Again!";

export interface Wallet {
  playerId: string;
  balance: number;
  coinsWon: number;
  coinsLost: number;
  totalBets: number;
  totalWins: number;
  totalLosses: number;
  dailyBonusClaimedAt: number | null;
  frozen: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface Transaction {
  id: string;
  playerId: string;
  game: GameType | "admin" | "daily_bonus" | "referral" | "purchase";
  amount: number;
  balanceBefore: number;
  balanceAfter: number;
  reason: string;
  metadata?: Record<string, any>;
  timestamp: number;
  txHash: string;
}

export interface EconomySnapshot {
  totalCoinsInCirculation: number;
  coinsCreated: number;
  coinsBurned: number;
  coinsWon: number;
  coinsLost: number;
  averageBalance: number;
  topPlayers: Array<{ playerId: string; name: string; balance: number }>;
  richestPlayers: Array<{ playerId: string; name: string; balance: number }>;
  dailyVolume: number;
  weeklyVolume: number;
  monthlyVolume: number;
  timestamp: number;
}

export type AdType = "video" | "overlay" | "popup" | "banner" | "interstitial" | "fullscreen";
export type AdFormat = "mp4" | "webm" | "gif" | "png" | "jpeg" | "svg" | "lottie" | "html";
export type AdAnimation = "fade" | "slide" | "scale" | "zoom";
export type AdStatus = "active" | "paused" | "scheduled" | "expired";

export type AdPlacement =
  | "coin-flip"
  | "dice"
  | "neon-roulette"
  | "vault-heist"
  | "lobby"
  | "loading"
  | "joining-room"
  | "match-finished"
  | "idle-screen"
  | "homepage"
  | "sidebar"
  | "popup"
  | "floating-card"
  | "footer"
  | "header"
  | "overlay";

export interface AdCampaign {
  id: string;
  title: string;
  description: string;
  campaignName: string;
  priority: number;
  weight: number;
  status: AdStatus;
  schedule: {
    startDate: number;
    endDate: number;
    timezone: string;
    frequency: "always" | "morning" | "afternoon" | "evening" | "weekend" | "custom";
    recurringDays?: number[];
  };
  targeting: {
    devices?: string[];
    countries?: string[];
    languages?: string[];
    screenSizes?: string[];
    returningUsers?: boolean;
    newUsers?: boolean;
    vipUsers?: boolean;
    roomTypes?: GameType[];
    browsers?: string[];
    os?: string[];
  };
  creative: {
    type: AdType;
    format: AdFormat;
    sourceUrl: string;
    ctaText?: string;
    destinationUrl?: string;
    animation: AdAnimation;
    volume?: number;
    loop: boolean;
    skipTimer: number;
    mandatory: boolean;
  };
  stats: {
    views: number;
    uniqueViews: number;
    clicks: number;
    ctr: number;
    completionRate: number;
    skipRate: number;
    revenue: number;
    avgWatchTime: number;
  };
  createdAt: number;
  updatedAt: number;
}

export interface AdPayload {
  campaignId: string;
  title: string;
  sourceUrl: string;
  type: AdType;
  format: AdFormat;
  animation: AdAnimation;
  skipTimer: number;
  mandatory: boolean;
  ctaText?: string;
  destinationUrl?: string;
  duration: number;
}

export interface AdAnalytics {
  campaignId: string;
  views: number;
  uniqueViews: number;
  clicks: number;
  ctr: number;
  completionRate: number;
  skipRate: number;
  revenue: number;
  avgWatchTime: number;
  devices: Record<string, number>;
  countries: Record<string, number>;
  browsers: Record<string, number>;
  heatmap?: Array<{ x: number; y: number; intensity: number }>;
  liveVisitors: number;
}

export interface ServerToClientEvents {
  "room:update": (room: Room) => void;
  "game:state": (state: GameState) => void;
  "chat:message": (message: ChatMessage) => void;
  "player:joined": (player: Player) => void;
  "player:left": (playerId: string) => void;
  "player:ready": (playerId: string, ready: boolean) => void;
  "countdown": (seconds: number) => void;
  "error": (message: string) => void;
  "bet:rejected": (message: string) => void;
  "ai:announcement": (text: string, type: string) => void;
  "effect:trigger": (effect: string, targetId?: string) => void;
  "typing:start": (playerId: string, playerName: string) => void;
  "typing:stop": (playerId: string) => void;
  "friend:invite": (invite: PartyInvite) => void;
  "tournament:update": (tournament: Tournament) => void;
  "session:rounds": (rounds: RoundRecord[]) => void;
  "session:summary": (summary: SessionSummary) => void;
  "wallet:update": (wallet: Wallet) => void;
  "wallet:tx": (tx: Transaction) => void;
  "economy:snapshot": (snapshot: EconomySnapshot) => void;
  "ad:show": (payload: AdPayload) => void;
  "ad:dismiss": () => void;
}

export interface ClientToServerEvents {
  "room:create": (data: { name: string; maxPlayers: number; password?: string }, callback: (room: Room) => void) => void;
  "room:join": (data: { code: string; name: string; avatar: string }, callback: (room: Room | null) => void) => void;
  "room:leave": () => void;
  "player:ready": (ready: boolean) => void;
  "chat:send": (text: string, type?: ChatMessage["type"]) => void;
  "typing:start": () => void;
  "typing:stop": () => void;
  "game:start": (gameType?: GameType) => void;
  "game:stop": () => void;
  "game:bet": (bet: Omit<Bet, "playerId">, txId?: string) => void;
  "game:choose": (choice: string) => void;
  "admin:kick": (playerId: string) => void;
  "admin:ban": (playerId: string) => void;
  "admin:mute": (playerId: string) => void;
  "admin:settings": (settings: Partial<RoomSettings>) => void;
  "admin:chips": (playerId: string, amount: number) => void;
  "admin:broadcast": (message: string) => void;
  "admin:timer": (seconds: number) => void;
  "prank:trigger": (effect: string, targetId?: string) => void;
  "friend:invite": (friendId: string, roomCode: string) => void;
  "friend:accept": (inviteId: string) => void;
  "tournament:join": (tournamentId: string) => void;
  "player:spectate": (spectating: boolean) => void;
  "session:end": () => void;
  "wallet:claimDaily": (callback: (result: { success: boolean; amount?: number; error?: string }) => void) => void;
  "ad:complete": (campaignId: string, watchedMs: number, skipped: boolean, clicked: boolean) => void;
}

export interface Friend {
  id: string;
  name: string;
  avatar: string;
  status: "online" | "in_game" | "offline";
  currentRoom?: string;
  lastSeen: number;
}

export interface PartyInvite {
  id: string;
  fromId: string;
  fromName: string;
  roomCode: string;
  roomName: string;
  timestamp: number;
  expiresAt: number;
}

export interface TypingIndicator {
  playerId: string;
  playerName: string;
  timestamp: number;
}

export interface AdminAction {
  id: string;
  type: "kick" | "ban" | "mute" | "gift" | "remove" | "announce" | "theme" | "timer" | "start" | "end";
  targetId?: string;
  targetName?: string;
  value?: number | string;
  performedBy: string;
  performedByName: string;
  timestamp: number;
}

export interface Tournament {
  id: string;
  name: string;
  status: "waiting" | "active" | "ended";
  rounds: TournamentRound[];
  players: TournamentPlayer[];
  maxRounds: number;
  currentRound: number;
  createdAt: number;
}

export interface TournamentRound {
  round: number;
  matches: TournamentMatch[];
  status: "waiting" | "active" | "completed";
}

export interface TournamentMatch {
  id: string;
  player1Id: string;
  player2Id?: string;
  winnerId?: string;
  status: "waiting" | "active" | "completed";
  gameType: GameType;
}

export interface TournamentPlayer {
  id: string;
  name: string;
  avatar: string;
  wins: number;
  losses: number;
  chips: number;
  eliminated: boolean;
}

export interface ActivityLogEntry {
  id: string;
  type: "join" | "leave" | "game_start" | "game_end" | "bet" | "win" | "prank" | "admin" | "chat";
  playerId: string;
  playerName: string;
  details: string;
  timestamp: number;
  roomId: string;
}

export interface RoundRecord {
  id: string;
  round: number;
  gameType: GameType;
  timestamp: number;
  result: {
    winningNumber?: number;
    isRed?: boolean;
    vaultName?: string;
    vaultEmoji?: string;
    aiEventName?: string;
    coinResult?: "heads" | "tails";
    diceValues?: [number, number];
    diceTotal?: number;
  };
  payouts: Record<string, number>;
  winnerId?: string;
  winnerName?: string;
  winnerAmount?: number;
  roomEvent?: string;
}

export interface SessionSummary {
  totalRounds: number;
  mvpId: string | null;
  mvpName: string | null;
  mvpChipsWon: number;
  biggestWinPlayerId: string | null;
  biggestWinPlayerName: string | null;
  biggestWinAmount: number;
  longestStreakName: string | null;
  longestStreak: number;
  comebackPlayerName: string | null;
  narrative: string[];
  finalStandings: Array<{ id: string; name: string; chips: number }>;
}

export type AIRoomEventType =
  | "gold_rain"
  | "confetti_burst"
  | "laser_show"
  | "lightning_storm"
  | "floating_coins"
  | "emoji_storm"
  | "fireworks"
  | "holographic";

export interface RoomStats {
  totalGames: number;
  totalBets: number;
  totalChipsExchanged: number;
  mostActivePlayer: string;
  longestStreak: number;
  favoriteGame: GameType;
  avgSessionTime: number;
}

export interface AdminPlayerView {
  playerId: string;
  name: string;
  avatar: string;
  balance: number;
  coinsWon: number;
  coinsLost: number;
  totalBets: number;
  totalWins: number;
  totalLosses: number;
  frozen: boolean;
  roomId?: string;
  roomCode?: string;
  lastActive: number;
  transactions: Transaction[];
}

export interface AdminDashboardStats {
  totalPlayers: number;
  activeRooms: number;
  totalAds: number;
  runningAds: number;
  totalCoins: number;
  coinsCreated: number;
  coinsBurned: number;
  dailyVolume: number;
  liveVisitors: number;
}
