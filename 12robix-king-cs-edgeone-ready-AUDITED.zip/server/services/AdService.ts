import { AdCampaign, AdPayload, AdStatus } from "../../types";

export class AdService {
  private campaigns = new Map<string, AdCampaign>();
  private viewLog = new Map<string, Set<string>>();
  private watchLog = new Map<string, number>();
  private clickLog = new Map<string, number>();
  private skipLog = new Map<string, number>();

  constructor() {
    this.createCampaign({
      id: "default-welcome",
      title: "Welcome to Robix",
      description: "Premium gaming experience",
      campaignName: "Default",
      priority: 5,
      weight: 100,
      status: "active",
      schedule: { startDate: 0, endDate: Date.now() + 365 * 24 * 60 * 60 * 1000, timezone: "UTC", frequency: "always" },
      targeting: {},
      creative: {
        type: "overlay",
        format: "png",
        sourceUrl: "https://via.placeholder.com/640x360/1a1a1a/d4af37?text=ROBIX+PREMIUM",
        animation: "fade",
        skipTimer: 3,
        mandatory: false,
        loop: false,
      },
      stats: { views: 0, uniqueViews: 0, clicks: 0, ctr: 0, completionRate: 0, skipRate: 0, revenue: 0, avgWatchTime: 0 },
      createdAt: Date.now(),
      updatedAt: Date.now(),
    });
  }

  createCampaign(campaign: AdCampaign): AdCampaign {
    this.campaigns.set(campaign.id, campaign);
    return campaign;
  }

  updateCampaign(id: string, updates: Partial<AdCampaign>): AdCampaign | undefined {
    const camp = this.campaigns.get(id);
    if (!camp) return undefined;
    const updated = { ...camp, ...updates, updatedAt: Date.now() };
    this.campaigns.set(id, updated);
    return updated;
  }

  deleteCampaign(id: string): boolean {
    return this.campaigns.delete(id);
  }

  getCampaign(id: string): AdCampaign | undefined {
    return this.campaigns.get(id);
  }

  getAllCampaigns(): AdCampaign[] {
    return Array.from(this.campaigns.values());
  }

  getActiveCampaigns(): AdCampaign[] {
    const now = Date.now();
    return this.getAllCampaigns().filter(c => {
      if (c.status !== "active") return false;
      if (now < c.schedule.startDate || now > c.schedule.endDate) return false;
      return this.checkFrequency(c);
    });
  }

  private checkFrequency(campaign: AdCampaign): boolean {
    const { frequency, recurringDays } = campaign.schedule;
    if (frequency === "always") return true;
    const now = new Date();
    const hour = now.getHours();
    if (frequency === "morning") return hour >= 6 && hour < 12;
    if (frequency === "afternoon") return hour >= 12 && hour < 18;
    if (frequency === "evening") return hour >= 18 || hour < 6;
    if (frequency === "weekend") return now.getDay() === 0 || now.getDay() === 6;
    if (frequency === "custom" && recurringDays) return recurringDays.includes(now.getDay());
    return true;
  }

  selectAd(placement: string, context?: { playerId?: string; device?: string; country?: string; isNewUser?: boolean }): AdPayload | null {
    const eligible = this.getActiveCampaigns();
    if (eligible.length === 0) return null;

    const totalWeight = eligible.reduce((sum, c) => sum + c.weight, 0);
    let random = Math.random() * totalWeight;
    const selected = eligible.find(c => { random -= c.weight; return random <= 0; }) || eligible[0];

    selected.stats.views++;
    if (context?.playerId) {
      const set = this.viewLog.get(selected.id) || new Set();
      if (!set.has(context.playerId)) {
        set.add(context.playerId);
        selected.stats.uniqueViews++;
      }
      this.viewLog.set(selected.id, set);
    }
    selected.stats.ctr = selected.stats.clicks / Math.max(selected.stats.views, 1);

    return {
      campaignId: selected.id,
      title: selected.title,
      sourceUrl: selected.creative.sourceUrl,
      type: selected.creative.type,
      format: selected.creative.format,
      animation: selected.creative.animation,
      skipTimer: selected.creative.skipTimer,
      mandatory: selected.creative.mandatory,
      ctaText: selected.creative.ctaText,
      destinationUrl: selected.creative.destinationUrl,
      duration: 5000,
    };
  }

  recordComplete(campaignId: string, watchedMs: number, skipped: boolean, clicked: boolean): void {
    const camp = this.campaigns.get(campaignId);
    if (!camp) return;

    const current = this.watchLog.get(campaignId) || 0;
    this.watchLog.set(campaignId, current + watchedMs);
    camp.stats.avgWatchTime = (this.watchLog.get(campaignId) || 0) / camp.stats.views;

    if (skipped) {
      const skips = this.skipLog.get(campaignId) || 0;
      this.skipLog.set(campaignId, skips + 1);
      camp.stats.skipRate = (skips + 1) / camp.stats.views;
      camp.stats.completionRate = 1 - camp.stats.skipRate;
    } else {
      camp.stats.completionRate = 1 - (camp.stats.skipRate || 0);
    }

    if (clicked) {
      const clicks = this.clickLog.get(campaignId) || 0;
      this.clickLog.set(campaignId, clicks + 1);
      camp.stats.clicks = clicks + 1;
      camp.stats.ctr = camp.stats.clicks / Math.max(camp.stats.views, 1);
    }
  }

  getAnalytics(campaignId: string) {
    const camp = this.campaigns.get(campaignId);
    if (!camp) return null;
    return {
      campaignId,
      ...camp.stats,
      devices: {},
      countries: {},
      browsers: {},
      liveVisitors: 0,
    };
  }
}

export const adService = new AdService();
