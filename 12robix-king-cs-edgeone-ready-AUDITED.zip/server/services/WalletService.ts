import { Wallet, Transaction, GameType } from "../../types";
import { securityService } from "./SecurityService";

export class WalletService {
  private wallets = new Map<string, Wallet>();
  private transactions = new Map<string, Transaction[]>();
  private globalStats = {
    coinsCreated: 0,
    coinsBurned: 0,
    coinsWon: 0,
    coinsLost: 0,
    totalVolume: 0,
  };

  getOrCreate(playerId: string, name: string = "Guest"): Wallet {
    if (!this.wallets.has(playerId)) {
      const startingBalance = name === "Host" ? 25000 : 10000;
      this.wallets.set(playerId, {
        playerId,
        balance: startingBalance,
        coinsWon: 0,
        coinsLost: 0,
        totalBets: 0,
        totalWins: 0,
        totalLosses: 0,
        dailyBonusClaimedAt: null,
        frozen: false,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      });
      this.globalStats.coinsCreated += startingBalance;
    }
    return this.wallets.get(playerId)!;
  }

  get(playerId: string): Wallet | undefined {
    return this.wallets.get(playerId);
  }

  getAll(): Wallet[] {
    return Array.from(this.wallets.values());
  }

  async transact(
    playerId: string,
    amount: number,
    game: GameType | "admin" | "daily_bonus" | "referral" | "purchase",
    reason: string,
    metadata?: Record<string, any>
  ): Promise<{ success: boolean; wallet?: Wallet; tx?: Transaction; error?: string }> {
    return securityService.withLock(playerId, async () => {
      const wallet = this.wallets.get(playerId);
      if (!wallet) return { success: false, error: "Wallet not found" };
      if (wallet.frozen) return { success: false, error: "Wallet is frozen" };

      const balanceBefore = wallet.balance;
      const balanceAfter = balanceBefore + amount;

      if (balanceAfter < 0) {
        return { success: false, error: "Insufficient balance" };
      }

      const txHash = securityService.generateTxHash(playerId, Date.now());
      if (securityService.isDuplicate(txHash)) {
        return { success: false, error: "Duplicate transaction" };
      }

      wallet.balance = balanceAfter;
      wallet.updatedAt = Date.now();

      if (amount > 0) {
        wallet.coinsWon += amount;
        wallet.totalWins += 1;
        this.globalStats.coinsWon += amount;
      } else if (amount < 0) {
        wallet.coinsLost += Math.abs(amount);
        wallet.totalLosses += 1;
        this.globalStats.coinsLost += Math.abs(amount);
      }

      if (game !== "admin" && game !== "daily_bonus") {
        wallet.totalBets += 1;
      }

      this.globalStats.totalVolume += Math.abs(amount);

      const tx: Transaction = {
        id: crypto.randomUUID(),
        playerId,
        game,
        amount,
        balanceBefore,
        balanceAfter,
        reason,
        metadata,
        timestamp: Date.now(),
        txHash,
      };

      const txs = this.transactions.get(playerId) || [];
      txs.unshift(tx);
      if (txs.length > 500) txs.pop();
      this.transactions.set(playerId, txs);

      return { success: true, wallet: { ...wallet }, tx };
    });
  }

  async placeBet(playerId: string, amount: number, game: GameType, round: number): Promise<{ success: boolean; wallet?: Wallet; tx?: Transaction; error?: string }> {
    if (amount <= 0) return { success: false, error: "Invalid bet amount" };
    return this.transact(playerId, -amount, game, `Bet placed for round ${round}`, { round, action: "bet" });
  }

  async reward(playerId: string, amount: number, game: GameType, round: number, resultDetails: any): Promise<{ success: boolean; wallet?: Wallet; tx?: Transaction; error?: string }> {
    if (amount <= 0) return { success: false, error: "Invalid reward amount" };
    return this.transact(playerId, amount, game, `Won round ${round}`, { round, ...resultDetails, action: "win" });
  }

  async adminAdjust(playerId: string, amount: number, adminId: string): Promise<{ success: boolean; wallet?: Wallet; tx?: Transaction; error?: string }> {
    return this.transact(playerId, amount, "admin", `Admin adjustment by ${adminId}`, { adminId });
  }

  claimDailyBonus(playerId: string): { success: boolean; amount?: number; error?: string } {
    const wallet = this.wallets.get(playerId);
    if (!wallet) return { success: false, error: "Wallet not found" };
    if (wallet.frozen) return { success: false, error: "Wallet frozen" };

    const now = Date.now();
    const oneDay = 24 * 60 * 60 * 1000;
    if (wallet.dailyBonusClaimedAt && now - wallet.dailyBonusClaimedAt < oneDay) {
      return { success: false, error: "Daily bonus already claimed" };
    }

    const bonus = 1000;
    wallet.balance += bonus;
    wallet.dailyBonusClaimedAt = now;
    wallet.updatedAt = now;
    this.globalStats.coinsCreated += bonus;

    const tx: Transaction = {
      id: crypto.randomUUID(),
      playerId,
      game: "daily_bonus",
      amount: bonus,
      balanceBefore: wallet.balance - bonus,
      balanceAfter: wallet.balance,
      reason: "Daily login bonus",
      timestamp: now,
      txHash: securityService.generateTxHash(playerId, now),
    };

    const txs = this.transactions.get(playerId) || [];
    txs.unshift(tx);
    this.transactions.set(playerId, txs);

    return { success: true, amount: bonus };
  }

  freeze(playerId: string, frozen: boolean): void {
    const wallet = this.wallets.get(playerId);
    if (wallet) wallet.frozen = frozen;
  }

  reset(playerId: string): void {
    this.wallets.delete(playerId);
    this.transactions.delete(playerId);
  }

  getTransactions(playerId: string): Transaction[] {
    return this.transactions.get(playerId) || [];
  }

  getGlobalStats() {
    return { ...this.globalStats };
  }

  getEconomySnapshot() {
    const wallets = this.getAll();
    const totalCoins = wallets.reduce((sum, w) => sum + w.balance, 0);
    const avgBalance = wallets.length > 0 ? Math.floor(totalCoins / wallets.length) : 0;
    const sorted = [...wallets].sort((a, b) => b.balance - a.balance);
    const topPlayers = sorted.slice(0, 10).map(w => ({
      playerId: w.playerId,
      name: w.playerId,
      balance: w.balance,
    }));

    return {
      totalCoinsInCirculation: totalCoins,
      coinsCreated: this.globalStats.coinsCreated,
      coinsBurned: this.globalStats.coinsBurned,
      coinsWon: this.globalStats.coinsWon,
      coinsLost: this.globalStats.coinsLost,
      averageBalance: avgBalance,
      topPlayers,
      richestPlayers: topPlayers,
      dailyVolume: this.globalStats.totalVolume,
      weeklyVolume: this.globalStats.totalVolume,
      monthlyVolume: this.globalStats.totalVolume,
      timestamp: Date.now(),
    };
  }
}

export const walletService = new WalletService();
