export class SecurityService {
  private locks = new Map<string, Promise<void>>();
  private processedTxs = new Set<string>();
  private rateLimits = new Map<string, { count: number; resetAt: number }>();

  async withLock<T>(playerId: string, fn: () => Promise<T>): Promise<T> {
    const acquire = async () => {
      while (this.locks.has(playerId)) {
        await this.locks.get(playerId);
      }
    };
    await acquire();

    let resolveLock: () => void;
    const lockPromise = new Promise<void>((res) => { resolveLock = res; });
    this.locks.set(playerId, lockPromise);

    try {
      return await fn();
    } finally {
      this.locks.delete(playerId);
      resolveLock!();
    }
  }

  isDuplicate(txHash: string): boolean {
    if (this.processedTxs.has(txHash)) return true;
    this.processedTxs.add(txHash);
    if (this.processedTxs.size > 50000) {
      const first = this.processedTxs.values().next().value;
      if (first) this.processedTxs.delete(first);
    }
    return false;
  }

  checkRateLimit(key: string, maxRequests: number, windowMs: number): boolean {
    const now = Date.now();
    const entry = this.rateLimits.get(key);
    if (!entry || now > entry.resetAt) {
      this.rateLimits.set(key, { count: 1, resetAt: now + windowMs });
      return true;
    }
    if (entry.count >= maxRequests) return false;
    entry.count++;
    return true;
  }

  generateTxHash(playerId: string, timestamp: number, nonce: number = Math.random()): string {
    const data = `${playerId}:${timestamp}:${nonce}:${Math.random().toString(36).slice(2)}`;
    let hash = 0;
    for (let i = 0; i < data.length; i++) {
      const char = data.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash |= 0;
    }
    return `tx_${Math.abs(hash).toString(16)}_${timestamp}`;
  }
}

export const securityService = new SecurityService();
