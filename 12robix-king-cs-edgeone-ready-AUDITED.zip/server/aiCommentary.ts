import { Player, Room, AIRoomEventType, RoundRecord, SessionSummary } from "../types";

const ROOM_EVENT_LINES: Record<AIRoomEventType, string[]> = {
  gold_rain: [
    "Gold Rain incoming! The whole room is about to shine.",
    "Make it rain — literally. Gold Rain activated!",
  ],
  confetti_burst: [
    "Confetti Burst! This round deserved it.",
    "The room just exploded in confetti. Well earned.",
  ],
  laser_show: [
    "Laser Show mode: ON. Let's give the streak the show it deserves.",
    "Lights up! Laser Show activated for that run.",
  ],
  lightning_storm: [
    "Lightning Storm rolling through the lounge. Feel that?",
    "The sky just cracked open. Lightning Storm live.",
  ],
  floating_coins: [
    "Floating Coins everywhere. Reach out and grab one.",
    "The room's filling up with floating coins. Vibes.",
  ],
  emoji_storm: [
    "Emoji Storm! Everyone's feelings, all at once.",
    "The chat just became a weather event. Emoji Storm.",
  ],
  fireworks: [
    "Fireworks over the vault. That's a celebration.",
    "Light it up — Fireworks incoming!",
  ],
  holographic: [
    "Holographic overlay engaged. Welcome to the future.",
    "The room just went holographic. Stay a while.",
  ],
};

export class AICommentary {
  private usedLines = new Set<string>();

  private pickLine(lines: string[]): string {
    const available = lines.filter((l) => !this.usedLines.has(l));
    const pool = available.length > 0 ? available : lines;
    const line = pool[Math.floor(Math.random() * pool.length)];
    this.usedLines.add(line);
    if (this.usedLines.size > 50) this.usedLines.clear(); // Reset after 50 lines
    return line;
  }

  onPlayerJoin(player: Player, room: Room): string {
    const lines = [
      `${player.name} just walked into the VIP lounge.`,
      `Look who it is — ${player.name} has arrived.`,
      `The room just got better. Welcome, ${player.name}.`,
      `${player.name} is here. Let the games begin.`,
    ];
    return this.pickLine(lines);
  }

  onPlayerLeave(player: Player): string {
    const lines = [
      `${player.name} dipped. Respect.`,
      `And just like that, ${player.name} is gone.`,
      `${player.name} left the building.`,
    ];
    return this.pickLine(lines);
  }

  onStreak(player: Player, streak: number): string {
    const lines = [
      `${player.name} is on a ${streak}-round streak. Unstoppable.`,
      `Someone stop ${player.name} — ${streak} wins in a row!`,
      `${player.name} is absolutely cooking right now. ${streak} straight.`,
      `${streak} wins? ${player.name} might be the GOAT.`,
    ];
    return this.pickLine(lines);
  }

  onBigWin(player: Player, amount: number): string {
    const lines = [
      `${player.name} just bagged ${amount.toLocaleString()} Royal Chips. Big W.`,
      `Rah, ${player.name} is eating good tonight — ${amount.toLocaleString()} chips!`,
      `${player.name} said "watch this" and absolutely delivered.`,
      `The vault opened for ${player.name}. ${amount.toLocaleString()} chips!`,
    ];
    return this.pickLine(lines);
  }

  onRouletteSpin(number: number): string {
    const isRed = [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36].includes(number);
    if (number === 0) {
      return this.pickLine([
        "Green zero. The house said 'nah'.",
        "Zero. Absolute scenes.",
        "The ball landed on zero. Chaos.",
      ]);
    }
    const lines = [
      `The wheel spoke: ${number}. ${isRed ? "Red" : "Black"} takes it.`,
      `${number} — ${isRed ? "red" : "black"}. That's the one.`,
      `Ball drops on ${number}. Beautiful.`,
    ];
    return this.pickLine(lines);
  }

  onVaultHeistStart(): string {
    return this.pickLine([
      "Vault Heist is live — pick your vault, choose your fate.",
      "The vaults are sealed. Choose wisely, the clock is ticking.",
      "Heist time. Everyone's got a target in mind. Or a guess.",
    ]);
  }

  onVaultHeistChoice(choices: Record<string, string>, vaults: any[]): string {
    const choiceCounts: Record<string, number> = {};
    Object.values(choices).forEach((v) => {
      choiceCounts[v] = (choiceCounts[v] || 0) + 1;
    });

    const maxChoice = Object.entries(choiceCounts).sort((a, b) => b[1] - a[1])[0];
    if (maxChoice && maxChoice[1] > 1) {
      const vault = vaults.find((v) => v.id === maxChoice[0]);
      return this.pickLine([
        `${maxChoice[1]} players went for the ${vault?.name || "same vault"}. Bold or broke?`,
        `Multiple people picked the ${vault?.name || "same vault"}. Someone's bluffing...`,
        `The ${vault?.name || "vault"} is crowded. Risky move.`,
      ]);
    }

    return this.pickLine([
      "Everyone picked different vaults. Respect the strategy.",
      "No consensus. This heist just got interesting.",
      "Split decisions. Let's see who read the room right.",
    ]);
  }

  onVaultHeistEvent(eventName: string): string {
    const lines: Record<string, string[]> = {
      golden_vault: [
        "Golden Vault activated! 3x multiplier. This is huge.",
        "Someone's about to get VERY rich. Golden Vault is live.",
      ],
      lucky: [
        "Lucky draw! Everyone's a winner today.",
        "The luck is contagious. Double rewards incoming.",
      ],
      lockdown: [
        "Security lockdown! The house is fighting back.",
        "Lockdown initiated. Play it safe, folks.",
      ],
      double: [
        "Double or nothing. No half-measures.",
        "High risk, high reward. Double multiplier active.",
      ],
      ghost: [
        "Ghost vault appeared. Spooky but safe.",
        "A ghost walks among us. Empty vault, zero risk.",
      ],
      mystery: [
        "Mystery chest! Nobody knows what's inside.",
        "Random rewards for everyone. The AI is feeling generous.",
      ],
    };
    return this.pickLine(lines[eventName] || ["Something's happening..."]);
  }

  onBluffDetected(): string {
    return this.pickLine([
      "Someone is bluffing... I can feel it.",
      "The tells are obvious. Someone's playing games.",
      "Bluff detected. Keep your cool.",
    ]);
  }

  onGameStart(gameType: string): string {
    const lines = gameType === "neon-roulette" ? [
      "Neon Roulette is live. Place your bets wisely.",
      "The wheel is spinning. Fortune favors the bold.",
    ] : [
      "Vault Heist begins. Trust no one.",
      "The vaults are waiting. Choose your target.",
    ];
    return this.pickLine(lines);
  }

  onMVP(player: Player): string {
    return this.pickLine([
      `${player.name} is the MVP. Absolute legend.`,
      `Give it up for ${player.name} — tonight's MVP!`,
      `${player.name} carried. No cap.`,
    ]);
  }

  onComeback(player: Player, lossStreak: number): string {
    return this.pickLine([
      `${player.name} was down ${lossStreak} rounds straight — and just clawed it back. Comeback of the night.`,
      `From ${lossStreak} losses to a win. ${player.name} never folded.`,
      `That's what a comeback looks like. ${player.name} refused to stay down.`,
    ]);
  }

  /**
   * Purely cosmetic room-wide event roll. Never touches odds, bets, or payouts —
   * only decides whether to fire a visual moment and which one.
   */
  maybeRoomEvent(context: { amount: number; streak: number; round: number; hadComeback: boolean }): { name: AIRoomEventType; line: string } | null {
    const { amount, streak, round, hadComeback } = context;

    let pool: AIRoomEventType[] = [];
    if (amount >= 5000) pool = ["gold_rain", "fireworks"];
    else if (streak >= 4) pool = ["laser_show", "lightning_storm"];
    else if (hadComeback) pool = ["fireworks", "confetti_burst"];
    else if (round % 4 === 0) pool = ["floating_coins", "emoji_storm", "holographic", "confetti_burst"];

    if (pool.length === 0) return null;
    // Keep it special, not constant — roughly 1 in 3 eligible moments actually fires.
    if (Math.random() > 0.35) return null;

    const name = pool[Math.floor(Math.random() * pool.length)];
    const line = this.pickLine(ROOM_EVENT_LINES[name]);
    return { name, line };
  }

  generateMatchSummary(
    players: Player[],
    rounds: RoundRecord[],
    startingChips: Record<string, number>
  ): SessionSummary {
    const finalStandings = players
      .map((p) => ({ id: p.id, name: p.name, chips: p.chips }))
      .sort((a, b) => b.chips - a.chips);

    const netByPlayer: Record<string, number> = {};
    players.forEach((p) => {
      netByPlayer[p.id] = p.chips - (startingChips[p.id] ?? p.chips);
    });

    let mvpId: string | null = null;
    let mvpChipsWon = -Infinity;
    Object.entries(netByPlayer).forEach(([id, net]) => {
      if (net > mvpChipsWon) {
        mvpChipsWon = net;
        mvpId = id;
      }
    });
    const mvpName = players.find((p) => p.id === mvpId)?.name ?? null;

    let biggestWinPlayerId: string | null = null;
    let biggestWinAmount = 0;
    rounds.forEach((r) => {
      if (r.winnerAmount && r.winnerAmount > biggestWinAmount) {
        biggestWinAmount = r.winnerAmount;
        biggestWinPlayerId = r.winnerId ?? null;
      }
    });
    const biggestWinPlayerName = players.find((p) => p.id === biggestWinPlayerId)?.name ?? null;

    let longestStreakName: string | null = null;
    let longestStreak = 0;
    players.forEach((p) => {
      if (p.winStreak > longestStreak) {
        longestStreak = p.winStreak;
        longestStreakName = p.name;
      }
    });

    const narrative: string[] = [];
    narrative.push(
      rounds.length > 0
        ? `${rounds.length} rounds played tonight — the vault never rested.`
        : `A quiet session, but the lounge was open.`
    );
    if (mvpName) narrative.push(`${mvpName} walks away tonight's MVP, up ${Math.max(0, mvpChipsWon).toLocaleString()} chips.`);
    if (biggestWinPlayerName) narrative.push(`Biggest single win goes to ${biggestWinPlayerName} — ${biggestWinAmount.toLocaleString()} chips in one round.`);
    if (longestStreakName && longestStreak >= 2) narrative.push(`${longestStreakName} ran the hottest streak of the night at ${longestStreak} straight.`);
    narrative.push("Thanks for playing — see you at the next table.");

    return {
      totalRounds: rounds.length,
      mvpId,
      mvpName,
      mvpChipsWon: Math.max(0, mvpChipsWon === -Infinity ? 0 : mvpChipsWon),
      biggestWinPlayerId,
      biggestWinPlayerName,
      biggestWinAmount,
      longestStreakName,
      longestStreak,
      comebackPlayerName: null,
      narrative,
      finalStandings,
    };
  }
}
