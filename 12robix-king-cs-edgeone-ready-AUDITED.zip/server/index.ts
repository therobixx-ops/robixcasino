import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import cors from "cors";
import { RoomManager } from "./rooms";
import { RouletteGame } from "./games/roulette";
import { VaultHeistGame } from "./games/vaultHeist";
import { CoinFlipGame } from "./games/coinFlip";
import { DiceGame } from "./games/dice";
import { AICommentary } from "./aiCommentary";
import { verifyAdminCredentials, createAdminToken, verifyAdminToken } from "./adminAuth";
import { walletService } from "./services/WalletService";
import { adService } from "./services/AdService";
import { securityService } from "./services/SecurityService";
import type { ClientToServerEvents, ServerToClientEvents, Player, ActivityLogEntry, Tournament, RoundRecord, AdminDashboardStats } from "../types";

// CORS_ORIGIN accepts a single origin or a comma-separated list. Falls back
// to "*" for local/dev use if unset, but production deployments should set
// this to the exact frontend origin(s) per DEPLOY_EDGEONE.md.
const corsOrigins = process.env.CORS_ORIGIN
  ? process.env.CORS_ORIGIN.split(",").map((o) => o.trim()).filter(Boolean)
  : "*";

const app = express();
app.use(cors({ origin: corsOrigins }));
app.use(express.json());

const httpServer = createServer(app);
const io = new Server<ClientToServerEvents, ServerToClientEvents>(httpServer, {
  cors: { origin: corsOrigins, methods: ["GET", "POST"] },
});

const roomManager = new RoomManager();
const rouletteGames = new Map<string, RouletteGame>();
const heistGames = new Map<string, VaultHeistGame>();
const coinFlipGames = new Map<string, CoinFlipGame>();
const diceGames = new Map<string, DiceGame>();
const aiHosts = new Map<string, AICommentary>();
const activityLogs = new Map<string, ActivityLogEntry[]>();
const tournaments = new Map<string, Tournament>();
const playerProgress = new Map<string, { gamesPlayed: number; gamesWon: number; chipsWon: number; winStreak: number; bestStreak: number; lossStreak: number }>();
const bannedPlayers = new Map<string, Set<string>>();
const mutedPlayers = new Map<string, Set<string>>();
const sessionRounds = new Map<string, RoundRecord[]>();
const sessionRoundCounter = new Map<string, number>();
const sessionStartingChips = new Map<string, Record<string, number>>();

function pushRoundRecord(roomId: string, record: RoundRecord) {
  const rounds = sessionRounds.get(roomId) || [];
  rounds.push(record);
  if (rounds.length > 100) rounds.shift();
  sessionRounds.set(roomId, rounds);
  io.to(roomId).emit("session:rounds", rounds);
}

function nextRoundNumber(roomId: string): number {
  const n = (sessionRoundCounter.get(roomId) || 0) + 1;
  sessionRoundCounter.set(roomId, n);
  return n;
}

function trackStartingChips(roomId: string, player: Player) {
  const map = sessionStartingChips.get(roomId) || {};
  if (!(player.id in map)) map[player.id] = player.chips;
  sessionStartingChips.set(roomId, map);
}

function clearSessionData(roomId: string) {
  sessionRounds.delete(roomId);
  sessionRoundCounter.delete(roomId);
  sessionStartingChips.delete(roomId);
}

const messageCounts = new Map<string, { count: number; resetTime: number }>();

function checkRateLimit(socketId: string): boolean {
  const now = Date.now();
  const limit = messageCounts.get(socketId);
  if (!limit || now > limit.resetTime) {
    messageCounts.set(socketId, { count: 1, resetTime: now + 1000 });
    return true;
  }
  if (limit.count >= 10) return false;
  limit.count++;
  return true;
}

function broadcastAI(roomId: string, text: string, type: string = "info") {
  io.to(roomId).emit("ai:announcement", text, type);
}

function logActivity(roomId: string, entry: Omit<ActivityLogEntry, "id" | "timestamp" | "roomId">) {
  const logs = activityLogs.get(roomId) || [];
  logs.push({
    ...entry,
    id: crypto.randomUUID(),
    timestamp: Date.now(),
    roomId,
  });
  if (logs.length > 200) logs.shift();
  activityLogs.set(roomId, logs);
}

function getOrCreateProgress(playerId: string) {
  if (!playerProgress.has(playerId)) {
    playerProgress.set(playerId, { gamesPlayed: 0, gamesWon: 0, chipsWon: 0, winStreak: 0, bestStreak: 0, lossStreak: 0 });
  }
  return playerProgress.get(playerId)!;
}

io.on("connection", (socket) => {
  console.log(`Player connected: ${socket.id}`);
  let currentRoomId: string | null = null;
  let currentPlayer: Player | null = null;

  socket.on("room:create", (data, callback) => {
    const room = roomManager.createRoom({
      name: data.name || "Royal Room",
      hostId: socket.id,
      maxPlayers: data.maxPlayers || 8,
      password: data.password,
    });

    const progress = getOrCreateProgress(socket.id);
    const wallet = walletService.getOrCreate(socket.id, "Host");

    const player: Player = {
      id: socket.id,
      name: "Host",
      avatar: "👑",
      chips: wallet.balance,
      isReady: true,
      isHost: true,
      ping: 0,
      winStreak: progress.winStreak,
      coinsWon: wallet.coinsWon,
      coinsLost: wallet.coinsLost,
      totalBets: wallet.totalBets,
      totalWins: wallet.totalWins,
      totalLosses: wallet.totalLosses,
    };

    roomManager.joinRoom(room.id, player);
    socket.join(room.id);
    currentRoomId = room.id;
    currentPlayer = player;
    aiHosts.set(room.id, new AICommentary());
    activityLogs.set(room.id, []);
    sessionRounds.set(room.id, []);
    sessionRoundCounter.set(room.id, 0);
    trackStartingChips(room.id, player);

    callback(room);
    io.to(room.id).emit("room:update", room);
    socket.emit("wallet:update", wallet);
  });

  socket.on("room:join", (data, callback) => {
    const room = roomManager.getRoomByCode(data.code);
    if (!room || room.isLocked || room.players.length >= room.maxPlayers) {
      callback(null);
      return;
    }
    if (bannedPlayers.get(room.id)?.has(socket.id)) {
      socket.emit("error", "You have been banned from this room.");
      callback(null);
      return;
    }

    const progress = getOrCreateProgress(socket.id);
    const wallet = walletService.getOrCreate(socket.id, data.name || "Guest");

    const player: Player = {
      id: socket.id,
      name: data.name || "Guest",
      avatar: data.avatar || "🎭",
      chips: wallet.balance,
      isReady: false,
      isHost: false,
      ping: 0,
      winStreak: progress.winStreak,
      coinsWon: wallet.coinsWon,
      coinsLost: wallet.coinsLost,
      totalBets: wallet.totalBets,
      totalWins: wallet.totalWins,
      totalLosses: wallet.totalLosses,
    };

    roomManager.joinRoom(room.id, player);
    socket.join(room.id);
    currentRoomId = room.id;
    currentPlayer = player;
    trackStartingChips(room.id, player);

    callback(room);
    io.to(room.id).emit("room:update", room);
    socket.emit("wallet:update", wallet);

    const ai = aiHosts.get(room.id);
    if (ai) broadcastAI(room.id, ai.onPlayerJoin(player, room), "info");

    logActivity(room.id, {
      type: "join",
      playerId: socket.id,
      playerName: player.name,
      details: `${player.name} joined the room`,
    });

    io.to(room.id).emit("chat:message", {
      id: Date.now().toString(),
      playerId: "system",
      playerName: "System",
      text: `${player.name} joined the room`,
      type: "system",
      timestamp: Date.now(),
    });
  });

  socket.on("room:leave", () => {
    if (currentRoomId) {
      const ai = aiHosts.get(currentRoomId);
      if (ai && currentPlayer) broadcastAI(currentRoomId, ai.onPlayerLeave(currentPlayer), "info");

      logActivity(currentRoomId, {
        type: "leave",
        playerId: socket.id,
        playerName: currentPlayer?.name || "Unknown",
        details: `${currentPlayer?.name || "Someone"} left the room`,
      });

      roomManager.leaveRoom(currentRoomId, socket.id);
      socket.leave(currentRoomId);
      const updatedRoom = roomManager.getRoom(currentRoomId);
      if (updatedRoom) {
        io.to(currentRoomId).emit("room:update", updatedRoom);
      } else {
        aiHosts.delete(currentRoomId);
        rouletteGames.delete(currentRoomId);
        heistGames.delete(currentRoomId);
        coinFlipGames.delete(currentRoomId);
        diceGames.delete(currentRoomId);
        activityLogs.delete(currentRoomId);
        bannedPlayers.delete(currentRoomId);
        mutedPlayers.delete(currentRoomId);
        clearSessionData(currentRoomId);
      }
      currentRoomId = null;
      currentPlayer = null;
    }
  });

  socket.on("player:ready", (ready) => {
    if (!currentRoomId) return;
    roomManager.setPlayerReady(currentRoomId, socket.id, ready);
    const room = roomManager.getRoom(currentRoomId);
    if (room) io.to(currentRoomId).emit("room:update", room);
  });

  socket.on("player:spectate", (spectating) => {
    if (!currentRoomId || !currentPlayer) return;
    currentPlayer.isSpectator = spectating;
    if (spectating) roomManager.setPlayerReady(currentRoomId, socket.id, true);
    roomManager.setPlayerSpectating(currentRoomId, socket.id, spectating);
    const room = roomManager.getRoom(currentRoomId);
    if (room) io.to(currentRoomId).emit("room:update", room);
  });

  socket.on("chat:send", (text, type = "text") => {
    if (!currentRoomId || !currentPlayer) return;
    if (mutedPlayers.get(currentRoomId)?.has(socket.id)) {
      socket.emit("error", "You are muted in this room.");
      return;
    }
    if (!checkRateLimit(socket.id)) {
      socket.emit("error", "You are sending messages too fast!");
      return;
    }

    const message = {
      id: Date.now().toString(),
      playerId: socket.id,
      playerName: currentPlayer.name,
      text,
      type,
      timestamp: Date.now(),
    };

    roomManager.addMessage(currentRoomId, message);
    io.to(currentRoomId).emit("chat:message", message);

    logActivity(currentRoomId, {
      type: "chat",
      playerId: socket.id,
      playerName: currentPlayer.name,
      details: text.slice(0, 50),
    });
  });

  socket.on("game:start", (gameType) => {
    if (!currentRoomId || !currentPlayer?.isHost) return;
    const room = roomManager.getRoom(currentRoomId);
    if (!room) return;

    const ai = aiHosts.get(currentRoomId);
    const ALL_GAME_TYPES = ["neon-roulette", "vault-heist", "coin-flip", "dice"] as const;
    const resolvedGameType: "neon-roulette" | "vault-heist" | "coin-flip" | "dice" =
      gameType && (ALL_GAME_TYPES as readonly string[]).includes(gameType)
        ? (gameType as (typeof ALL_GAME_TYPES)[number])
        : ALL_GAME_TYPES[Math.floor(Math.random() * ALL_GAME_TYPES.length)];

    if (ai) broadcastAI(currentRoomId, ai.onGameStart(resolvedGameType), "info");

    logActivity(currentRoomId, {
      type: "game_start",
      playerId: socket.id,
      playerName: currentPlayer.name,
      details: `Started ${resolvedGameType}`,
    });

    if (resolvedGameType === "neon-roulette") {
      const game = new RouletteGame(currentRoomId, room.players);
      rouletteGames.set(currentRoomId, game);
      room.currentGame = "neon-roulette";
      room.gameState = game.getState();

      io.to(currentRoomId).emit("room:update", room);
      io.to(currentRoomId).emit("game:state", game.getState());

      game.start(async (state) => {
        io.to(currentRoomId!).emit("game:state", state);

        if (state.phase === "result") {
          const payouts = state.results?.payouts;
          let roundWinnerId: string | undefined;
          let roundWinnerName: string | undefined;
          let roundWinnerAmount: number | undefined;
          let roundEvent: string | undefined;

          if (payouts) {
            const sorted = Object.entries(payouts).sort((a, b) => (b[1] as number) - (a[1] as number));
            const [winnerId, amount] = sorted[0] ?? [undefined, 0];

            if (amount && (amount as number) > 0 && winnerId) {
              const winnerPlayer = room.players.find((p) => p.id === winnerId);
              if (winnerPlayer) {
                const progress = getOrCreateProgress(winnerId);
                progress.gamesWon++;
                progress.chipsWon += amount as number;
                progress.winStreak++;
                progress.lossStreak = 0;
                if (progress.winStreak > progress.bestStreak) progress.bestStreak = progress.winStreak;

                roundWinnerId = winnerId;
                roundWinnerName = winnerPlayer.name;
                roundWinnerAmount = amount as number;

                if (ai) {
                  broadcastAI(currentRoomId!, ai.onBigWin(winnerPlayer, amount as number), "celebration");
                  if (progress.winStreak >= 3) {
                    setTimeout(() => {
                      broadcastAI(currentRoomId!, ai.onStreak(winnerPlayer, progress.winStreak), "celebration");
                    }, 1200);
                  }
                }

                logActivity(currentRoomId!, {
                  type: "win",
                  playerId: winnerId,
                  playerName: winnerPlayer.name,
                  details: `Won ${amount} chips on roulette`,
                });
              }
            }
            Object.entries(payouts).forEach(([pid, amt]) => {
              if ((amt as number) <= 0) {
                const progress = getOrCreateProgress(pid);
                progress.winStreak = 0;
                progress.lossStreak++;
              }
            });

            io.to(currentRoomId!).emit("room:update", roomManager.getRoom(currentRoomId!)!);
          }

          pushRoundRecord(currentRoomId!, {
            id: crypto.randomUUID(),
            round: nextRoundNumber(currentRoomId!),
            gameType: "neon-roulette",
            timestamp: Date.now(),
            result: { winningNumber: state.winningNumber ?? undefined, isRed: state.results?.isRed },
            payouts: payouts || {},
            winnerId: roundWinnerId,
            winnerName: roundWinnerName,
            winnerAmount: roundWinnerAmount,
            roomEvent: roundEvent,
          });
        }

        if (state.status === "ended") {
          const liveRoom = roomManager.getRoom(currentRoomId!);
          if (liveRoom) {
            liveRoom.currentGame = null;
            liveRoom.players.forEach((p) => (p.isReady = false));
            io.to(currentRoomId!).emit("room:update", liveRoom);
          }
          rouletteGames.delete(currentRoomId!);
        }
      });
    } else if (resolvedGameType === "vault-heist") {
      const game = new VaultHeistGame(currentRoomId, room.players);
      heistGames.set(currentRoomId, game);
      room.currentGame = "vault-heist";
      room.gameState = game.getState();

      io.to(currentRoomId).emit("room:update", room);
      io.to(currentRoomId).emit("game:state", game.getState());

      game.start(async (state) => {
        io.to(currentRoomId!).emit("game:state", state);

        if (state.phase === "choosing" && ai) {
          broadcastAI(currentRoomId!, ai.onVaultHeistStart(), "info");
        }

        if (state.phase === "locked" && Object.keys(state.playerChoices).length > 0 && ai) {
          broadcastAI(currentRoomId!, ai.onVaultHeistChoice(state.playerChoices, state.vaults), "info");
        }

        if (state.phase === "event" && state.aiEvent && ai) {
          broadcastAI(currentRoomId!, ai.onVaultHeistEvent(state.aiEvent.effect), "warning");
        }

        if (state.phase === "result") {
          const rewards = state.rewards;
          let roundWinnerId: string | undefined;
          let roundWinnerName: string | undefined;
          let roundWinnerAmount: number | undefined;
          let roundEvent: string | undefined;

          if (rewards) {
            const sorted = Object.entries(rewards).sort((a, b) => (b[1] as number) - (a[1] as number));
            const [winnerId, amount] = sorted[0];
            if (amount && (amount as number) > 0) {
              const winnerPlayer = room.players.find(p => p.id === winnerId);
              if (winnerPlayer) {
                const progress = getOrCreateProgress(winnerId);
                const hadComeback = progress.lossStreak >= 3;
                progress.gamesWon++;
                progress.chipsWon += amount as number;
                progress.winStreak++;
                progress.lossStreak = 0;
                if (progress.winStreak > progress.bestStreak) progress.bestStreak = progress.winStreak;

                roundWinnerId = winnerId;
                roundWinnerName = winnerPlayer.name;
                roundWinnerAmount = amount as number;

                if (ai) {
                  broadcastAI(currentRoomId!, ai.onBigWin(winnerPlayer, amount as number), "celebration");
                  if (hadComeback) {
                    setTimeout(() => {
                      broadcastAI(currentRoomId!, ai.onComeback(winnerPlayer, progress.lossStreak), "celebration");
                    }, 1500);
                  }

                  const roundNum = sessionRoundCounter.get(currentRoomId!) || 1;
                  const roomEvent = ai.maybeRoomEvent({ amount: amount as number, streak: progress.winStreak, round: roundNum, hadComeback });
                  if (roomEvent) {
                    roundEvent = roomEvent.name;
                    setTimeout(() => {
                      io.to(currentRoomId!).emit("effect:trigger", roomEvent.name);
                      broadcastAI(currentRoomId!, roomEvent.line, "celebration");
                    }, 2000);
                  }
                }

                logActivity(currentRoomId!, {
                  type: "win",
                  playerId: winnerId,
                  playerName: winnerPlayer.name,
                  details: `Won ${amount} chips in vault heist`,
                });
              }
            }
            Object.entries(rewards).forEach(([pid, amt]) => {
              if ((amt as number) <= 0) {
                const progress = getOrCreateProgress(pid);
                progress.winStreak = 0;
                progress.lossStreak++;
              }
            });
          }

          const winnerVaultId = roundWinnerId ? state.playerChoices[roundWinnerId] : undefined;
          const winnerVault = winnerVaultId ? state.vaults.find((v) => v.id === winnerVaultId) : undefined;

          pushRoundRecord(currentRoomId!, {
            id: crypto.randomUUID(),
            round: nextRoundNumber(currentRoomId!),
            gameType: "vault-heist",
            timestamp: Date.now(),
            result: {
              vaultName: winnerVault?.name,
              vaultEmoji: winnerVault?.emoji,
              aiEventName: state.aiEvent?.effect,
            },
            payouts: rewards || {},
            winnerId: roundWinnerId,
            winnerName: roundWinnerName,
            winnerAmount: roundWinnerAmount,
            roomEvent: roundEvent,
          });

          io.to(currentRoomId!).emit("room:update", roomManager.getRoom(currentRoomId!)!);
        }

        if (state.status === "ended") {
          const liveRoom = roomManager.getRoom(currentRoomId!);
          if (liveRoom) {
            liveRoom.currentGame = null;
            liveRoom.players.forEach((p) => (p.isReady = false));
            io.to(currentRoomId!).emit("room:update", liveRoom);
          }
          heistGames.delete(currentRoomId!);
        }
      });
    } else if (resolvedGameType === "coin-flip") {
      const game = new CoinFlipGame(currentRoomId, room.players);
      coinFlipGames.set(currentRoomId, game);
      room.currentGame = "coin-flip";
      room.gameState = game.getState();

      io.to(currentRoomId).emit("room:update", room);
      io.to(currentRoomId).emit("game:state", game.getState());

      game.start(async (state) => {
        io.to(currentRoomId!).emit("game:state", state);

        if (state.phase === "result") {
          const payouts = state.results?.payouts;
          let roundWinnerId: string | undefined;
          let roundWinnerName: string | undefined;
          let roundWinnerAmount: number | undefined;
          let roundEvent: string | undefined;

          if (payouts) {
            const sorted = Object.entries(payouts).sort((a, b) => (b[1] as number) - (a[1] as number));
            const [winnerId, amount] = sorted[0] ?? [undefined, 0];

            if (amount && (amount as number) > 0 && winnerId) {
              const winnerPlayer = room.players.find((p) => p.id === winnerId);
              if (winnerPlayer) {
                const progress = getOrCreateProgress(winnerId);
                progress.gamesWon++;
                progress.chipsWon += amount as number;
                progress.winStreak++;
                progress.lossStreak = 0;
                if (progress.winStreak > progress.bestStreak) progress.bestStreak = progress.winStreak;

                roundWinnerId = winnerId;
                roundWinnerName = winnerPlayer.name;
                roundWinnerAmount = amount as number;

                if (ai) {
                  broadcastAI(currentRoomId!, ai.onBigWin(winnerPlayer, amount as number), "celebration");
                  if (progress.winStreak >= 3) {
                    setTimeout(() => {
                      broadcastAI(currentRoomId!, ai.onStreak(winnerPlayer, progress.winStreak), "celebration");
                    }, 1200);
                  }
                }

                logActivity(currentRoomId!, {
                  type: "win",
                  playerId: winnerId,
                  playerName: winnerPlayer.name,
                  details: `Won ${amount} chips on coin flip`,
                });
              }
            }
            Object.entries(payouts).forEach(([pid, amt]) => {
              if ((amt as number) <= 0) {
                const progress = getOrCreateProgress(pid);
                progress.winStreak = 0;
                progress.lossStreak++;
              }
            });

            io.to(currentRoomId!).emit("room:update", roomManager.getRoom(currentRoomId!)!);
          }

          pushRoundRecord(currentRoomId!, {
            id: crypto.randomUUID(),
            round: nextRoundNumber(currentRoomId!),
            gameType: "coin-flip",
            timestamp: Date.now(),
            result: { coinResult: state.results?.result },
            payouts: payouts || {},
            winnerId: roundWinnerId,
            winnerName: roundWinnerName,
            winnerAmount: roundWinnerAmount,
            roomEvent: roundEvent,
          });

          io.to(currentRoomId!).emit("room:update", roomManager.getRoom(currentRoomId!)!);
        }

        if (state.status === "ended") {
          const liveRoom = roomManager.getRoom(currentRoomId!);
          if (liveRoom) {
            liveRoom.currentGame = null;
            liveRoom.players.forEach((p) => (p.isReady = false));
            io.to(currentRoomId!).emit("room:update", liveRoom);
          }
          coinFlipGames.delete(currentRoomId!);
        }
      });
    } else {
      const game = new DiceGame(currentRoomId, room.players);
      diceGames.set(currentRoomId, game);
      room.currentGame = "dice";
      room.gameState = game.getState();

      io.to(currentRoomId).emit("room:update", room);
      io.to(currentRoomId).emit("game:state", game.getState());

      game.start(async (state) => {
        io.to(currentRoomId!).emit("game:state", state);

        if (state.phase === "result") {
          const payouts = state.results?.payouts;
          let roundWinnerId: string | undefined;
          let roundWinnerName: string | undefined;
          let roundWinnerAmount: number | undefined;
          let roundEvent: string | undefined;

          if (payouts) {
            const sorted = Object.entries(payouts).sort((a, b) => (b[1] as number) - (a[1] as number));
            const [winnerId, amount] = sorted[0] ?? [undefined, 0];

            if (amount && (amount as number) > 0 && winnerId) {
              const winnerPlayer = room.players.find((p) => p.id === winnerId);
              if (winnerPlayer) {
                const progress = getOrCreateProgress(winnerId);
                progress.gamesWon++;
                progress.chipsWon += amount as number;
                progress.winStreak++;
                progress.lossStreak = 0;
                if (progress.winStreak > progress.bestStreak) progress.bestStreak = progress.winStreak;

                roundWinnerId = winnerId;
                roundWinnerName = winnerPlayer.name;
                roundWinnerAmount = amount as number;

                if (ai) {
                  broadcastAI(currentRoomId!, ai.onBigWin(winnerPlayer, amount as number), "celebration");
                  if (progress.winStreak >= 3) {
                    setTimeout(() => {
                      broadcastAI(currentRoomId!, ai.onStreak(winnerPlayer, progress.winStreak), "celebration");
                    }, 1200);
                  }
                }

                logActivity(currentRoomId!, {
                  type: "win",
                  playerId: winnerId,
                  playerName: winnerPlayer.name,
                  details: `Won ${amount} chips on dice`,
                });
              }
            }
            Object.entries(payouts).forEach(([pid, amt]) => {
              if ((amt as number) <= 0) {
                const progress = getOrCreateProgress(pid);
                progress.winStreak = 0;
                progress.lossStreak++;
              }
            });

            io.to(currentRoomId!).emit("room:update", roomManager.getRoom(currentRoomId!)!);
          }

          pushRoundRecord(currentRoomId!, {
            id: crypto.randomUUID(),
            round: nextRoundNumber(currentRoomId!),
            gameType: "dice",
            timestamp: Date.now(),
            result: {
              diceValues: state.results?.dice,
              diceTotal: state.results?.total,
            },
            payouts: payouts || {},
            winnerId: roundWinnerId,
            winnerName: roundWinnerName,
            winnerAmount: roundWinnerAmount,
            roomEvent: roundEvent,
          });

          io.to(currentRoomId!).emit("room:update", roomManager.getRoom(currentRoomId!)!);
        }

        if (state.status === "ended") {
          const liveRoom = roomManager.getRoom(currentRoomId!);
          if (liveRoom) {
            liveRoom.currentGame = null;
            liveRoom.players.forEach((p) => (p.isReady = false));
            io.to(currentRoomId!).emit("room:update", liveRoom);
          }
          diceGames.delete(currentRoomId!);
        }
      });
    }
  });

  socket.on("game:stop", () => {
    if (!currentRoomId || !currentPlayer?.isHost) return;
    rouletteGames.get(currentRoomId)?.stop();
    heistGames.get(currentRoomId)?.stop();
    coinFlipGames.get(currentRoomId)?.stop();
    diceGames.get(currentRoomId)?.stop();
    logActivity(currentRoomId, {
      type: "game_end",
      playerId: socket.id,
      playerName: currentPlayer.name,
      details: "Host stopped the table",
    });
  });

  socket.on("game:bet", async (bet, txId) => {
    if (!currentRoomId || currentPlayer?.isSpectator) return;
    if (txId && securityService.isDuplicate(txId)) {
      socket.emit("bet:rejected", "Duplicate bet detected.");
      return;
    }

    const room = roomManager.getRoom(currentRoomId);
    const game =
      room?.currentGame === "coin-flip" ? coinFlipGames.get(currentRoomId)
      : room?.currentGame === "dice" ? diceGames.get(currentRoomId)
      : room?.currentGame === "neon-roulette" ? rouletteGames.get(currentRoomId)
      : undefined;
    if (!game) return;

    const ok = await game.placeBet(socket.id, bet);
    if (!ok) {
      socket.emit("bet:rejected", "Not enough chips or invalid bet.");
      return;
    }

    const wallet = walletService.get(socket.id);
    if (wallet) socket.emit("wallet:update", wallet);

    io.to(currentRoomId).emit("room:update", roomManager.getRoom(currentRoomId)!);
    logActivity(currentRoomId, {
      type: "bet",
      playerId: socket.id,
      playerName: currentPlayer?.name || "Unknown",
      details: `Bet ${bet.amount} on ${bet.type} ${bet.value}`,
    });
  });

  socket.on("game:choose", (choice) => {
    if (!currentRoomId || currentPlayer?.isSpectator) return;
    const game = heistGames.get(currentRoomId);
    if (game) {
      game.makeChoice(socket.id, choice);
      logActivity(currentRoomId, {
        type: "bet",
        playerId: socket.id,
        playerName: currentPlayer?.name || "Unknown",
        details: `Chose a vault`,
      });
    }
  });

  socket.on("prank:trigger", (effect, targetId) => {
    if (!currentRoomId) return;
    io.to(currentRoomId).emit("effect:trigger", effect, targetId);
    logActivity(currentRoomId, {
      type: "prank",
      playerId: socket.id,
      playerName: currentPlayer?.name || "Unknown",
      details: `Triggered ${effect} prank`,
    });
  });

  socket.on("admin:kick", (playerId) => {
    if (!currentRoomId || !currentPlayer?.isHost) return;
    roomManager.leaveRoom(currentRoomId, playerId);
    io.to(currentRoomId).emit("room:update", roomManager.getRoom(currentRoomId)!);
    logActivity(currentRoomId, {
      type: "admin",
      playerId: socket.id,
      playerName: currentPlayer.name,
      details: `Kicked player ${playerId}`,
    });
  });

  socket.on("admin:ban", (playerId) => {
    if (!currentRoomId || !currentPlayer?.isHost) return;
    const set = bannedPlayers.get(currentRoomId) || new Set<string>();
    set.add(playerId);
    bannedPlayers.set(currentRoomId, set);
    roomManager.leaveRoom(currentRoomId, playerId);
    io.to(currentRoomId).emit("room:update", roomManager.getRoom(currentRoomId)!);
    const targetSocket = io.sockets.sockets.get(playerId);
    targetSocket?.emit("error", "You have been banned from this room.");
    targetSocket?.leave(currentRoomId);
    logActivity(currentRoomId, {
      type: "admin",
      playerId: socket.id,
      playerName: currentPlayer.name,
      details: `Banned player ${playerId}`,
    });
  });

  socket.on("admin:mute", (playerId) => {
    if (!currentRoomId || !currentPlayer?.isHost) return;
    const set = mutedPlayers.get(currentRoomId) || new Set<string>();
    if (set.has(playerId)) set.delete(playerId);
    else set.add(playerId);
    mutedPlayers.set(currentRoomId, set);
    logActivity(currentRoomId, {
      type: "admin",
      playerId: socket.id,
      playerName: currentPlayer.name,
      details: `${set.has(playerId) ? "Muted" : "Unmuted"} player ${playerId}`,
    });
  });

  socket.on("admin:chips", (playerId, amount) => {
    if (!currentRoomId || !currentPlayer?.isHost) return;
    const adminPlayer = currentPlayer;
    walletService.adminAdjust(playerId, amount, socket.id).then((result) => {
      if (!result.success) {
        socket.emit("error", result.error ?? "Failed to adjust chips.");
        return;
      }
      const wallet = walletService.get(playerId);
      if (wallet) {
        const player = roomManager.getRoom(currentRoomId!)?.players.find(p => p.id === playerId);
        if (player) player.chips = wallet.balance;
        io.to(playerId).emit("wallet:update", wallet);
      }
      io.to(currentRoomId!).emit("room:update", roomManager.getRoom(currentRoomId!)!);
      logActivity(currentRoomId!, {
        type: "admin",
        playerId: socket.id,
        playerName: adminPlayer.name,
        details: `${amount > 0 ? "Gifted" : "Removed"} ${Math.abs(amount)} chips`,
      });
    });
  });

  socket.on("admin:broadcast", (message) => {
    if (!currentRoomId || !currentPlayer?.isHost) return;
    io.to(currentRoomId).emit("chat:message", {
      id: Date.now().toString(),
      playerId: "admin",
      playerName: "📢 Admin",
      text: message,
      type: "system",
      timestamp: Date.now(),
    });
  });

  socket.on("admin:timer", (seconds) => {
    if (!currentRoomId || !currentPlayer?.isHost) return;
    const room = roomManager.getRoom(currentRoomId);
    if (room) {
      room.settings.roundTimer = seconds;
      io.to(currentRoomId).emit("room:update", room);
    }
  });

  socket.on("wallet:claimDaily", (callback) => {
    if (!currentPlayer) return callback({ success: false, error: "Not authenticated" });
    const result = walletService.claimDailyBonus(currentPlayer.id);
    if (result.success) {
      const wallet = walletService.get(currentPlayer.id)!;
      currentPlayer.chips = wallet.balance;
      socket.emit("wallet:update", wallet);
      if (currentRoomId) io.to(currentRoomId).emit("room:update", roomManager.getRoom(currentRoomId)!);
    }
    callback(result);
  });

  socket.on("ad:complete", (campaignId, watchedMs, skipped, clicked) => {
    adService.recordComplete(campaignId, watchedMs, skipped, clicked);
  });

  socket.on("session:end", () => {
    if (!currentRoomId || !currentPlayer?.isHost) return;
    const room = roomManager.getRoom(currentRoomId);
    const ai = aiHosts.get(currentRoomId);
    if (!room || !ai) return;

    const rounds = sessionRounds.get(currentRoomId) || [];
    const startingChips = sessionStartingChips.get(currentRoomId) || {};
    const summary = ai.generateMatchSummary(room.players, rounds, startingChips);

    io.to(currentRoomId).emit("session:summary", summary);
    logActivity(currentRoomId, {
      type: "admin",
      playerId: socket.id,
      playerName: currentPlayer.name,
      details: "Ended the session and generated a recap",
    });
  });

  socket.on("disconnect", () => {
    if (currentRoomId) {
      const ai = aiHosts.get(currentRoomId);
      if (ai && currentPlayer) broadcastAI(currentRoomId, ai.onPlayerLeave(currentPlayer), "info");

      roomManager.leaveRoom(currentRoomId, socket.id);
      const room = roomManager.getRoom(currentRoomId);
      if (room) {
        io.to(currentRoomId).emit("room:update", room);
      } else {
        aiHosts.delete(currentRoomId);
        rouletteGames.delete(currentRoomId);
        heistGames.delete(currentRoomId);
        coinFlipGames.delete(currentRoomId);
        diceGames.delete(currentRoomId);
        activityLogs.delete(currentRoomId);
        bannedPlayers.delete(currentRoomId);
        mutedPlayers.delete(currentRoomId);
        clearSessionData(currentRoomId);
      }
    }
    console.log(`Player disconnected: ${socket.id}`);
  });
});

app.get("/api/rooms/:roomId/logs", (req, res) => {
  const logs = activityLogs.get(req.params.roomId) || [];
  res.json(logs);
});

app.get("/api/rooms/:roomId/stats", (req, res) => {
  const logs = activityLogs.get(req.params.roomId) || [];
  const stats = {
    totalGames: logs.filter((l) => l.type === "game_start").length,
    totalBets: logs.filter((l) => l.type === "bet").length,
    totalChipsExchanged: logs.filter((l) => l.type === "win").length * 1000,
    mostActivePlayer: "",
    longestStreak: 0,
    avgSessionTime: 0,
  };
  res.json(stats);
});

function requireAdmin(req: express.Request, res: express.Response, next: express.NextFunction) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : undefined;
  if (!verifyAdminToken(token)) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  next();
}

app.post("/api/admin/login", (req, res) => {
  const { username, password } = req.body || {};
  try {
    if (!verifyAdminCredentials(username, password)) {
      res.status(401).json({ error: "Invalid credentials" });
      return;
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Admin login is not configured on this server." });
    return;
  }
  res.json({ token: createAdminToken() });
});

app.get("/api/admin/rooms", requireAdmin, (_req, res) => {
  const rooms = roomManager.getAllRooms().map((room) => ({
    id: room.id,
    code: room.code,
    name: room.name,
    playerCount: room.players.length,
    maxPlayers: room.maxPlayers,
    isLocked: room.isLocked,
    currentGame: room.currentGame,
    createdAt: room.createdAt,
    players: room.players.map((p) => ({ id: p.id, name: p.name, chips: p.chips, isHost: p.isHost })),
  }));
  res.json(rooms);
});

app.post("/api/admin/rooms/:roomId/lock", requireAdmin, (req, res) => {
  const { locked } = req.body || {};
  const ok = roomManager.setLocked(req.params.roomId, Boolean(locked));
  if (!ok) { res.status(404).json({ error: "Room not found" }); return; }
  const room = roomManager.getRoom(req.params.roomId);
  if (room) io.to(room.id).emit("room:update", room);
  res.json({ success: true });
});

app.post("/api/admin/rooms/:roomId/kick", requireAdmin, (req, res) => {
  const { playerId } = req.body || {};
  roomManager.leaveRoom(req.params.roomId, playerId);
  const room = roomManager.getRoom(req.params.roomId);
  if (room) io.to(room.id).emit("room:update", room);
  const targetSocket = io.sockets.sockets.get(playerId);
  targetSocket?.emit("error", "You have been removed from this room by the administrator.");
  targetSocket?.leave(req.params.roomId);
  res.json({ success: true });
});

app.post("/api/admin/rooms/:roomId/ban", requireAdmin, (req, res) => {
  const { playerId } = req.body || {};
  const set = bannedPlayers.get(req.params.roomId) || new Set<string>();
  set.add(playerId);
  bannedPlayers.set(req.params.roomId, set);
  roomManager.leaveRoom(req.params.roomId, playerId);
  const room = roomManager.getRoom(req.params.roomId);
  if (room) io.to(room.id).emit("room:update", room);
  const targetSocket = io.sockets.sockets.get(playerId);
  targetSocket?.emit("error", "You have been banned from this room by the administrator.");
  targetSocket?.leave(req.params.roomId);
  res.json({ success: true });
});

app.post("/api/admin/rooms/:roomId/chips", requireAdmin, (req, res) => {
  const { playerId, amount } = req.body || {};
  if (typeof amount !== "number" || !Number.isFinite(amount)) {
    res.status(400).json({ error: "amount must be a number" });
    return;
  }
  roomManager.updateChips(req.params.roomId, playerId, amount);
  const room = roomManager.getRoom(req.params.roomId);
  if (!room) { res.status(404).json({ error: "Room not found" }); return; }
  io.to(room.id).emit("room:update", room);
  res.json({ success: true });
});

app.post("/api/admin/rooms/:roomId/broadcast", requireAdmin, (req, res) => {
  const { message } = req.body || {};
  const room = roomManager.getRoom(req.params.roomId);
  if (!room) { res.status(404).json({ error: "Room not found" }); return; }
  io.to(room.id).emit("chat:message", {
    id: Date.now().toString(),
    playerId: "admin",
    playerName: "📢 Admin",
    text: message,
    type: "system",
    timestamp: Date.now(),
  });
  res.json({ success: true });
});

app.post("/api/admin/rooms/:roomId/regenerate-invite", requireAdmin, (req, res) => {
  const code = roomManager.regenerateCode(req.params.roomId);
  if (!code) { res.status(404).json({ error: "Room not found" }); return; }
  const room = roomManager.getRoom(req.params.roomId);
  if (room) io.to(room.id).emit("room:update", room);
  res.json({ code });
});

app.post("/api/admin/rooms/:roomId/end", requireAdmin, (req, res) => {
  const room = roomManager.getRoom(req.params.roomId);
  if (!room) { res.status(404).json({ error: "Room not found" }); return; }
  io.to(room.id).emit("error", "This room was ended by the administrator.");
  io.socketsLeave(room.id);
  roomManager.deleteRoom(room.id);
  aiHosts.delete(room.id);
  rouletteGames.delete(room.id);
  heistGames.delete(room.id);
  coinFlipGames.delete(room.id);
  diceGames.delete(room.id);
  activityLogs.delete(room.id);
  bannedPlayers.delete(room.id);
  mutedPlayers.delete(room.id);
  clearSessionData(room.id);
  res.json({ success: true });
});

// ─── NEW ADMIN ENDPOINTS ───

app.get("/api/admin/wallets", requireAdmin, (_req, res) => {
  const wallets = walletService.getAll().map(w => ({ ...w, name: w.playerId }));
  res.json(wallets);
});

app.get("/api/admin/players/:playerId/transactions", requireAdmin, (req, res) => {
  const txs = walletService.getTransactions(req.params.playerId);
  res.json(txs);
});

app.post("/api/admin/players/:playerId/balance", requireAdmin, (req, res) => {
  const { amount, reason } = req.body || {};
  if (typeof amount !== "number") { res.status(400).json({ error: "amount must be a number" }); return; }
  walletService.adminAdjust(req.params.playerId, amount, "admin_api").then((result) => {
    if (!result.success) { res.status(400).json({ error: result.error }); return; }
    res.json({ success: true, wallet: result.wallet, tx: result.tx });
  });
});

app.post("/api/admin/players/:playerId/freeze", requireAdmin, (req, res) => {
  const { frozen } = req.body || {};
  walletService.freeze(req.params.playerId, Boolean(frozen));
  res.json({ success: true });
});

app.post("/api/admin/players/:playerId/reset", requireAdmin, (req, res) => {
  walletService.reset(req.params.playerId);
  res.json({ success: true });
});

app.get("/api/admin/economy", requireAdmin, (_req, res) => {
  res.json(walletService.getEconomySnapshot());
});

app.get("/api/admin/ads", requireAdmin, (_req, res) => {
  res.json(adService.getAllCampaigns());
});

app.post("/api/admin/ads", requireAdmin, (req, res) => {
  const campaign = adService.createCampaign({ ...req.body, id: crypto.randomUUID(), createdAt: Date.now(), updatedAt: Date.now() });
  res.json(campaign);
});

app.put("/api/admin/ads/:id", requireAdmin, (req, res) => {
  const updated = adService.updateCampaign(req.params.id, req.body);
  if (!updated) { res.status(404).json({ error: "Not found" }); return; }
  res.json(updated);
});

app.delete("/api/admin/ads/:id", requireAdmin, (req, res) => {
  const ok = adService.deleteCampaign(req.params.id);
  res.json({ success: ok });
});

app.get("/api/admin/ads/:id/analytics", requireAdmin, (req, res) => {
  const analytics = adService.getAnalytics(req.params.id);
  if (!analytics) { res.status(404).json({ error: "Not found" }); return; }
  res.json(analytics);
});

app.get("/api/admin/stats", requireAdmin, (_req, res) => {
  const economy = walletService.getEconomySnapshot();
  const stats: AdminDashboardStats = {
    totalPlayers: walletService.getAll().length,
    activeRooms: roomManager.getAllRooms().length,
    totalAds: adService.getAllCampaigns().length,
    runningAds: adService.getActiveCampaigns().length,
    totalCoins: economy.totalCoinsInCirculation,
    coinsCreated: economy.coinsCreated,
    coinsBurned: economy.coinsBurned,
    dailyVolume: economy.dailyVolume,
    liveVisitors: 0,
  };
  res.json(stats);
});

const PORT = process.env.PORT || 3001;
httpServer.listen(PORT, () => {
  console.log(`🎰 ROBIX KING CS Server running on port ${PORT}`);
});
