import { Room, Player, ChatMessage } from "../types";
import { generateRoomCode } from "../lib/utils";
import { walletService } from "./services/WalletService";

export class RoomManager {
  private rooms = new Map<string, Room>();

  createRoom(data: {
    name: string;
    hostId: string;
    maxPlayers: number;
    password?: string;
  }): Room {
    const id = crypto.randomUUID();
    const code = generateRoomCode();

    const room: Room = {
      id,
      code,
      name: data.name,
      hostId: data.hostId,
      players: [],
      maxPlayers: data.maxPlayers,
      isLocked: false,
      password: data.password,
      currentGame: null,
      gameState: null,
      chat: [],
      settings: {
        maxPlayers: data.maxPlayers,
        roundTimer: 30,
        enableEffects: true,
        theme: "dark",
      },
      createdAt: Date.now(),
    };

    this.rooms.set(id, room);
    return room;
  }

  getRoom(id: string): Room | undefined {
    return this.rooms.get(id);
  }

  getRoomByCode(code: string): Room | undefined {
    return Array.from(this.rooms.values()).find((r) => r.code === code);
  }

  joinRoom(roomId: string, player: Player): boolean {
    const room = this.rooms.get(roomId);
    if (!room || room.players.length >= room.maxPlayers) return false;
    room.players.push(player);
    return true;
  }

  leaveRoom(roomId: string, playerId: string): boolean {
    const room = this.rooms.get(roomId);
    if (!room) return false;
    room.players = room.players.filter((p) => p.id !== playerId);

    if (room.hostId === playerId && room.players.length > 0) {
      room.hostId = room.players[0].id;
      room.players[0].isHost = true;
      room.players[0].title = "Room Owner";
    }

    if (room.players.length === 0) {
      this.rooms.delete(roomId);
    }
    return true;
  }

  setPlayerReady(roomId: string, playerId: string, ready: boolean): void {
    const room = this.rooms.get(roomId);
    if (!room) return;
    const player = room.players.find((p) => p.id === playerId);
    if (player) player.isReady = ready;
  }

  setPlayerSpectating(roomId: string, playerId: string, spectating: boolean): void {
    const room = this.rooms.get(roomId);
    if (!room) return;
    const player = room.players.find((p) => p.id === playerId);
    if (player) player.isSpectator = spectating;
  }

  addMessage(roomId: string, message: ChatMessage): void {
    const room = this.rooms.get(roomId);
    if (!room) return;
    room.chat.push(message);
    if (room.chat.length > 100) room.chat.shift();
  }

  updateChips(roomId: string, playerId: string, amount: number): void {
    const room = this.rooms.get(roomId);
    if (!room) return;
    const player = room.players.find((p) => p.id === playerId);
    if (player) player.chips = Math.max(0, player.chips + amount);
  }

  syncPlayerWallet(roomId: string, playerId: string): void {
    const room = this.rooms.get(roomId);
    if (!room) return;
    const player = room.players.find((p) => p.id === playerId);
    const wallet = walletService.get(playerId);
    if (player && wallet) {
      player.chips = wallet.balance;
      player.coinsWon = wallet.coinsWon;
      player.coinsLost = wallet.coinsLost;
      player.totalBets = wallet.totalBets;
      player.totalWins = wallet.totalWins;
      player.totalLosses = wallet.totalLosses;
    }
  }

  getAllRooms(): Room[] {
    return Array.from(this.rooms.values());
  }

  setLocked(roomId: string, locked: boolean): boolean {
    const room = this.rooms.get(roomId);
    if (!room) return false;
    room.isLocked = locked;
    return true;
  }

  deleteRoom(roomId: string): boolean {
    return this.rooms.delete(roomId);
  }

  regenerateCode(roomId: string): string | null {
    const room = this.rooms.get(roomId);
    if (!room) return null;
    room.code = generateRoomCode();
    return room.code;
  }
}
