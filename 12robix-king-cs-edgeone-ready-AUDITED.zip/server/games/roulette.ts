import { RouletteState, Player, Bet } from "../../types";
import { ROULETTE_NUMBERS, pocketColor } from "../../lib/roulette";
import { walletService } from "../services/WalletService";
import { adService } from "../services/AdService";
import { securityService } from "../services/SecurityService";

function wait(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

export class RouletteGame {
  private state: RouletteState;
  private roomId: string;
  private players: Player[];
  private running = false;
  private roundBets = new Map<string, Bet[]>();

  constructor(roomId: string, players: Player[]) {
    this.roomId = roomId;
    this.players = players;
    this.state = {
      status: "waiting",
      countdown: 30,
      round: 1,
      history: [],
      wheelRotation: 0,
      ballPosition: 0,
      winningNumber: null,
      bets: {},
      phase: "betting",
      adPayload: null,
    };
  }

  getState(): RouletteState {
    return { ...this.state };
  }

  async placeBet(playerId: string, bet: Omit<Bet, "playerId">): Promise<boolean> {
    if (this.state.phase !== "betting") return false;
    if (!bet || !bet.amount || bet.amount <= 0) return false;

    const wallet = walletService.get(playerId);
    if (!wallet || wallet.balance < bet.amount) return false;
    if (wallet.frozen) return false;
    if (!securityService.checkRateLimit(`bet:${playerId}`, 5, 1000)) return false;

    const deduct = await walletService.placeBet(playerId, bet.amount, "neon-roulette", this.state.round);
    if (!deduct.success || !deduct.tx) return false;

    if (!this.roundBets.has(playerId)) this.roundBets.set(playerId, []);
    this.roundBets.get(playerId)!.push({ ...bet, playerId });

    if (!this.state.bets[playerId]) this.state.bets[playerId] = [];
    this.state.bets[playerId].push({ ...bet, playerId });

    const player = this.players.find(p => p.id === playerId);
    if (player && deduct.wallet) player.chips = deduct.wallet.balance;

    return true;
  }

  stop(): void {
    this.running = false;
  }

  async start(onUpdate: (state: RouletteState) => void, onRoundStart?: () => void): Promise<void> {
    this.running = true;

    while (this.running) {
      this.state.status = "countdown";
      this.state.phase = "betting";
      this.state.bets = {};
      this.state.winningNumber = null;
      this.state.results = undefined;
      this.state.adPayload = null;
      this.roundBets.clear();
      onRoundStart?.();
      onUpdate(this.getState());

      for (let i = 30; i >= 0; i--) {
        if (!this.running) break;
        this.state.countdown = i;
        onUpdate(this.getState());
        await wait(1000);
      }
      if (!this.running) break;

      this.state.phase = "spinning";
      this.state.status = "playing";
      this.state.adPayload = adService.selectAd("neon-roulette", { playerId: this.players[0]?.id });
      onUpdate(this.getState());

      const winningIndex = Math.floor(Math.random() * ROULETTE_NUMBERS.length);
      const winningNumber = ROULETTE_NUMBERS[winningIndex];
      const spins = 5 + Math.random() * 3;
      const finalRotation = spins * 360 + (winningIndex / ROULETTE_NUMBERS.length) * 360;

      this.state.wheelRotation = finalRotation;
      this.state.winningNumber = winningNumber;

      await wait(6000);

      this.state.phase = "result";
      const payouts = await this.calculatePayouts(winningNumber);
      this.state.results = { winningNumber, payouts, isRed: pocketColor(winningNumber) === "red" };
      this.state.history.push({ round: this.state.round, winningNumber, timestamp: Date.now() });
      onUpdate(this.getState());

      await wait(10000);
      this.state.round += 1;
    }

    this.state.status = "ended";
    onUpdate(this.getState());
  }

  private async calculatePayouts(winningNumber: number): Promise<Record<string, number>> {
    const payouts: Record<string, number> = {};
    const color = pocketColor(winningNumber);
    const isEven = winningNumber !== 0 && winningNumber % 2 === 0;
    const isLow = winningNumber >= 1 && winningNumber <= 18;
    const dozen = winningNumber === 0 ? 0 : Math.ceil(winningNumber / 12);
    const column = winningNumber === 0 ? 0 : ((winningNumber - 1) % 3) + 1;

    for (const playerId of Array.from(this.roundBets.keys())) {
      const bets = this.roundBets.get(playerId)!;
      let totalWin = 0;
      for (const bet of bets) {
        switch (bet.type) {
          case "straight":
            if (Number(bet.value) === winningNumber) totalWin += bet.amount * 36;
            break;
          case "color":
            if (bet.value === color) totalWin += bet.amount * 2;
            break;
          case "even-odd":
            if ((bet.value === "even" && isEven) || (bet.value === "odd" && !isEven && winningNumber !== 0)) totalWin += bet.amount * 2;
            break;
          case "high-low":
            if ((bet.value === "low" && isLow) || (bet.value === "high" && !isLow && winningNumber !== 0)) totalWin += bet.amount * 2;
            break;
          case "dozen":
            if (Number(bet.value) === dozen) totalWin += bet.amount * 3;
            break;
          case "column":
            if (Number(bet.value) === column) totalWin += bet.amount * 3;
            break;
        }
      }
      payouts[playerId] = totalWin;

      if (totalWin > 0) {
        const reward = await walletService.reward(playerId, totalWin, "neon-roulette", this.state.round, { winningNumber });
        if (reward.success && reward.wallet) {
          const player = this.players.find(p => p.id === playerId);
          if (player) player.chips = reward.wallet.balance;
        }
      }
    }

    return payouts;
  }
}
