import { CoinFlipState, Player, Bet } from "../../types";
import { walletService } from "../services/WalletService";
import { adService } from "../services/AdService";
import { securityService } from "../services/SecurityService";

function wait(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

export class CoinFlipGame {
  private state: CoinFlipState;
  private roomId: string;
  private players: Player[];
  private running = false;
  private roundBets = new Map<string, Bet[]>();
  private roundResult: "heads" | "tails" | null = null;

  constructor(roomId: string, players: Player[]) {
    this.roomId = roomId;
    this.players = players;
    this.state = {
      status: "waiting",
      countdown: 12,
      round: 1,
      history: [],
      phase: "betting",
      bets: {},
      coinResult: null,
      adPayload: null,
    };
  }

  getState(): CoinFlipState {
    return { ...this.state };
  }

  async placeBet(playerId: string, bet: Omit<Bet, "playerId">): Promise<boolean> {
    if (this.state.phase !== "betting") return false;
    if (!bet || !bet.amount || bet.amount <= 0) return false;
    if (bet.type !== "coinflip" || (bet.value !== "heads" && bet.value !== "tails")) return false;

    const wallet = walletService.get(playerId);
    if (!wallet || wallet.balance < bet.amount) return false;
    if (wallet.frozen) return false;
    if (!securityService.checkRateLimit(`bet:${playerId}`, 5, 1000)) return false;

    const deduct = await walletService.placeBet(playerId, bet.amount, "coin-flip", this.state.round);
    if (!deduct.success || !deduct.tx) return false;

    if (!this.roundBets.has(playerId)) this.roundBets.set(playerId, []);
    this.roundBets.get(playerId)!.push({ ...bet, playerId });

    if (!this.state.bets[playerId]) this.state.bets[playerId] = [];
    this.state.bets[playerId].push({ ...bet, playerId });

    const player = this.players.find(p => p.id === playerId);
    if (player && deduct.wallet) player.chips = deduct.wallet.balance;

    return true;
  }

  stop(): void {
    this.running = false;
  }

  async start(onUpdate: (state: CoinFlipState) => void, onRoundStart?: () => void): Promise<void> {
    this.running = true;

    while (this.running) {
      this.state.status = "countdown";
      this.state.phase = "betting";
      this.state.bets = {};
      this.state.coinResult = null;
      this.state.results = undefined;
      this.state.adPayload = null;
      this.roundBets.clear();

      onRoundStart?.();
      onUpdate(this.getState());

      for (let i = 12; i >= 0; i--) {
        if (!this.running) break;
        this.state.countdown = i;
        onUpdate(this.getState());
        await wait(1000);
      }
      if (!this.running) break;

      this.roundResult = Math.random() < 0.5 ? "heads" : "tails";
      this.state.coinResult = this.roundResult;
      this.state.adPayload = adService.selectAd("coin-flip", { playerId: this.players[0]?.id });

      this.state.phase = "flipping";
      this.state.status = "playing";
      onUpdate(this.getState());

      await wait(2500);

      this.state.phase = "result";
      const payouts = await this.calculatePayouts(this.roundResult);
      this.state.results = { result: this.roundResult, payouts };
      this.state.history.push({ round: this.state.round, result: this.roundResult, timestamp: Date.now() });
      onUpdate(this.getState());

      await wait(5000);
      this.state.round += 1;
    }

    this.state.status = "ended";
    onUpdate(this.getState());
  }

  private async calculatePayouts(result: "heads" | "tails"): Promise<Record<string, number>> {
    const payouts: Record<string, number> = {};

    for (const playerId of Array.from(this.roundBets.keys())) {
      const bets = this.roundBets.get(playerId)!;
      let totalWin = 0;
      for (const bet of bets) {
        if (bet.value === result) totalWin += bet.amount * 2;
      }
      payouts[playerId] = totalWin;

      if (totalWin > 0) {
        const reward = await walletService.reward(playerId, totalWin, "coin-flip", this.state.round, { result });
        if (reward.success && reward.wallet) {
          const player = this.players.find(p => p.id === playerId);
          if (player) player.chips = reward.wallet.balance;
        }
      }
    }

    return payouts;
  }
}
