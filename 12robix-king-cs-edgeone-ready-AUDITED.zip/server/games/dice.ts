import { DiceState, Player, Bet } from "../../types";
import { walletService } from "../services/WalletService";
import { adService } from "../services/AdService";
import { securityService } from "../services/SecurityService";

function wait(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

const EXACT_PAYOUTS: Record<number, number> = {
  2: 30, 3: 15, 4: 10, 5: 8, 6: 6, 7: 5, 8: 6, 9: 8, 10: 10, 11: 15, 12: 30,
};

export class DiceGame {
  private state: DiceState;
  private roomId: string;
  private players: Player[];
  private running = false;
  private roundBets = new Map<string, Bet[]>();
  private diceResult: [number, number] | null = null;

  constructor(roomId: string, players: Player[]) {
    this.roomId = roomId;
    this.players = players;
    this.state = {
      status: "waiting",
      countdown: 15,
      round: 1,
      history: [],
      phase: "betting",
      bets: {},
      dice: null,
      total: null,
      adPayload: null,
    };
  }

  getState(): DiceState {
    return { ...this.state };
  }

  async placeBet(playerId: string, bet: Omit<Bet, "playerId">): Promise<boolean> {
    if (this.state.phase !== "betting") return false;
    if (!bet || !bet.amount || bet.amount <= 0) return false;

    const validRange = bet.type === "dice-range" && (bet.value === "low" || bet.value === "high");
    const validExact = bet.type === "dice-exact" && typeof bet.value === "number" && bet.value >= 2 && bet.value <= 12;
    if (!validRange && !validExact) return false;

    const wallet = walletService.get(playerId);
    if (!wallet || wallet.balance < bet.amount) return false;
    if (wallet.frozen) return false;
    if (!securityService.checkRateLimit(`bet:${playerId}`, 5, 1000)) return false;

    const deduct = await walletService.placeBet(playerId, bet.amount, "dice", this.state.round);
    if (!deduct.success || !deduct.tx) return false;

    if (!this.roundBets.has(playerId)) this.roundBets.set(playerId, []);
    this.roundBets.get(playerId)!.push({ ...bet, playerId });

    if (!this.state.bets[playerId]) this.state.bets[playerId] = [];
    this.state.bets[playerId].push({ ...bet, playerId });

    const player = this.players.find(p => p.id === playerId);
    if (player && deduct.wallet) player.chips = deduct.wallet.balance;

    return true;
  }

  stop(): void {
    this.running = false;
  }

  async start(onUpdate: (state: DiceState) => void, onRoundStart?: () => void): Promise<void> {
    this.running = true;

    while (this.running) {
      this.state.status = "countdown";
      this.state.phase = "betting";
      this.state.bets = {};
      this.state.dice = null;
      this.state.total = null;
      this.state.results = undefined;
      this.state.adPayload = null;
      this.roundBets.clear();

      onRoundStart?.();
      onUpdate(this.getState());

      for (let i = 15; i >= 0; i--) {
        if (!this.running) break;
        this.state.countdown = i;
        onUpdate(this.getState());
        await wait(1000);
      }
      if (!this.running) break;

      const die1 = 1 + Math.floor(Math.random() * 6);
      const die2 = 1 + Math.floor(Math.random() * 6);
      const total = die1 + die2;
      this.diceResult = [die1, die2];

      this.state.dice = [die1, die2];
      this.state.total = total;
      this.state.adPayload = adService.selectAd("dice", { playerId: this.players[0]?.id });

      this.state.phase = "rolling";
      this.state.status = "playing";
      onUpdate(this.getState());

      await wait(2200);

      this.state.phase = "result";
      const payouts = await this.calculatePayouts(total);
      this.state.results = { dice: [die1, die2] as [number, number], total, payouts };
      this.state.history.push({ round: this.state.round, dice: [die1, die2], total, timestamp: Date.now() });
      onUpdate(this.getState());

      await wait(5000);
      this.state.round += 1;
    }

    this.state.status = "ended";
    onUpdate(this.getState());
  }

  private async calculatePayouts(total: number): Promise<Record<string, number>> {
    const payouts: Record<string, number> = {};
    const isLow = total >= 2 && total <= 6;
    const isHigh = total >= 8 && total <= 12;

    for (const playerId of Array.from(this.roundBets.keys())) {
      const bets = this.roundBets.get(playerId)!;
      let totalWin = 0;
      for (const bet of bets) {
        if (bet.type === "dice-range") {
          if ((bet.value === "low" && isLow) || (bet.value === "high" && isHigh)) {
            totalWin += bet.amount * 2;
          }
        } else if (bet.type === "dice-exact" && Number(bet.value) === total) {
          totalWin += bet.amount * (EXACT_PAYOUTS[total] ?? 6);
        }
      }
      payouts[playerId] = totalWin;

      if (totalWin > 0) {
        const reward = await walletService.reward(playerId, totalWin, "dice", this.state.round, { total });
        if (reward.success && reward.wallet) {
          const player = this.players.find(p => p.id === playerId);
          if (player) player.chips = reward.wallet.balance;
        }
      }
    }

    return payouts;
  }
}
