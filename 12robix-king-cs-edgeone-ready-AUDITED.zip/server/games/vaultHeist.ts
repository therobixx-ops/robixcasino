import { VaultHeistState, Player, Vault, AIEvent } from "../../types";
import { shuffle } from "../../lib/utils";
import { walletService } from "../services/WalletService";
import { adService } from "../services/AdService";

function wait(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

const VAULT_TEMPLATES: Omit<Vault, "id">[] = [
  { name: "Bronze Vault", emoji: "🥉", baseReward: 500, risk: 0.1, isGolden: false, isGhost: false },
  { name: "Silver Vault", emoji: "🥈", baseReward: 1000, risk: 0.2, isGolden: false, isGhost: false },
  { name: "Gold Vault", emoji: "🥇", baseReward: 2000, risk: 0.3, isGolden: false, isGhost: false },
  { name: "Diamond Vault", emoji: "💎", baseReward: 5000, risk: 0.5, isGolden: false, isGhost: false },
  { name: "Mystery Vault", emoji: "❓", baseReward: 1500, risk: 0.4, isGolden: false, isGhost: false },
];

const AI_EVENTS: AIEvent[] = [
  { id: "golden", name: "Golden Vault", description: "One vault turns to gold! 3x rewards!", effect: "golden_vault", multiplier: 3 },
  { id: "lucky", name: "Lucky Vault", description: "Lucky draw! All rewards doubled!", effect: "lucky", multiplier: 2 },
  { id: "lockdown", name: "Security Lockdown", description: "Security activated! Risk increased!", effect: "lockdown", multiplier: 0.5 },
  { id: "double", name: "Double Reward", description: "Double or nothing! Rewards x2 but risk x2!", effect: "double", multiplier: 2 },
  { id: "ghost", name: "Ghost Vault", description: "A ghost vault appears! Empty but safe!", effect: "ghost", multiplier: 1 },
  { id: "mystery", name: "Mystery Chest", description: "Random rewards for everyone!", effect: "mystery", multiplier: 1.5 },
];

export class VaultHeistGame {
  private state: VaultHeistState;
  private roomId: string;
  private players: Player[];
  private running = false;

  constructor(roomId: string, players: Player[]) {
    this.roomId = roomId;
    this.players = players;
    this.state = {
      status: "waiting",
      countdown: 20,
      round: 1,
      history: [],
      phase: "choosing",
      vaults: this.generateVaults(),
      playerChoices: {},
      aiEvent: null,
      rewards: {},
      adPayload: null,
    };
  }

  getState(): VaultHeistState {
    return { ...this.state };
  }

  makeChoice(playerId: string, vaultId: string): void {
    if (this.state.phase !== "choosing") return;
    this.state.playerChoices[playerId] = vaultId;
  }

  stop(): void {
    this.running = false;
  }

  async start(onUpdate: (state: VaultHeistState) => void, onRoundStart?: () => void): Promise<void> {
    this.running = true;

    while (this.running) {
      this.state.status = "countdown";
      this.state.phase = "choosing";
      this.state.vaults = this.generateVaults();
      this.state.playerChoices = {};
      this.state.aiEvent = null;
      this.state.rewards = {};
      this.state.adPayload = null;
      onRoundStart?.();
      onUpdate(this.getState());

      for (let i = 20; i >= 0; i--) {
        if (!this.running) break;
        this.state.countdown = i;
        onUpdate(this.getState());
        await wait(1000);
        if (Object.keys(this.state.playerChoices).length === this.players.length) break;
      }
      if (!this.running) break;

      this.state.phase = "locked";
      this.state.status = "playing";
      onUpdate(this.getState());
      await wait(2000);

      this.state.phase = "event";
      this.state.aiEvent = AI_EVENTS[Math.floor(Math.random() * AI_EVENTS.length)];
      this.state.adPayload = adService.selectAd("vault-heist", { playerId: this.players[0]?.id });
      onUpdate(this.getState());
      await wait(3000);

      this.state.phase = "revealing";
      this.calculateRewards();
      onUpdate(this.getState());
      await wait(4000);

      this.state.phase = "result";
      await this.applyRewards();
      this.state.history.push({ round: this.state.round, rewards: { ...this.state.rewards }, timestamp: Date.now() });
      onUpdate(this.getState());

      await wait(5000);
      this.state.round += 1;
    }

    this.state.status = "ended";
    onUpdate(this.getState());
  }

  private generateVaults(): Vault[] {
    const shuffled = shuffle([...VAULT_TEMPLATES]);
    return shuffled.slice(0, 4).map((v, i) => ({ ...v, id: `vault-${i}` }));
  }

  private calculateRewards(): void {
    const event = this.state.aiEvent;
    const multiplier = event?.multiplier ?? 1;

    for (const [playerId, vaultId] of Object.entries(this.state.playerChoices)) {
      const vault = this.state.vaults.find(v => v.id === vaultId);
      if (!vault) continue;

      const roll = Math.random();
      if (roll < vault.risk) {
        this.state.rewards[playerId] = 0;
      } else {
        const base = vault.isGolden ? vault.baseReward * 3 : vault.baseReward;
        this.state.rewards[playerId] = Math.floor(base * multiplier);
      }
    }
  }

  private async applyRewards(): Promise<void> {
    for (const [playerId, amount] of Object.entries(this.state.rewards)) {
      if (amount > 0) {
        const reward = await walletService.reward(playerId, amount, "vault-heist", this.state.round, { vaultChoice: this.state.playerChoices[playerId] });
        if (reward.success && reward.wallet) {
          const player = this.players.find(p => p.id === playerId);
          if (player) player.chips = reward.wallet.balance;
        }
      }
    }
  }
}
