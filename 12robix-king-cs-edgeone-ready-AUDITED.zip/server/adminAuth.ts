import crypto from "crypto";

/**
 * Admin authentication for the single-administrator model described in the
 * product spec:
 *   - Exactly one administrator.
 *   - Credentials live in environment variables, never in code.
 *   - The server verifies every admin request (REST and Socket.IO).
 *
 * This intentionally avoids adding a new dependency (like jsonwebtoken) —
 * it's a small HMAC-signed token built on Node's built-in `crypto` module.
 */

const SESSION_TTL_MS = 12 * 60 * 60 * 1000; // 12 hours

function getSecret(): string {
  const secret = process.env.ADMIN_SESSION_SECRET;
  if (!secret) {
    // Fail loudly rather than silently signing tokens with a guessable
    // default — admin auth is only as strong as this secret.
    throw new Error(
      "ADMIN_SESSION_SECRET is not set. Add it to your .env file before starting the server."
    );
  }
  return secret;
}

function sign(payload: string): string {
  return crypto.createHmac("sha256", getSecret()).update(payload).digest("hex");
}

/** Constant-time string compare to avoid timing attacks on credential/token checks. */
function safeEqual(a: string, b: string): boolean {
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

/**
 * Verifies a username/password pair against the environment-configured
 * admin credentials. There is exactly one administrator account.
 */
export function verifyAdminCredentials(username: string, password: string): boolean {
  const expectedUser = process.env.ADMIN_USERNAME;
  const expectedPass = process.env.ADMIN_PASSWORD;
  if (!expectedUser || !expectedPass) {
    throw new Error(
      "ADMIN_USERNAME / ADMIN_PASSWORD are not set. Add them to your .env file before starting the server."
    );
  }
  if (typeof username !== "string" || typeof password !== "string") return false;
  return safeEqual(username, expectedUser) && safeEqual(password, expectedPass);
}

/** Issues a signed, time-limited admin session token. */
export function createAdminToken(): string {
  const expiresAt = Date.now() + SESSION_TTL_MS;
  const payload = `admin:${expiresAt}`;
  const signature = sign(payload);
  return Buffer.from(`${payload}:${signature}`).toString("base64url");
}

/** Verifies a token was issued by this server and hasn't expired. */
export function verifyAdminToken(token: string | undefined | null): boolean {
  if (!token) return false;
  try {
    const decoded = Buffer.from(token, "base64url").toString("utf8");
    const lastColon = decoded.lastIndexOf(":");
    const payload = decoded.slice(0, lastColon);
    const signature = decoded.slice(lastColon + 1);
    const expected = sign(payload);
    if (!safeEqual(signature, expected)) return false;

    const [, expiresAtStr] = payload.split(":");
    const expiresAt = Number(expiresAtStr);
    if (!Number.isFinite(expiresAt) || Date.now() > expiresAt) return false;

    return true;
  } catch {
    return false;
  }
}
