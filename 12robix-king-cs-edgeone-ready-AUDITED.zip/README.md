# ROBIX KING CS 🎰

> A premium private multiplayer party game platform.  
> **Royal Chips are virtual entertainment credits with no cash value.**  
> **Not a casino. Not gambling. Just friends having fun.**

---

## What is ROBIX KING CS?

ROBIX KING CS is a browser-based private social gaming lounge where friends play together using virtual Royal Chips. Like joining a Discord call — but with games.

**The Experience:**
- 🔗 **Join via link** — `robixkingcs.app/r/BG72XP`. No registration. No signup. Just play.
- 🎮 **Two original games** — Neon Roulette & Vault Heist
- 😂 **Gen-Z social features** — Pranks, reactions, confetti, auto-GIFs
- 🤖 **AI Host** — Fun commentary without predicting winners
- 🎨 **6 room themes** — Midnight Gold, Cyber Neon, Emerald City, Ruby Lounge, Deep Ocean, Disco Fever
- 🔊 **Synthesized audio** — Web Audio API engine, no external files needed
- 📱 **PWA** — Works offline after first load, installable on homescreen

**Key Principles:**
- 🚫 **No real money** — Royal Chips cannot be purchased, redeemed, withdrawn, or exchanged for cash
- 🔒 **Private only** — Invite-only rooms, no public lobbies
- ⚡ **AAA feel** — 60fps animations, glassmorphism, cinematic transitions
- 🎮 **Social first** — Games designed for laughs and interaction

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Next.js 14, React 18, TypeScript, Tailwind CSS, Framer Motion |
| Realtime | Socket.IO (WebSocket + fallback) |
| Backend | Node.js, Express |
| State | In-memory only — no database. Room data is deleted when the room ends. |
| Audio | Web Audio API (synthesized, zero external assets) |
| PWA | Service Worker, Manifest, offline caching |
| Deployment | Vercel, EdgeOne, Cloudflare Pages, Netlify |

---

## Quick Start

```bash
# 1. Extract the project
cd robix-king-cs

# 2. Install dependencies
npm install

# 3. Start the dev server (runs Next.js + Socket.IO concurrently)
npm run dev

# 4. Open http://localhost:3000
```

The setup runs two processes:
- **Next.js** on `http://localhost:3000` — frontend
- **Socket.IO server** on `http://localhost:3001` — multiplayer backend

---

## Discord-Style Invite Flow

```
1. Host creates room → gets code BG72XP
2. Shares: robixkingcs.app/r/BG72XP
3. Friends click link → enter name → instantly in room
4. Play. Laugh. Leave. No accounts.
```

---

## Games

### 🎡 Neon Roulette
European roulette with realistic wheel physics, smooth ball animation, and premium lighting.
- **Bets:** Straight (35:1), Red/Black (2:1), Even/Odd (2:1), High/Low (2:1)
- **Features:** Countdown timer, bet history, celebration animations, synthesized spin sound
- **Server-authoritative:** All spins determined server-side

### 🏦 Vault Heist
Original social strategy game. Players secretly choose vaults, then an AI event modifies the round.
- **AI Events:** Golden Vault (3x), Lucky Draw (2x), Security Lockdown (0.5x), Double Reward, Ghost Vault, Mystery Chest
- **Risk/Reward:** Higher vaults = bigger payouts but higher bust chance
- **Social:** Bluff, deduce, celebrate together

---

## Gen-Z Social Features

| Feature | Description |
|---------|-------------|
| 😂 Spam Emoji | Flood chat with reactions |
| 💀 "Bro got cooked" | Auto reaction when someone loses big |
| 🔥 "That was lucky" | Quick-fire celebration button |
| 👀 "Everyone saw that" | Call out a bad play |
| 🎉 Confetti | Full-screen particle burst |
| 💣 Fake chip explosion | Visual prank, no balance change |
| 🍅 Tomato throw | Classic throw at a player |
| 🧻 Toilet paper | Cover screen in TP |
| 💨 Smoke bomb | Screen fog effect |
| 🌈 Rainbow table | Colorful room overlay |
| ⚡ Lightning strike | Flash effect |
| 🪩 Disco mode | Pulsing lights |
| 🎭 Troll mask | Giant mask popup |
| 💯 Win flex | MVP celebration animation |
| 🏆 MVP celebration | Trophy animation for top player |

**All pranks are visual only. They never change game outcomes or balances.**

---

## AI Host Commentary

The AI Host acts like a fun casino announcer — but never predicts winners or manipulates randomness.

**Examples:**
- "Rahul is on a 5-round streak. Unstoppable."
- "Ronit just doubled his Royal Chips. Big W."
- "Three players picked the same vault. Bold or broke?"
- "Someone is bluffing... I can feel it."
- "Nobody trusted the Golden Vault this round."
- "The wheel spoke: 17. Red takes it."

**Triggers:**
- Player joins/leaves
- Win streaks (3+)
- Big wins (1000+ chips)
- Vault consensus (multiple players same vault)
- AI events (Golden Vault, Lockdown, etc.)
- Comebacks (winning after 3+ losses in a row)
- Game start/end

### AI Room Events

Purely cosmetic, room-wide moments the AI fires occasionally to keep the atmosphere alive — never touches odds, bets, or payouts:

| Event | Trigger tendency |
|-------|-------------------|
| 🪙 Gold Rain | Big wins (5,000+ chips) |
| 🎆 Fireworks | Big wins, or right after a comeback |
| 🔫 Laser Show | Hot streaks (4+ wins) |
| ⚡ Lightning Storm | Hot streaks |
| 🎊 Confetti Burst | Comebacks, or periodically |
| 🪙 Floating Coins | Periodically (every ~4th round) |
| 😂 Emoji Storm | Periodically |
| 🌐 Holographic Overlay | Periodically |

These roll with real odds (not every eligible moment fires) so they stay a surprise rather than constant noise.

### Session Recap

The host can hit **End Session & Get Recap** at any time. The AI Host reviews the whole session's round history and generates a short narrated summary — MVP, biggest single win, hottest streak, and final chip standings — shown to everyone in the room.

---

## Session Leaderboard, Round History & Spectator Mode

- **Leaderboard** — live chip standings for the room, updated after every round, with the session's biggest single win called out.
- **Round History / Replay** — every round played is logged (winning number or vault, payouts, any AI event that fired). Tapping a past round opens a lightweight replay of that result — a fast recreation, not a full physics re-simulation.
- **Spectator Mode** — any player can toggle "Spectate" to watch without betting or choosing vaults. Spectators are excluded from the ready-check gate so they never block the host from starting a round.

---

## Room Themes

| Theme | Vibe |
|-------|------|
| Midnight Gold | Classic luxury (default) |
| Cyber Neon | Tokyo nights, pink/cyan |
| Emerald City | Green velvet, gold accents |
| Ruby Lounge | Red carpet, high stakes |
| Deep Ocean | Underwater blue/purple |
| Disco Fever | Saturday night, yellow/pink |

Themes change the entire room's color palette in real-time.

---

## Audio Engine

Zero external audio files. All sounds synthesized in-browser via Web Audio API:

| Sound | Trigger |
|-------|---------|
| Chip click | Placing bet |
| Win arpeggio | Winning round |
| Lose descent | Busting |
| Wheel spin | 4-second white noise sweep |
| Vault lock | Heavy mechanical thud |
| Prank | Context-aware tone |
| UI click | Every button press |

---

## Performance

| Target | Status |
|--------|--------|
| 60 FPS | ✅ Framer Motion + GPU compositing |
| <2s first load | ✅ Code splitting, lazy loading |
| 4G compatible | ✅ Minimal bundle, no heavy assets |
| Old Android | ✅ No WebGL required |
| Safari | ✅ Full support |
| Edge | ✅ Full support |
| PWA | ✅ Service worker + manifest |
| Offline | ✅ Assets cached after first visit |

---

## Multiplayer Architecture

```
┌─────────────┐      WebSocket       ┌─────────────┐
│   Client    │ ◄──────────────────► │   Server    │
│  (Next.js)  │   Socket.IO Events   │  (Express)  │
└─────────────┘                      └──────┬──────┘
                                            │
                                    ┌───────┴───────┐
                                    │  RoomManager  │
                                    │  Game Engines │
                                    │  AICommentary │
                                    │   SQLite DB   │
                                    └───────────────┘
```

**Security:**
- Server-authoritative game state
- Rate limiting (10 msg/sec)
- Input validation on all events
- No client-side balance editing
- Secure random room IDs

---

## Admin Controls (Room Owner)

| Command | Action |
|---------|--------|
| Kick | Remove player |
| Mute | Disable chat |
| Gift Chips | Add Royal Chips |
| Remove Chips | Deduct Royal Chips |
| Effects | 12 visual pranks |
| Themes | 6 room color schemes |
| Settings | Max players, timer, password |

**The game itself remains fair. Outcomes are server-randomized.**

---

## Deployment

### Vercel (Frontend)

1. Push to GitHub
2. Import to Vercel
3. Set `NEXT_PUBLIC_SOCKET_URL` to your Socket.IO server

### Socket.IO Server (Any Node.js host)

```bash
# Build
npm run build

# Start server only
npm run server
```

Deploy to Railway, Render, Fly.io, or AWS ECS.

### PWA Installation

Users can "Add to Home Screen" on iOS/Android. The app works offline after first load.

---

## Project Structure

```
robix-king-cs/
├── app/                    # Next.js App Router
│   ├── layout.tsx          # PWA manifest, service worker registration
│   ├── page.tsx            # Lobby with invite code support
│   └── room/[id]/          # Dynamic room pages
├── components/
│   ├── IntroAnimation.tsx  # Cinematic 4.5s intro
│   ├── Lobby.tsx           # Create/Join with avatar picker
│   ├── Room.tsx            # Main shell (audio, themes, pranks, AI host)
│   ├── PlayerCard.tsx      # Player profiles with prank buttons
│   ├── Chat.tsx            # Real-time chat + quick reactions
│   ├── NeonRoulette.tsx    # Full roulette UI
│   ├── VaultHeist.tsx      # Vault heist UI
│   └── effects/
│       ├── PrankOverlay.tsx  # 14 visual prank effects
│       └── AIHost.tsx        # AI commentary overlay
├── server/
│   ├── index.ts            # Express + Socket.IO entry
│   ├── rooms.ts            # Room lifecycle manager
│   ├── aiCommentary.ts     # AI host personality engine
│   └── games/
│       ├── roulette.ts     # European roulette logic
│       └── vaultHeist.ts   # Vault heist + AI events
├── hooks/
│   ├── useSocket.ts        # Socket.IO state management
│   └── useAudio.ts         # Web Audio API synthesizer
├── lib/
│   ├── utils.ts            # Helpers
│   └── themes.ts           # 6 room themes
├── types/                  # Shared TypeScript
├── styles/                 # Tailwind + custom CSS
└── public/
    ├── manifest.json       # PWA manifest
    └── sw.js               # Service worker
```

---

## Environment Variables

```bash
NEXT_PUBLIC_SOCKET_URL=http://localhost:3001

# Single-administrator login for the protected /admin dashboard
ADMIN_USERNAME=change-me
ADMIN_PASSWORD=change-me-too

# Long random string used to sign admin session tokens (openssl rand -hex 32)
ADMIN_SESSION_SECRET=change-me-to-a-long-random-string
```

Copy `.env.example` to `.env` and fill these in before starting the server —
without `ADMIN_USERNAME`/`ADMIN_PASSWORD`/`ADMIN_SESSION_SECRET`, admin login
will fail with a clear error rather than falling back to a default.

## Admin Dashboard (`/admin`)

Visit `/admin` and sign in with the credentials above. This is the single
administrator account described in the spec — separate from the "room host"
controls a friend gets automatically when they create a room. Every
`/api/admin/*` request is verified server-side against a signed, time-limited
session token; there is no client-side-only gate. From here you can see every
active room and, regardless of who's hosting it, lock it, kick/ban a player,
gift or remove chips, broadcast an announcement, regenerate its invite link,
or end it outright.

---

## Customization

### Adding a New Game

1. Create logic in `server/games/yourGame.ts`
2. Create UI in `components/YourGame.tsx`
3. Add type to `types/index.ts`
4. Wire in `server/index.ts` and `components/Room.tsx`

### Adding a New Prank

1. Add type to `components/effects/PrankOverlay.tsx`
2. Add button to `components/Room.tsx` admin panel
3. Add sound to `hooks/useAudio.ts`

### Adding a New Theme

1. Add to `lib/themes.ts`
2. Automatically available in room settings

---

## Legal & Compliance

**ROBIX KING CS is NOT a gambling website.**

- Royal Chips are virtual entertainment credits only
- They cannot be purchased, redeemed, withdrawn, or exchanged for real money
- No payment gateways, deposits, withdrawals, or cryptocurrency
- No real-money prizes
- Players must be 18+
- This is a private social platform for invited friends

---

## License

Private use only. See LICENSE for details.

---

Built with 💎 by the ROBIX KING CS Engineering Team
