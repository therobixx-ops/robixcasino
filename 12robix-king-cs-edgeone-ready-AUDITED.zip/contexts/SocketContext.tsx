"use client";

import { createContext, useContext, useEffect, useRef, useState, useCallback, type ReactNode } from "react";
import { io, Socket } from "socket.io-client";
import type {
  ClientToServerEvents,
  ServerToClientEvents,
  Room,
  GameState,
  ChatMessage,
  PartyInvite,
  Bet,
  GameType,
  RoundRecord,
  SessionSummary,
} from "../types";
import { buildSoloRoom, runSoloRoulette, runSoloVaultHeist, runSoloCoinFlip, runSoloDice, pickRandomGameType } from "../lib/soloEngine";

const SOCKET_URL = process.env.NEXT_PUBLIC_SOCKET_URL || "http://localhost:3001";

// If the realtime server doesn't answer within this window (e.g. it isn't
// deployed anywhere, or NEXT_PUBLIC_SOCKET_URL is unset), give up waiting
// instead of spinning on "Loading..." forever, and surface a clear error.
const ACK_TIMEOUT_MS = 8000;

function withTimeout<T>(executor: (resolve: (v: T) => void, reject: (e: Error) => void) => void): Promise<T> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      reject(new Error("Couldn't reach the game server. Check your connection, or try Solo Mode instead."));
    }, ACK_TIMEOUT_MS);
    executor(
      (v) => {
        clearTimeout(timer);
        resolve(v);
      },
      (e) => {
        clearTimeout(timer);
        reject(e);
      }
    );
  });
}

export interface SocketContextValue {
  socket: Socket<ServerToClientEvents, ClientToServerEvents> | null;
  isConnected: boolean;
  myId: string | null;
  room: Room | null;
  gameState: GameState | null;
  messages: ChatMessage[];
  error: string | null;
  clearError: () => void;
  aiAnnouncement: { text: string; type: string } | null;
  activeEffect: { effect: string; targetId?: string } | null;
  typingPlayers: Array<{ playerId: string; playerName: string }>;
  partyInvites: PartyInvite[];
  sessionRounds: RoundRecord[];
  sessionSummary: SessionSummary | null;
  clearSessionSummary: () => void;
  endSession: () => void;
  setSpectating: (spectating: boolean) => void;
  createRoom: (data: { name: string; maxPlayers: number; password?: string }) => Promise<Room>;
  joinRoom: (data: { code: string; name: string; avatar: string }) => Promise<Room | null>;
  leaveRoom: () => void;
  isSolo: boolean;
  startSolo: (data: { name: string; avatar: string; roomName?: string; totalPlayers: number }) => Room;
  setReady: (ready: boolean) => void;
  sendMessage: (text: string, type?: ChatMessage["type"]) => void;
  startTyping: () => void;
  stopTyping: () => void;
  startGame: (gameType?: GameType) => void;
  stopGame: () => void;
  placeBet: (bet: Omit<Bet, "playerId">) => void;
  chooseVault: (choice: string) => void;
  triggerPrank: (effect: string, targetId?: string) => void;
  adminKick: (playerId: string) => void;
  adminBan: (playerId: string) => void;
  adminMute: (playerId: string) => void;
  adminChips: (playerId: string, amount: number) => void;
  adminBroadcast: (message: string) => void;
  adminTimer: (seconds: number) => void;
  sendInvite: (friendId: string, roomCode: string) => void;
  acceptInvite: (inviteId: string) => void;
}

const SocketContext = createContext<SocketContextValue | null>(null);

export function SocketProvider({ children }: { children: ReactNode }) {
  const socketRef = useRef<Socket<ServerToClientEvents, ClientToServerEvents> | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [myId, setMyId] = useState<string | null>(null);
  const [room, setRoom] = useState<Room | null>(null);
  const [gameState, setGameState] = useState<GameState | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [aiAnnouncement, setAiAnnouncement] = useState<{ text: string; type: string } | null>(null);
  const [activeEffect, setActiveEffect] = useState<{ effect: string; targetId?: string } | null>(null);
  const [typingPlayers, setTypingPlayers] = useState<Array<{ playerId: string; playerName: string }>>([]);
  const [partyInvites, setPartyInvites] = useState<PartyInvite[]>([]);
  const [sessionRounds, setSessionRounds] = useState<RoundRecord[]>([]);
  const [sessionSummary, setSessionSummary] = useState<SessionSummary | null>(null);
  const [isSolo, setIsSolo] = useState(false);
  const soloRoomRef = useRef<Room | null>(null);
  const soloEngineRef = useRef<{ cancel: () => void; game?: { placeBet?: (...args: any[]) => void; makeChoice?: (...args: any[]) => void } } | null>(null);

  useEffect(() => {
    const socket = io(SOCKET_URL, {
      transports: ["websocket", "polling"],
      reconnection: true,
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
    });
    socketRef.current = socket;

    // "connect" fires on the initial connection AND on every reconnection,
    // and socket.io issues a new id each time, so this is the single
    // source of truth for "which player is me" on this client.
    socket.on("connect", () => {
      setIsConnected(true);
      setMyId(socket.id ?? null);
    });
    socket.on("disconnect", () => setIsConnected(false));
    socket.on("room:update", (r) => setRoom(r));
    socket.on("game:state", (s) => setGameState(s));
    socket.on("chat:message", (m) => setMessages((prev) => [...prev, m]));
    socket.on("error", (e) => setError(e));
    socket.on("bet:rejected", (message) => setError(message));
    socket.on("ai:announcement", (text, type) => setAiAnnouncement({ text, type }));
    socket.on("effect:trigger", (effect, targetId) => {
      setActiveEffect({ effect, targetId });
      setTimeout(() => setActiveEffect(null), 4000);
    });
    socket.on("typing:start", (playerId, playerName) => {
      setTypingPlayers((prev) => [...prev.filter((p) => p.playerId !== playerId), { playerId, playerName }]);
    });
    socket.on("typing:stop", (playerId) => {
      setTypingPlayers((prev) => prev.filter((p) => p.playerId !== playerId));
    });
    socket.on("friend:invite", (invite) => {
      setPartyInvites((prev) => [...prev, invite]);
    });
    socket.on("session:rounds", (rounds) => setSessionRounds(rounds));
    socket.on("session:summary", (summary) => setSessionSummary(summary));

    return () => {
      socket.disconnect();
    };
  }, []);

  const createRoom = useCallback(
    (data: { name: string; maxPlayers: number; password?: string }): Promise<Room> => {
      return withTimeout<Room>((resolve, reject) => {
        if (!socketRef.current) {
          reject(new Error("Not connected yet."));
          return;
        }
        socketRef.current.emit("room:create", data, (room) => {
          setRoom(room);
          resolve(room);
        });
      });
    },
    []
  );

  const joinRoom = useCallback(
    (data: { code: string; name: string; avatar: string }): Promise<Room | null> => {
      return withTimeout<Room | null>((resolve, reject) => {
        if (!socketRef.current) {
          reject(new Error("Not connected yet."));
          return;
        }
        socketRef.current.emit("room:join", data, (room) => {
          if (room) setRoom(room);
          resolve(room);
        });
      });
    },
    []
  );

  /** Starts a fully local, no-server Solo table filled with bots. */
  const startSolo = useCallback(
    (data: { name: string; avatar: string; roomName?: string; totalPlayers: number }): Room => {
      soloEngineRef.current?.cancel();
      const soloRoom = buildSoloRoom(data);
      soloRoomRef.current = soloRoom;
      setIsSolo(true);
      setIsConnected(true);
      setMyId("you");
      setRoom(soloRoom);
      setGameState(null);
      setMessages([]);
      setError(null);
      return soloRoom;
    },
    []
  );

  const leaveRoom = useCallback(() => {
    if (isSolo) {
      soloEngineRef.current?.cancel();
      soloEngineRef.current = null;
      soloRoomRef.current = null;
      setIsSolo(false);
      setRoom(null);
      setMessages([]);
      setGameState(null);
      setSessionRounds([]);
      setSessionSummary(null);
      return;
    }
    socketRef.current?.emit("room:leave");
    setRoom(null);
    setMessages([]);
    setGameState(null);
    setSessionRounds([]);
    setSessionSummary(null);
  }, [isSolo]);

  const setReady = useCallback(
    (ready: boolean) => {
      if (isSolo) {
        setRoom((prev) => {
          if (!prev) return prev;
          const updated = { ...prev, players: prev.players.map((p) => (p.id === "you" ? { ...p, isReady: ready } : p)) };
          soloRoomRef.current = updated;
          return updated;
        });
        return;
      }
      socketRef.current?.emit("player:ready", ready);
    },
    [isSolo]
  );

  const sendMessage = useCallback(
    (text: string, type?: ChatMessage["type"]) => {
      if (isSolo) {
        const you = soloRoomRef.current?.players.find((p) => p.id === "you");
        setMessages((prev) => [
          ...prev,
          { id: `${Date.now()}`, playerId: "you", playerName: you?.name || "You", text, type: type || "text", timestamp: Date.now() },
        ]);
        return;
      }
      socketRef.current?.emit("chat:send", text, type);
    },
    [isSolo]
  );

  const startTyping = useCallback(() => {
    socketRef.current?.emit("typing:start");
  }, []);

  const stopTyping = useCallback(() => {
    socketRef.current?.emit("typing:stop");
  }, []);

  const startGame = useCallback(
    (gameType?: GameType) => {
      if (isSolo) {
        const soloRoom = soloRoomRef.current;
        if (!soloRoom) return;
        const resolvedType = pickRandomGameType(gameType);
        const updatedRoom = { ...soloRoom, currentGame: resolvedType };
        soloRoomRef.current = updatedRoom;
        setRoom(updatedRoom);

        const handleUpdate = (state: any) => {
          setGameState(state);
          setRoom((prev) => {
            if (!prev) return prev;
            // RouletteGame/VaultHeistGame mutate player objects in place
            // (same reference held by both "before" and "after"). PlayerCard
            // is memoized and compares prev.player.chips === next.player.chips
            // — if the player object reference is unchanged, that comparison
            // is trivially true (it's the same object on both sides) and the
            // card never re-renders, even though the array wrapper is new.
            // Cloning each player object (not just the array) gives every
            // tick a fresh reference so the memo comparator actually runs.
            const next = { ...prev, players: prev.players.map((p) => ({ ...p })) };
            soloRoomRef.current = next;
            return next;
          });
          if (state.status === "ended") {
            setRoom((prev) => {
              if (!prev) return prev;
              const finished = {
                ...prev,
                currentGame: null,
                players: prev.players.map((p) => (p.id === "you" ? { ...p, isReady: false } : p)),
              };
              soloRoomRef.current = finished;
              return finished;
            });
          }
        };

        soloEngineRef.current?.cancel();
        if (resolvedType === "neon-roulette") {
          soloEngineRef.current = runSoloRoulette(soloRoom, handleUpdate);
        } else if (resolvedType === "vault-heist") {
          soloEngineRef.current = runSoloVaultHeist(soloRoom, handleUpdate);
        } else if (resolvedType === "coin-flip") {
          soloEngineRef.current = runSoloCoinFlip(soloRoom, handleUpdate);
        } else {
          soloEngineRef.current = runSoloDice(soloRoom, handleUpdate);
        }
        return;
      }
      socketRef.current?.emit("game:start", gameType);
    },
    [isSolo]
  );

  const stopGame = useCallback(() => {
    if (isSolo) {
      (soloEngineRef.current as any)?.game?.stop?.();
      return;
    }
    socketRef.current?.emit("game:stop");
  }, [isSolo]);

  const placeBet = useCallback(
    (bet: Omit<Bet, "playerId">) => {
      if (isSolo) {
        const engine = soloEngineRef.current as any;
        const ok = engine?.game?.placeBet?.("you", bet);
        // RouletteGame mutates the shared player objects in place (chips
        // deducted right away) — clone the players array so React actually
        // notices the balance changed and re-renders.
        if (ok) {
          setRoom((prev) => (prev ? { ...prev, players: prev.players.map((p) => ({ ...p })) } : prev));
        }
        return;
      }
      socketRef.current?.emit("game:bet", bet);
    },
    [isSolo]
  );

  const chooseVault = useCallback(
    (choice: string) => {
      if (isSolo) {
        const engine = soloEngineRef.current as any;
        engine?.game?.makeChoice?.("you", choice);
        return;
      }
      socketRef.current?.emit("game:choose", choice);
    },
    [isSolo]
  );

  const triggerPrank = useCallback((effect: string, targetId?: string) => {
    socketRef.current?.emit("prank:trigger", effect, targetId);
  }, []);

  const adminKick = useCallback((playerId: string) => {
    socketRef.current?.emit("admin:kick", playerId);
  }, []);

  const adminBan = useCallback((playerId: string) => {
    socketRef.current?.emit("admin:ban", playerId);
  }, []);

  const adminMute = useCallback((playerId: string) => {
    socketRef.current?.emit("admin:mute", playerId);
  }, []);

  const adminChips = useCallback((playerId: string, amount: number) => {
    socketRef.current?.emit("admin:chips", playerId, amount);
  }, []);

  const adminBroadcast = useCallback((message: string) => {
    socketRef.current?.emit("admin:broadcast", message);
  }, []);

  const adminTimer = useCallback((seconds: number) => {
    socketRef.current?.emit("admin:timer", seconds);
  }, []);

  const sendInvite = useCallback((friendId: string, roomCode: string) => {
    socketRef.current?.emit("friend:invite", friendId, roomCode);
  }, []);

  const acceptInvite = useCallback((inviteId: string) => {
    socketRef.current?.emit("friend:accept", inviteId);
    setPartyInvites((prev) => prev.filter((i) => i.id !== inviteId));
  }, []);

  const endSession = useCallback(() => {
    // Solo tables run entirely client-side with no round history to recap.
    if (isSolo) return;
    socketRef.current?.emit("session:end");
  }, [isSolo]);

  const clearSessionSummary = useCallback(() => {
    setSessionSummary(null);
  }, []);

  const setSpectating = useCallback(
    (spectating: boolean) => {
      if (isSolo) {
        setRoom((prev) => {
          if (!prev) return prev;
          const updated = { ...prev, players: prev.players.map((p) => (p.id === "you" ? { ...p, isSpectator: spectating } : p)) };
          soloRoomRef.current = updated;
          return updated;
        });
        return;
      }
      socketRef.current?.emit("player:spectate", spectating);
    },
    [isSolo]
  );

  const value: SocketContextValue = {
    socket: socketRef.current,
    isConnected,
    myId,
    room,
    gameState,
    messages,
    error,
    clearError: () => setError(null),
    aiAnnouncement,
    activeEffect,
    typingPlayers,
    partyInvites,
    sessionRounds,
    sessionSummary,
    clearSessionSummary,
    endSession,
    setSpectating,
    createRoom,
    joinRoom,
    leaveRoom,
    isSolo,
    startSolo,
    setReady,
    sendMessage,
    startTyping,
    stopTyping,
    startGame,
    stopGame,
    placeBet,
    chooseVault,
    triggerPrank,
    adminKick,
    adminBan,
    adminMute,
    adminChips,
    adminBroadcast,
    adminTimer,
    sendInvite,
    acceptInvite,
  };

  return <SocketContext.Provider value={value}>{children}</SocketContext.Provider>;
}

export function useSocketContext(): SocketContextValue {
  const ctx = useContext(SocketContext);
  if (!ctx) {
    throw new Error("useSocketContext must be used within a SocketProvider");
  }
  return ctx;
}
