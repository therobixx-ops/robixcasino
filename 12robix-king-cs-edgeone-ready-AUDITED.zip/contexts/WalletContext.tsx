"use client";

import { createContext, useContext, useState, useCallback, ReactNode } from "react";
import { Wallet, Transaction } from "../types";

interface WalletContextValue {
  wallet: Wallet | null;
  setWallet: (w: Wallet) => void;
  transactions: Transaction[];
  addTransaction: (tx: Transaction) => void;
}

const WalletContext = createContext<WalletContextValue | null>(null);

export function WalletProvider({ children }: { children: ReactNode }) {
  const [wallet, setWalletState] = useState<Wallet | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);

  const setWallet = useCallback((w: Wallet) => {
    setWalletState(w);
  }, []);

  const addTransaction = useCallback((tx: Transaction) => {
    setTransactions(prev => [tx, ...prev].slice(0, 100));
  }, []);

  return (
    <WalletContext.Provider value={{ wallet, setWallet, transactions, addTransaction }}>
      {children}
    </WalletContext.Provider>
  );
}

export function useWalletContext() {
  const ctx = useContext(WalletContext);
  if (!ctx) throw new Error("useWalletContext must be used within WalletProvider");
  return ctx;
}
