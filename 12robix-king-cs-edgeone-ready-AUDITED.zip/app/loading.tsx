export default function Loading() {
  return (
    <div className="min-h-dvh bg-vault-black flex items-center justify-center">
      <div className="text-center space-y-4">
        <div className="w-12 h-12 border-2 border-vault-gold/20 border-t-vault-gold rounded-full animate-spin mx-auto" />
        <p className="text-white/40 text-sm">Loading ROBIX KING CS...</p>
      </div>
    </div>
  );
}
