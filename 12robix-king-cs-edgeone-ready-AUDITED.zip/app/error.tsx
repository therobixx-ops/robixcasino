"use client";

import { useEffect } from "react";
import { motion } from "framer-motion";
import { AlertTriangle, RotateCcw } from "lucide-react";

export default function ErrorBoundary({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("ROBIX KING CS Error:", error);
  }, [error]);

  return (
    <div className="min-h-dvh bg-vault-black flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-strong rounded-2xl p-8 max-w-md w-full text-center space-y-6"
      >
        <motion.div
          animate={{ rotate: [0, 5, -5, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <AlertTriangle className="w-16 h-16 text-red-400 mx-auto" />
        </motion.div>

        <div>
          <h2 className="text-2xl font-bold text-white mb-2">Something went wrong</h2>
          <p className="text-white/40 text-sm">{error.message || "An unexpected error occurred"}</p>
          {error.digest && (
            <p className="text-white/20 text-xs font-mono mt-2">Error ID: {error.digest}</p>
          )}
        </div>

        <button
          onClick={reset}
          className="w-full py-3 bg-gold-sheen text-vault-black rounded-xl font-bold hover:brightness-110 transition-all flex items-center justify-center gap-2"
        >
          <RotateCcw className="w-4 h-4" />
          Try Again
        </button>
      </motion.div>
    </div>
  );
}
