"use client";

import { useState, useEffect, useCallback, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import dynamic from "next/dynamic";
import { IntroAnimation } from "../components/IntroAnimation";
import { useSocket } from "../hooks/useSocket";

// Lazy load lobby for instant first paint
const LazyLobby = dynamic(() => import("../components/Lobby").then((m) => m.Lobby), {
  ssr: false,
  loading: () => (
    <div className="min-h-dvh bg-vault-black flex items-center justify-center">
      <div className="w-8 h-8 border-2 border-vault-gold/20 border-t-vault-gold rounded-full animate-spin" />
    </div>
  ),
});

function HomeContent() {
  const [showIntro, setShowIntro] = useState(true);
  const [introComplete, setIntroComplete] = useState(false);
  const router = useRouter();
  const searchParams = useSearchParams();
  const { createRoom, joinRoom, startSolo } = useSocket();

  // Check for invite code in URL: ?r=BG72XP
  const inviteCode = searchParams.get("r");

  useEffect(() => {
    // If there's an invite code, skip intro and go straight to join
    if (inviteCode) {
      setShowIntro(false);
      setIntroComplete(true);
    }
  }, [inviteCode]);

  const handleCreateRoom = useCallback(
    async (data: { name: string; maxPlayers: number; password?: string }) => {
      const room = await createRoom(data);
      if (room) {
        router.push(`/room?code=${room.code}`);
      }
      return room;
    },
    [createRoom, router]
  );

  const handleJoinRoom = useCallback(
    async (data: { code: string; name: string; avatar: string }) => {
      const room = await joinRoom(data);
      if (room) {
        router.push(`/room?code=${room.code}`);
      }
      return room;
    },
    [joinRoom, router]
  );

  const handlePlaySolo = useCallback(
    (data: { name: string; avatar: string; roomName?: string; totalPlayers: number }) => {
      const room = startSolo(data);
      router.push(`/room?code=${room.code}`);
      return room;
    },
    [startSolo, router]
  );

  return (
    <main className="min-h-dvh bg-vault-black">
      {showIntro && (
        <IntroAnimation
          onComplete={() => {
            setShowIntro(false);
            setIntroComplete(true);
          }}
        />
      )}

      {introComplete && (
        <Suspense fallback={
          <div className="min-h-dvh flex items-center justify-center">
            <div className="w-8 h-8 border-2 border-vault-gold/20 border-t-vault-gold rounded-full animate-spin" />
          </div>
        }>
          <LazyLobby 
            onCreateRoom={handleCreateRoom} 
            onJoinRoom={handleJoinRoom}
            onPlaySolo={handlePlaySolo}
            inviteCode={inviteCode || undefined}
          />
        </Suspense>
      )}
    </main>
  );
}

export default function Home() {
  return (
    <Suspense fallback={null}>
      <HomeContent />
    </Suspense>
  );
}
