"use client";

import { Suspense, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Room } from "../../components/Room";
import { useSocket } from "../../hooks/useSocket";

function RoomContent() {
  const router = useRouter();
  const { room, isConnected } = useSocket();

  useEffect(() => {
    if (!isConnected) return;
    if (!room) {
      const timer = setTimeout(() => {
        router.push("/");
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [room, isConnected, router]);

  // Belt-and-suspenders: if the socket never connects at all (server
  // unreachable / not deployed), don't spin forever — bounce back to the
  // lobby after a reasonable wait instead of showing a dead screen.
  useEffect(() => {
    if (room) return;
    const timer = setTimeout(() => {
      router.push("/");
    }, 10000);
    return () => clearTimeout(timer);
  }, [room, router]);

  if (!room) {
    return (
      <div className="min-h-dvh bg-vault-black flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-2 border-vault-gold/20 border-t-vault-gold rounded-full animate-spin mx-auto mb-4" />
          <p className="text-white/40">Connecting to room...</p>
        </div>
      </div>
    );
  }

  return <Room />;
}

export default function RoomPage() {
  return (
    <Suspense fallback={null}>
      <RoomContent />
    </Suspense>
  );
}
