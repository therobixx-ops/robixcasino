import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import "./../styles/globals.css";
import { SocketProvider } from "../contexts/SocketContext";
import { WalletProvider } from "../contexts/WalletContext";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Robix Vault — Royal Casino",
  description: "The ultimate multiplayer casino experience",
  manifest: "/manifest.json",
};

export const viewport: Viewport = {
  themeColor: "#0a0a0a",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className={`${inter.className} bg-[#050505] text-white antialiased overflow-x-hidden`}>
        <WalletProvider>
          <SocketProvider>
            {children}
          </SocketProvider>
        </WalletProvider>
      </body>
    </html>
  );
}
