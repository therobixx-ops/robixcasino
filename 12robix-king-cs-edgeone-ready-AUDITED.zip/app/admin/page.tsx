"use client";

import { useState, useEffect, useCallback } from "react";
import { motion } from "framer-motion";
import { Lock, Shield, Users, RefreshCw, LogOut, Ban, UserX, Coins, Megaphone, Radio } from "lucide-react";

const SOCKET_URL = process.env.NEXT_PUBLIC_SOCKET_URL || "http://localhost:3001";
const TOKEN_KEY = "robix-king-cs-admin-token";

interface AdminRoomPlayer {
  id: string;
  name: string;
  chips: number;
  isHost: boolean;
}

interface AdminRoom {
  id: string;
  code: string;
  name: string;
  playerCount: number;
  maxPlayers: number;
  isLocked: boolean;
  currentGame: string | null;
  createdAt: number;
  players: AdminRoomPlayer[];
}

async function adminFetch(path: string, token: string, options: RequestInit = {}) {
  const res = await fetch(`${SOCKET_URL}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      ...(options.headers || {}),
    },
  });
  if (res.status === 401) throw new Error("UNAUTHORIZED");
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request failed (${res.status})`);
  }
  return res.json();
}

export default function AdminPage() {
  const [token, setToken] = useState<string | null>(null);
  const [checkingSession, setCheckingSession] = useState(true);

  useEffect(() => {
    const stored = typeof window !== "undefined" ? localStorage.getItem(TOKEN_KEY) : null;
    setToken(stored);
    setCheckingSession(false);
  }, []);

  const handleLogin = (t: string) => {
    localStorage.setItem(TOKEN_KEY, t);
    setToken(t);
  };

  const handleLogout = () => {
    localStorage.removeItem(TOKEN_KEY);
    setToken(null);
  };

  if (checkingSession) return null;

  return (
    <main className="min-h-dvh bg-vault-black text-white">
      {token ? (
        <Dashboard token={token} onUnauthorized={handleLogout} onLogout={handleLogout} />
      ) : (
        <LoginForm onLogin={handleLogin} />
      )}
    </main>
  );
}

function LoginForm({ onLogin }: { onLogin: (token: string) => void }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch(`${SOCKET_URL}/api/admin/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Login failed");
        return;
      }
      onLogin(data.token);
    } catch {
      setError("Could not reach the server. Is it running?");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-dvh flex items-center justify-center px-4">
      <motion.form
        onSubmit={handleSubmit}
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-sm bg-vault-glass border border-vault-glassBorder rounded-2xl p-8 backdrop-blur-xl"
      >
        <div className="flex flex-col items-center mb-6">
          <div className="w-14 h-14 rounded-full bg-vault-gold/10 border border-vault-gold/30 flex items-center justify-center mb-3">
            <Shield className="w-7 h-7 text-vault-gold" />
          </div>
          <h1 className="text-xl font-semibold">Administrator Login</h1>
          <p className="text-white/40 text-sm mt-1">ROBIX KING CS — restricted access</p>
        </div>

        <label className="block text-sm text-white/60 mb-1">Username</label>
        <input
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          autoComplete="username"
          className="w-full mb-4 bg-black/30 border border-white/10 rounded-lg px-3 py-2 outline-none focus:border-vault-gold/50"
        />

        <label className="block text-sm text-white/60 mb-1">Password</label>
        <div className="relative mb-6">
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="current-password"
            className="w-full bg-black/30 border border-white/10 rounded-lg px-3 py-2 pr-9 outline-none focus:border-vault-gold/50"
          />
          <Lock className="w-4 h-4 text-white/30 absolute right-3 top-1/2 -translate-y-1/2" />
        </div>

        {error && <p className="text-red-400 text-sm mb-4">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-gold-sheen text-vault-black font-medium rounded-lg py-2 hover:brightness-110 transition-all disabled:opacity-50"
        >
          {loading ? "Signing in…" : "Sign in"}
        </button>
      </motion.form>
    </div>
  );
}

function Dashboard({
  token,
  onUnauthorized,
  onLogout,
}: {
  token: string;
  onUnauthorized: () => void;
  onLogout: () => void;
}) {
  const [rooms, setRooms] = useState<AdminRoom[]>([]);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      const data = await adminFetch("/api/admin/rooms", token);
      setRooms(data);
      setError(null);
    } catch (err: any) {
      if (err.message === "UNAUTHORIZED") {
        onUnauthorized();
        return;
      }
      setError(err.message);
    }
  }, [token, onUnauthorized]);

  useEffect(() => {
    refresh();
    const interval = setInterval(refresh, 4000);
    return () => clearInterval(interval);
  }, [refresh]);

  const act = async (path: string, body?: object) => {
    try {
      await adminFetch(path, token, { method: "POST", body: JSON.stringify(body || {}) });
      refresh();
    } catch (err: any) {
      if (err.message === "UNAUTHORIZED") onUnauthorized();
      else setError(err.message);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-2">
          <Shield className="w-6 h-6 text-vault-gold" />
          <h1 className="text-2xl font-semibold">Admin Dashboard</h1>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={refresh} className="p-2 rounded-lg bg-white/5 hover:bg-white/10">
            <RefreshCw className="w-4 h-4" />
          </button>
          <button onClick={onLogout} className="p-2 rounded-lg bg-white/5 hover:bg-white/10 flex items-center gap-1 text-sm">
            <LogOut className="w-4 h-4" /> Log out
          </button>
        </div>
      </div>

      {error && <p className="text-red-400 mb-4 text-sm">{error}</p>}

      {rooms.length === 0 ? (
        <p className="text-white/40">No active rooms right now.</p>
      ) : (
        <div className="space-y-4">
          {rooms.map((room) => (
            <div key={room.id} className="bg-vault-glass border border-vault-glassBorder rounded-xl p-5">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h2 className="font-medium">{room.name}</h2>
                  <p className="text-white/40 text-sm">
                    Code {room.code} · {room.currentGame || "lobby"} · {room.isLocked ? "locked" : "unlocked"}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-white/50 flex items-center gap-1">
                    <Users className="w-4 h-4" /> {room.playerCount}/{room.maxPlayers}
                  </span>
                  <button
                    onClick={() => act(`/api/admin/rooms/${room.id}/lock`, { locked: !room.isLocked })}
                    className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-sm"
                  >
                    {room.isLocked ? "Unlock" : "Lock"}
                  </button>
                  <button
                    onClick={() => act(`/api/admin/rooms/${room.id}/regenerate-invite`)}
                    className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-sm"
                  >
                    New invite
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(`End room "${room.name}"? This disconnects everyone.`)) {
                        act(`/api/admin/rooms/${room.id}/end`);
                      }
                    }}
                    className="px-3 py-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-300 text-sm"
                  >
                    End room
                  </button>
                </div>
              </div>

              <div className="space-y-1.5">
                {room.players.map((p) => (
                  <div key={p.id} className="flex items-center justify-between text-sm bg-black/20 rounded-lg px-3 py-2">
                    <span>
                      {p.name} {p.isHost && <span className="text-vault-gold text-xs">(host)</span>}
                      <span className="text-white/30 ml-2">{p.chips.toLocaleString()} chips</span>
                    </span>
                    <div className="flex items-center gap-1.5">
                      <button
                        title="Give 1000 chips"
                        onClick={() => act(`/api/admin/rooms/${room.id}/chips`, { playerId: p.id, amount: 1000 })}
                        className="p-1.5 rounded bg-white/5 hover:bg-white/10"
                      >
                        <Coins className="w-3.5 h-3.5" />
                      </button>
                      <button
                        title="Kick"
                        onClick={() => act(`/api/admin/rooms/${room.id}/kick`, { playerId: p.id })}
                        className="p-1.5 rounded bg-white/5 hover:bg-white/10"
                      >
                        <UserX className="w-3.5 h-3.5" />
                      </button>
                      <button
                        title="Ban"
                        onClick={() => act(`/api/admin/rooms/${room.id}/ban`, { playerId: p.id })}
                        className="p-1.5 rounded bg-white/5 hover:bg-white/10"
                      >
                        <Ban className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <BroadcastRow onSend={(msg) => act(`/api/admin/rooms/${room.id}/broadcast`, { message: msg })} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function BroadcastRow({ onSend }: { onSend: (message: string) => void }) {
  const [message, setMessage] = useState("");
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (!message.trim()) return;
        onSend(message.trim());
        setMessage("");
      }}
      className="flex items-center gap-2 mt-3"
    >
      <Megaphone className="w-4 h-4 text-white/30 shrink-0" />
      <input
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Broadcast a message to this room…"
        className="flex-1 bg-black/20 border border-white/10 rounded-lg px-3 py-1.5 text-sm outline-none focus:border-vault-gold/50"
      />
      <button type="submit" className="p-1.5 rounded bg-white/5 hover:bg-white/10">
        <Radio className="w-3.5 h-3.5" />
      </button>
    </form>
  );
}
