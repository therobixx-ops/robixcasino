"use client";

import { memo, useEffect, useRef, useState } from "react";
import { motion, animate } from "framer-motion";
import { Crown, Wifi, Flame, Zap } from "lucide-react";
import { cn, formatChips } from "../lib/utils";
import type { Player } from "../types";

interface PlayerCardProps {
  player: Player;
  index: number;
  isCurrentPlayer: boolean;
  onPrank?: (effect: string) => void;
}

/** Tweens a displayed number toward `value` whenever it changes, instead of
 * jumping instantly — gives chip wins/losses a smooth, premium roll-up feel. */
function useAnimatedNumber(value: number, duration = 0.7) {
  const [display, setDisplay] = useState(value);
  const prevRef = useRef(value);

  useEffect(() => {
    const from = prevRef.current;
    const to = value;
    prevRef.current = value;
    if (from === to) return;
    const controls = animate(from, to, {
      duration,
      ease: "easeOut",
      onUpdate: (v) => setDisplay(v),
    });
    return () => controls.stop();
  }, [value, duration]);

  return display;
}

function PlayerCardImpl({ player, index, isCurrentPlayer, onPrank }: PlayerCardProps) {
  const animatedChips = useAnimatedNumber(player.chips);
  const prevChipsRef = useRef(player.chips);
  const [flash, setFlash] = useState<"up" | "down" | null>(null);

  useEffect(() => {
    if (player.chips > prevChipsRef.current) setFlash("up");
    else if (player.chips < prevChipsRef.current) setFlash("down");
    prevChipsRef.current = player.chips;
  }, [player.chips]);

  useEffect(() => {
    if (!flash) return;
    const t = setTimeout(() => setFlash(null), 900);
    return () => clearTimeout(t);
  }, [flash]);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: index * 0.1 }}
      className={cn(
        "relative glass-strong rounded-2xl p-4 transition-all duration-300",
        isCurrentPlayer && "ring-2 ring-vault-gold/50 neon-glow",
        player.isReady && "border-vault-emerald/30"
      )}
    >
      {/* Host badge */}
      {player.isHost && (
        <div className="absolute -top-2 -right-2 w-6 h-6 bg-gold-sheen rounded-full flex items-center justify-center shadow-md">
          <Crown className="w-3 h-3 text-vault-black" />
        </div>
      )}

      <div className="flex items-center gap-3">
        {/* Avatar */}
        <div className="relative">
          <div className="w-14 h-14 rounded-xl flex items-center justify-center text-3xl bg-white/5">
            {player.avatar}
          </div>
          {player.isReady && (
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-vault-emerald rounded-full border-2 border-vault-graphite" />
          )}
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h4 className="text-white font-semibold truncate">{player.name}</h4>
            {player.winStreak > 2 && <Flame className="w-4 h-4 text-orange-400" />}
            {player.isSpectator && (
              <span className="text-[9px] uppercase tracking-wider text-white/40 border border-white/15 rounded px-1 py-0.5 flex-shrink-0">
                spectating
              </span>
            )}
          </div>
          <motion.p
            className="text-sm font-mono"
            animate={{
              color: flash === "up" ? "#34d399" : flash === "down" ? "#f87171" : "#d4af37",
              scale: flash ? [1, 1.12, 1] : 1,
            }}
            transition={{ duration: 0.5 }}
          >
            {formatChips(Math.round(animatedChips))}
          </motion.p>
        </div>

        {/* Stats */}
        <div className="flex flex-col items-end gap-1">
          <div className="flex items-center gap-1 text-white/30 text-xs">
            <Wifi className="w-3 h-3" />
            <span>{player.ping}ms</span>
          </div>
          {player.winStreak > 0 && (
            <div className="flex items-center gap-1 text-orange-400 text-xs">
              <Zap className="w-3 h-3" />
              <span>{player.winStreak}</span>
            </div>
          )}
        </div>
      </div>

      {/* Quick pranks */}
      {onPrank && !isCurrentPlayer && (
        <div className="flex gap-1 mt-3 pt-3 border-t border-white/5">
          {["😂", "🔥", "💀", "👀"].map((emoji) => (
            <button
              key={emoji}
              onClick={() => onPrank(emoji)}
              className="text-sm hover:scale-125 transition-transform p-1"
            >
              {emoji}
            </button>
          ))}
        </div>
      )}
    </motion.div>
  );
}

export const PlayerCard = memo(PlayerCardImpl, (prev, next) => {
  return (
    prev.isCurrentPlayer === next.isCurrentPlayer &&
    prev.index === next.index &&
    prev.player.id === next.player.id &&
    prev.player.chips === next.player.chips &&
    prev.player.isReady === next.player.isReady &&
    prev.player.isHost === next.player.isHost &&
    prev.player.ping === next.player.ping &&
    prev.player.winStreak === next.player.winStreak &&
    prev.player.avatar === next.player.avatar &&
    prev.player.name === next.player.name &&
    prev.player.isSpectator === next.player.isSpectator
  );
});
