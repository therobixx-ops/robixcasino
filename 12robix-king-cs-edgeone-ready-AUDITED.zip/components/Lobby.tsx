"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Crown, Users, Lock, ArrowRight, Sparkles, Shield, Zap, PartyPopper, User } from "lucide-react";
import { cn, getRandomAvatar, formatChips } from "../lib/utils";
import { RobixSeal } from "./RobixSeal";
import type { Room } from "../types";

interface LobbyProps {
  onCreateRoom: (data: { name: string; maxPlayers: number; password?: string }) => Promise<Room>;
  onJoinRoom: (data: { code: string; name: string; avatar: string }) => Promise<Room | null>;
  onPlaySolo: (data: { name: string; avatar: string; roomName?: string; totalPlayers: number }) => Room;
  inviteCode?: string;
}

export function Lobby({ onCreateRoom, onJoinRoom, onPlaySolo, inviteCode }: LobbyProps) {
  const [mode, setMode] = useState<"menu" | "create" | "join" | "solo">(inviteCode ? "join" : "menu");
  const [name, setName] = useState("");
  const [avatar, setAvatar] = useState(getRandomAvatar());
  const [roomCode, setRoomCode] = useState(inviteCode || "");
  const [roomName, setRoomName] = useState("");
  const [maxPlayers, setMaxPlayers] = useState(6);
  const [soloTotalPlayers, setSoloTotalPlayers] = useState(4);
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const avatars = ["🦁", "🦊", "🐼", "🐯", "🦅", "🐺", "🦉", "🐉", "🦋", "🦄", "🐍", "🦎", "🦖", "🐙"];

  // Auto-focus name input when joining via invite
  useEffect(() => {
    if (inviteCode) {
      const timer = setTimeout(() => {
        const input = document.getElementById("player-name");
        input?.focus();
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [inviteCode]);

  const handleCreate = async () => {
    if (!name.trim()) return;
    setLoading(true);
    setError("");
    try {
      await onCreateRoom({
        name: roomName || `${name}'s Royal Room`,
        maxPlayers,
        password: password || undefined,
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to create room");
    }
    setLoading(false);
  };

  const handleJoin = async () => {
    if (!name.trim() || !roomCode.trim()) return;
    setLoading(true);
    setError("");
    try {
      const room = await onJoinRoom({ code: roomCode.toUpperCase(), name, avatar });
      if (!room) setError("Room not found, full, or locked");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to join room");
    }
    setLoading(false);
  };

  const handlePlaySolo = () => {
    if (!name.trim()) return;
    setLoading(true);
    setError("");
    // Fully local — no server round trip, so this can't hang.
    onPlaySolo({
      name,
      avatar,
      roomName: roomName || `${name}'s Solo Table`,
      totalPlayers: soloTotalPlayers,
    });
    setLoading(false);
  };

  return (
    <div className="min-h-dvh bg-vault-black flex items-center justify-center p-4 relative overflow-hidden">
      {/* Animated background — two-tone royal glow, same language as the intro and the wheel */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="royal-glow" />
      </div>

      <motion.div
        className="relative w-full max-w-md"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Header */}
        <div className="text-center mb-8">
          <motion.div
            className="inline-flex flex-col items-center gap-3 mb-3"
            animate={{ y: [0, -4, 0] }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            <RobixSeal size={56} />
            <span className="relative font-display font-semibold text-gold-gradient text-sm tracking-[0.25em] uppercase light-sweep">
              Robix King CS
            </span>
          </motion.div>
          <h2 className="text-3xl font-display font-bold text-ink">Private Party Games</h2>
          <p className="text-ink/40 text-sm mt-2 font-body">Like a Discord call, but with games.</p>

          {/* Invite banner */}
          {inviteCode && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="metallic-gold-border relative mt-4 glass rounded-xl p-3"
            >
              <div className="flex items-center justify-center gap-2 text-vault-gold text-sm">
                <PartyPopper className="w-4 h-4" />
                <span>You&apos;ve been invited to room <strong className="font-mono tracking-wider">{inviteCode}</strong></span>
              </div>
            </motion.div>
          )}
        </div>

        <AnimatePresence mode="wait">
          {mode === "menu" && (
            <motion.div
              key="menu"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-4"
            >
              <button
                onClick={() => setMode("solo")}
                className="metallic-gold-border relative w-full card-lacquer rounded-2xl p-6 text-left group hover:brightness-125 transition-all duration-300 neon-glow overflow-hidden"
              >
                <div className="relative flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-display font-semibold text-ink group-hover:text-vault-gold-light transition-colors">
                      Play Solo
                    </h3>
                    <p className="text-white/40 text-sm mt-1">Just you + AI table (1-12 players), no waiting</p>
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-gold-sheen flex items-center justify-center shadow-inner">
                    <User className="w-6 h-6 text-vault-black" strokeWidth={2} />
                  </div>
                </div>
              </button>

              <button
                onClick={() => setMode("create")}
                className="metallic-gold-border relative w-full card-lacquer rounded-2xl p-6 text-left group hover:brightness-125 transition-all duration-300"
              >
                <div className="relative flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-display font-semibold text-ink group-hover:text-vault-gold-light transition-colors">
                      Create Room
                    </h3>
                    <p className="text-white/40 text-sm mt-1">Host a private game for friends</p>
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-vault-gold/10 flex items-center justify-center group-hover:bg-vault-gold/20 transition-colors">
                    <Crown className="w-6 h-6 text-vault-gold" />
                  </div>
                </div>
              </button>

              <button
                onClick={() => setMode("join")}
                className="relative w-full glass-strong rounded-2xl p-6 text-left group hover:bg-white/10 transition-all duration-300 border border-vault-emerald/15 overflow-hidden"
              >
                <div className="relative flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-display font-semibold text-ink group-hover:text-vault-emerald transition-colors">
                      Join Room
                    </h3>
                    <p className="text-white/40 text-sm mt-1">Enter a room code to play</p>
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-emerald-felt flex items-center justify-center shadow-inner">
                    <ArrowRight className="w-6 h-6 text-white" strokeWidth={2} />
                  </div>
                </div>
              </button>

              <div className="metallic-gold-border relative glass rounded-xl p-4 mt-6 space-y-2">
                <div className="flex items-center gap-2 text-vault-gold/60 text-xs">
                  <Shield className="w-4 h-4 flex-shrink-0" />
                  <span>Royal Chips are virtual entertainment credits only</span>
                </div>
                <div className="flex items-center gap-2 text-white/30 text-xs">
                  <Sparkles className="w-4 h-4 flex-shrink-0" />
                  <span>No purchases, no withdrawals, no real money</span>
                </div>
                <div className="flex items-center gap-2 text-white/30 text-xs">
                  <Zap className="w-4 h-4 flex-shrink-0" />
                  <span>Works offline as PWA after first load</span>
                </div>
              </div>
            </motion.div>
          )}

          {(mode === "create" || mode === "join" || mode === "solo") && (
            <motion.div
              key="form"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="glass-strong rounded-2xl p-6 space-y-4"
            >
              <button
                onClick={() => setMode("menu")}
                className="text-white/40 text-sm hover:text-white transition-colors"
              >
                ← Back
              </button>

              {/* Avatar selection */}
              <div>
                <label className="text-white/60 text-sm mb-2 block">Choose Avatar</label>
                <div className="flex gap-2 flex-wrap">
                  {avatars.map((a) => (
                    <button
                      key={a}
                      onClick={() => setAvatar(a)}
                      className={cn(
                        "w-10 h-10 rounded-xl text-xl flex items-center justify-center transition-all",
                        avatar === a
                          ? "bg-vault-gold/20 border-2 border-vault-gold scale-110"
                          : "bg-white/5 border-2 border-transparent hover:bg-white/10"
                      )}
                    >
                      {a}
                    </button>
                  ))}
                </div>
              </div>

              {/* Name */}
              <div>
                <label className="text-white/60 text-sm mb-2 block">Your Name</label>
                <input
                  id="player-name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter your name"
                  maxLength={16}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder:text-white/20 focus:outline-none focus:border-vault-gold/50 transition-colors"
                  autoFocus
                />
              </div>

              {mode === "create" && (
                <>
                  <div>
                    <label className="text-white/60 text-sm mb-2 block">Room Name</label>
                    <input
                      type="text"
                      value={roomName}
                      onChange={(e) => setRoomName(e.target.value)}
                      placeholder="My Royal Room"
                      maxLength={24}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder:text-white/20 focus:outline-none focus:border-vault-gold/50 transition-colors"
                    />
                  </div>

                  <div>
                    <label className="text-white/60 text-sm mb-2 block">Max Players: {maxPlayers}</label>
                    <input
                      type="range"
                      min={2}
                      max={12}
                      value={maxPlayers}
                      onChange={(e) => setMaxPlayers(Number(e.target.value))}
                      className="w-full accent-vault-gold"
                    />
                  </div>

                  <div>
                    <label className="text-white/60 text-sm mb-2 block flex items-center gap-2">
                      <Lock className="w-3 h-3" /> Password (optional)
                    </label>
                    <input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Leave empty for open room"
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder:text-white/20 focus:outline-none focus:border-vault-gold/50 transition-colors"
                    />
                  </div>
                </>
              )}

              {mode === "solo" && (
                <>
                  <div>
                    <label className="text-white/60 text-sm mb-2 block">Table Name (optional)</label>
                    <input
                      type="text"
                      value={roomName}
                      onChange={(e) => setRoomName(e.target.value)}
                      placeholder="My Solo Table"
                      maxLength={24}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder:text-white/20 focus:outline-none focus:border-vault-gold/50 transition-colors"
                    />
                  </div>

                  <div>
                    <label className="text-white/60 text-sm mb-2 block">
                      Total Players: {soloTotalPlayers === 1 ? "Just you" : `${soloTotalPlayers} (you + ${soloTotalPlayers - 1} AI)`}
                    </label>
                    <input
                      type="range"
                      min={1}
                      max={12}
                      value={soloTotalPlayers}
                      onChange={(e) => setSoloTotalPlayers(Number(e.target.value))}
                      className="w-full accent-vault-gold"
                    />
                    <p className="text-white/30 text-xs mt-1">Fill empty seats with AI so the table always plays instantly — works fully offline, no server needed.</p>
                  </div>
                </>
              )}

              {mode === "join" && (
                <div>
                  <label className="text-white/60 text-sm mb-2 block">Room Code</label>
                  <input
                    type="text"
                    value={roomCode}
                    onChange={(e) => setRoomCode(e.target.value.toUpperCase())}
                    placeholder="BG72XP"
                    maxLength={6}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder:text-white/20 focus:outline-none focus:border-vault-emerald/50 transition-colors text-center tracking-[0.3em] font-mono text-lg"
                  />
                </div>
              )}

              {error && (
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-red-400 text-sm text-center"
                >
                  {error}
                </motion.p>
              )}

              <button
                onClick={mode === "create" ? handleCreate : mode === "join" ? handleJoin : handlePlaySolo}
                disabled={loading || !name.trim() || (mode === "join" && !roomCode.trim())}
                className={cn(
                  "w-full py-4 rounded-xl font-display font-semibold text-lg transition-all duration-300 shadow-lg",
                  mode === "join"
                    ? "bg-emerald-felt text-white hover:brightness-110 neon-glow-emerald"
                    : "bg-gold-sheen text-vault-black hover:brightness-110 neon-glow",
                  (loading || !name.trim() || (mode === "join" && !roomCode.trim())) && "opacity-50 cursor-not-allowed"
                )}
              >
                {loading ? "Loading..." : mode === "create" ? "Create Royal Room" : mode === "join" ? "Join Room" : "Start Solo Table"}
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
