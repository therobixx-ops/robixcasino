"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { RobixSeal } from "./RobixSeal";
import { cn } from "../lib/utils";

interface IntroAnimationProps {
  onComplete: () => void;
}

export function IntroAnimation({ onComplete }: IntroAnimationProps) {
  const [phase, setPhase] = useState<"logo" | "tagline" | "done">("logo");

  useEffect(() => {
    const t1 = setTimeout(() => setPhase("tagline"), 2200);
    const t2 = setTimeout(() => {
      setPhase("done");
      onComplete();
    }, 3800);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, [onComplete]);

  if (phase === "done") return null;

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-vault-black safe-top safe-bottom safe-x"
        initial={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Two-tone royal ambient glow behind the mark */}
        <div className="royal-glow" aria-hidden />

        {/* Ambient particles */}
        <div className="absolute inset-0 overflow-hidden">
          {Array.from({ length: 24 }).map((_, i) => (
            <motion.div
              key={i}
              className={cn("absolute w-1 h-1 rounded-full", i % 3 === 0 ? "bg-vault-wine-light" : "bg-vault-gold")}
              initial={{
                x: Math.random() * (typeof window !== "undefined" ? window.innerWidth : 1000),
                y: Math.random() * (typeof window !== "undefined" ? window.innerHeight : 800),
                opacity: 0,
                scale: 0,
              }}
              animate={{
                y: [null, Math.random() * -200 - 100],
                opacity: [0, 0.7, 0],
                scale: [0, 1.4, 0],
              }}
              transition={{
                duration: 3 + Math.random() * 2,
                repeat: Infinity,
                delay: Math.random() * 2,
                ease: "easeOut",
              }}
            />
          ))}
        </div>

        {/* Mark + wordmark */}
        <motion.div
          className="relative flex flex-col items-center gap-5"
          initial={{ scale: 0.85, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.9, ease: "easeOut" }}
        >
          <motion.div
            initial={{ rotate: -8, opacity: 0 }}
            animate={{ rotate: 0, opacity: 1 }}
            transition={{ duration: 0.7, delay: 0.15 }}
          >
            <RobixSeal size={88} />
          </motion.div>

          <div className="flex flex-col items-center leading-none">
            <motion.h1
              className="relative font-display font-black tracking-tight text-gold-gradient text-5xl md:text-7xl light-sweep animate-gradient-drift"
              initial={{ y: 16, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              ROBIX KING
            </motion.h1>
            <motion.span
              className="font-display font-medium tracking-[0.5em] uppercase text-ink/80 text-lg md:text-2xl mt-1"
              initial={{ y: 12, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.6 }}
            >
              CS
            </motion.span>
          </div>
        </motion.div>

        {/* Tagline */}
        <AnimatePresence>
          {phase === "tagline" && (
            <motion.div
              className="mt-10 text-center"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
            >
              <p className="text-vault-gold/80 text-xs md:text-sm tracking-[0.35em] uppercase font-body">
                Private Social Gaming
              </p>
              <p className="text-ink/40 text-xs mt-2 tracking-wider font-body">
                Entertainment Only — No Cash Value
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Progress bar */}
        <motion.div className="absolute bottom-12 left-1/2 -translate-x-1/2 w-48 h-0.5 bg-white/10 rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-gold-sheen"
            initial={{ width: "0%" }}
            animate={{ width: "100%" }}
            transition={{ duration: 3.8, ease: "linear" }}
          />
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
