"use client";

import { motion } from "framer-motion";

interface TypingIndicatorProps {
  players: Array<{ name: string; color?: string }>;
}

export function TypingIndicator({ players }: TypingIndicatorProps) {
  if (players.length === 0) return null;

  const text = players.length === 1 
    ? `${players[0].name} is typing...` 
    : players.length === 2 
    ? `${players[0].name} and ${players[1].name} are typing...`
    : `${players.length} people are typing...`;

  return (
    <motion.div
      initial={{ opacity: 0, y: 5 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 5 }}
      className="flex items-center gap-2 px-3 py-1.5"
    >
      <div className="flex gap-0.5">
        {[0, 1, 2].map((i) => (
          <motion.div
            key={i}
            className="w-1.5 h-1.5 rounded-full bg-vault-gold/60"
            animate={{ y: [0, -3, 0] }}
            transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.15 }}
          />
        ))}
      </div>
      <span className="text-white/30 text-xs">{text}</span>
    </motion.div>
  );
}
