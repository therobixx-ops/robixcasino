"use client";

import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, X, Crown } from "lucide-react";
import type { SessionSummary } from "../../types";
import { formatChips } from "../../lib/utils";

interface SessionSummaryModalProps {
  summary: SessionSummary | null;
  onClose: () => void;
}

export function SessionSummaryModal({ summary, onClose }: SessionSummaryModalProps) {
  return (
    <AnimatePresence>
      {summary && (
        <motion.div
          className="fixed inset-0 z-[70] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <motion.div
            className="glass-strong rounded-2xl p-6 sm:p-8 max-w-md w-full relative max-h-[85vh] overflow-y-auto"
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0 }}
            onClick={(e) => e.stopPropagation()}
          >
            <button onClick={onClose} className="absolute top-4 right-4 text-white/40 hover:text-white">
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 mb-1">
              <Sparkles className="w-5 h-5 text-vault-gold" />
              <p className="text-white/40 text-xs uppercase tracking-wider">AI Host Recap</p>
            </div>
            <h2 className="text-2xl font-bold text-gold-gradient mb-4">Session Summary</h2>

            {summary.mvpName && (
              <div className="glass rounded-xl p-4 mb-4 flex items-center gap-3">
                <Crown className="w-8 h-8 text-vault-gold flex-shrink-0" />
                <div>
                  <p className="text-white/40 text-xs uppercase tracking-wider">MVP</p>
                  <p className="text-white font-semibold">
                    {summary.mvpName} · +{formatChips(summary.mvpChipsWon)} chips
                  </p>
                </div>
              </div>
            )}

            <div className="space-y-2 mb-4 text-sm text-white/70">
              {summary.narrative.map((line, i) => (
                <motion.p key={i} initial={{ opacity: 0, x: -6 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.15 + i * 0.12 }}>
                  {line}
                </motion.p>
              ))}
            </div>

            <div className="pt-3 border-t border-white/10">
              <p className="text-white/30 text-xs uppercase tracking-wider mb-2">Final Standings</p>
              <div className="space-y-1.5">
                {summary.finalStandings.map((p, i) => (
                  <div key={p.id} className="flex items-center justify-between text-sm">
                    <span className="text-white/70">
                      {i + 1}. {p.name}
                    </span>
                    <span className="text-vault-gold font-medium">{formatChips(p.chips)}</span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
