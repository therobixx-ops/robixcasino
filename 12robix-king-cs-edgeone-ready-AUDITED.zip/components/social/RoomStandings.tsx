"use client";

import { motion } from "framer-motion";
import { Trophy, Flame } from "lucide-react";
import type { Player, RoundRecord } from "../../types";
import { formatChips, cn } from "../../lib/utils";

interface RoomStandingsProps {
  players: Player[];
  rounds: RoundRecord[];
  currentPlayerId?: string;
}

const MEDALS = ["🥇", "🥈", "🥉"];

export function RoomStandings({ players, rounds, currentPlayerId }: RoomStandingsProps) {
  const sorted = [...players].sort((a, b) => b.chips - a.chips);

  const biggestWin = rounds.reduce<RoundRecord | null>((max, r) => {
    if (!r.winnerAmount) return max;
    if (!max || (r.winnerAmount as number) > (max.winnerAmount as number)) return r;
    return max;
  }, null);

  return (
    <div className="glass-strong rounded-2xl p-4">
      <div className="flex items-center gap-2 mb-3">
        <Trophy className="w-4 h-4 text-vault-gold" />
        <h3 className="text-white/60 text-sm font-medium uppercase tracking-wider">Room Standings</h3>
      </div>

      <div className="space-y-2">
        {sorted.map((p, i) => (
          <motion.div
            key={p.id}
            initial={{ opacity: 0, x: -8 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.03 }}
            className={cn(
              "flex items-center justify-between px-3 py-2 rounded-xl",
              p.id === currentPlayerId ? "bg-vault-gold/10 border border-vault-gold/30" : "bg-white/5"
            )}
          >
            <div className="flex items-center gap-2 min-w-0">
              <span className="w-6 text-center text-sm">{MEDALS[i] ?? i + 1}</span>
              <span className="text-white text-sm truncate">{p.name}</span>
              {p.isSpectator && (
                <span className="text-[9px] uppercase tracking-wider text-white/30 border border-white/10 rounded px-1 py-0.5 flex-shrink-0">
                  spectating
                </span>
              )}
              {p.winStreak >= 2 && (
                <span className="flex items-center gap-0.5 text-orange-400 text-xs flex-shrink-0">
                  <Flame className="w-3 h-3" /> {p.winStreak}
                </span>
              )}
            </div>
            <span className="text-vault-gold text-sm font-semibold flex-shrink-0">{formatChips(p.chips)}</span>
          </motion.div>
        ))}
      </div>

      {biggestWin && (
        <div className="mt-3 pt-3 border-t border-white/10 text-xs text-white/40">
          Biggest win this session:{" "}
          <span className="text-vault-gold font-medium">
            {biggestWin.winnerName} · {formatChips(biggestWin.winnerAmount || 0)}
          </span>
        </div>
      )}
    </div>
  );
}
