"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Users, Circle, Send, X } from "lucide-react";
import { cn } from "../../lib/utils";
import type { Friend, PartyInvite } from "../../types";

interface FriendListProps {
  friends: Friend[];
  invites: PartyInvite[];
  onInvite: (friendId: string) => void;
  onAcceptInvite: (inviteId: string) => void;
  onDeclineInvite: (inviteId: string) => void;
}

export function FriendList({ friends, invites, onInvite, onAcceptInvite, onDeclineInvite }: FriendListProps) {
  const [expanded, setExpanded] = useState(false);
  const [showInvites, setShowInvites] = useState(false);

  const onlineFriends = friends.filter((f) => f.status === "online" || f.status === "in_game");
  const pendingInvites = invites.filter((i) => Date.now() < i.expiresAt);

  return (
    <div className="glass-strong rounded-2xl p-4 space-y-3">
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center justify-between"
      >
        <div className="flex items-center gap-2">
          <Users className="w-5 h-5 text-vault-emerald" />
          <h3 className="text-white font-semibold">Friends</h3>
          <span className="text-vault-emerald text-xs font-medium">{onlineFriends.length} online</span>
          {pendingInvites.length > 0 && (
            <span className="bg-vault-gold text-vault-black text-[10px] font-bold px-1.5 py-0.5 rounded-full">
              {pendingInvites.length}
            </span>
          )}
        </div>
        <motion.div animate={{ rotate: expanded ? 180 : 0 }}>
          <ChevronDown className="w-4 h-4 text-white/40" />
        </motion.div>
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden space-y-3"
          >
            {/* Invites */}
            {pendingInvites.length > 0 && (
              <div className="space-y-2">
                <p className="text-vault-gold text-xs uppercase tracking-wider">Party Invites</p>
                {pendingInvites.map((invite) => (
                  <motion.div
                    key={invite.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="flex items-center gap-2 bg-vault-gold/10 border border-vault-gold/20 rounded-xl p-3"
                  >
                    <div className="flex-1 min-w-0">
                      <p className="text-white text-sm font-medium truncate">{invite.fromName}</p>
                      <p className="text-white/40 text-xs">Room: {invite.roomName}</p>
                    </div>
                    <button
                      onClick={() => onAcceptInvite(invite.id)}
                      className="p-2 bg-vault-emerald/20 text-vault-emerald rounded-lg hover:bg-vault-emerald/30 transition-colors"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onDeclineInvite(invite.id)}
                      className="p-2 bg-white/5 text-white/40 rounded-lg hover:bg-white/10 transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </motion.div>
                ))}
              </div>
            )}

            {/* Friends list */}
            <div className="space-y-1 max-h-48 overflow-y-auto">
              {friends.map((friend) => (
                <div
                  key={friend.id}
                  className="flex items-center gap-3 p-2 rounded-xl hover:bg-white/5 transition-colors"
                >
                  <div className="relative">
                    <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center text-lg">
                      {friend.avatar}
                    </div>
                    <div className={cn(
                      "absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-vault-graphite",
                      friend.status === "online" && "bg-vault-emerald",
                      friend.status === "in_game" && "bg-vault-gold",
                      friend.status === "offline" && "bg-white/20"
                    )} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-sm font-medium truncate">{friend.name}</p>
                    <p className="text-white/30 text-xs">
                      {friend.status === "in_game" ? `In ${friend.currentRoom}` : friend.status}
                    </p>
                  </div>
                  {friend.status !== "offline" && (
                    <button
                      onClick={() => onInvite(friend.id)}
                      className="p-1.5 bg-white/5 text-white/40 rounded-lg hover:bg-vault-gold/20 hover:text-vault-gold transition-colors"
                    >
                      <Send className="w-3 h-3" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ChevronDown({ className }: { className?: string }) {
  return (
    <svg className={className} width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="6 9 12 15 18 9" />
    </svg>
  );
}
