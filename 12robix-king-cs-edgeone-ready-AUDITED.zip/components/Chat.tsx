"use client";

import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Send, Smile, Sticker, ChevronDown, ChevronUp } from "lucide-react";
import { cn } from "../lib/utils";
import type { ChatMessage, QuickReaction } from "../types";

interface ChatProps {
  messages: ChatMessage[];
  onSend: (text: string, type?: ChatMessage["type"]) => void;
  currentPlayerId: string;
  onTypingStart?: () => void;
  onTypingStop?: () => void;
  /** Starts collapsed (header only). Defaults to expanded. */
  startCollapsed?: boolean;
}

const QUICK_REACTIONS: QuickReaction[] = ["😂", "😭", "🔥", "💀", "👀", "💰", "GG", "Lucky!", "No way!", "Again!"];

const STICKERS = ["🎉", "🍀", "🎯", "🚀", "💎", "👑", "🎊", "✨", "🌟", "💯"];

export function Chat({ messages, onSend, currentPlayerId, onTypingStart, onTypingStop, startCollapsed = false }: ChatProps) {
  const [input, setInput] = useState("");
  const [showReactions, setShowReactions] = useState(false);
  const [showStickers, setShowStickers] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [collapsed, setCollapsed] = useState(startCollapsed);
  const scrollRef = useRef<HTMLDivElement>(null);
  const typingTimer = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value);

    if (!isTyping) {
      setIsTyping(true);
      onTypingStart?.();
    }

    if (typingTimer.current) clearTimeout(typingTimer.current);
    typingTimer.current = setTimeout(() => {
      setIsTyping(false);
      onTypingStop?.();
    }, 2000);
  };

  const handleSend = () => {
    if (!input.trim()) return;
    onSend(input);
    setInput("");
    setIsTyping(false);
    onTypingStop?.();
    if (typingTimer.current) clearTimeout(typingTimer.current);
  };

  return (
    <div className={cn("glass-strong rounded-2xl flex flex-col", collapsed ? "" : "h-full max-h-[min(500px,60dvh)]")}>
      {/* Header — tap to collapse/expand so chat never eats the whole screen on mobile */}
      <button
        onClick={() => setCollapsed((c) => !c)}
        className="px-4 py-3 border-b border-white/5 flex items-center justify-between text-left"
      >
        <span className="flex items-center gap-2">
          <h3 className="text-white font-semibold text-sm">Room Chat</h3>
          {collapsed && messages.length > 0 && (
            <span className="text-white/30 text-xs truncate max-w-[140px]">
              {messages[messages.length - 1].type === "system"
                ? messages[messages.length - 1].text
                : `${messages[messages.length - 1].playerName}: ${messages[messages.length - 1].text}`}
            </span>
          )}
        </span>
        <span className="flex items-center gap-2 flex-shrink-0">
          <span className="text-white/30 text-xs">{messages.length} messages</span>
          {collapsed ? <ChevronDown className="w-4 h-4 text-white/40" /> : <ChevronUp className="w-4 h-4 text-white/40" />}
        </span>
      </button>

      {collapsed ? null : (
        <>
      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3 min-h-0">
        <AnimatePresence>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={cn(
                "flex flex-col",
                msg.playerId === currentPlayerId && "items-end",
                msg.type === "system" && "items-center"
              )}
            >
              {msg.type === "system" ? (
                <span className="text-vault-gold/60 text-xs bg-vault-gold/5 px-3 py-1 rounded-full">
                  {msg.text}
                </span>
              ) : (
                <>
                  <span className="text-white/40 text-xs mb-1">{msg.playerName}</span>
                  <div
                    className={cn(
                      "px-3 py-2 rounded-xl max-w-[80%] text-sm",
                      msg.playerId === currentPlayerId
                        ? "bg-vault-gold/20 text-vault-gold-light"
                        : "bg-white/5 text-white/80"
                    )}
                  >
                    {msg.text}
                  </div>
                </>
              )}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Quick reactions */}
      <AnimatePresence>
        {showReactions && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="px-4 py-2 border-t border-white/5 overflow-hidden"
          >
            <div className="flex gap-2 flex-wrap">
              {QUICK_REACTIONS.map((reaction) => (
                <button
                  key={reaction}
                  onClick={() => {
                    onSend(reaction, "reaction");
                    setShowReactions(false);
                  }}
                  className="px-3 py-1 bg-white/5 rounded-lg text-sm hover:bg-white/10 transition-colors"
                >
                  {reaction}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Stickers */}
      <AnimatePresence>
        {showStickers && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="px-4 py-2 border-t border-white/5 overflow-hidden"
          >
            <div className="flex gap-2 flex-wrap">
              {STICKERS.map((sticker) => (
                <button
                  key={sticker}
                  onClick={() => {
                    onSend(sticker, "emoji");
                    setShowStickers(false);
                  }}
                  className="text-2xl hover:scale-125 transition-transform p-1"
                >
                  {sticker}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Input */}
      <div className="p-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))] border-t border-white/5 flex gap-2">
        <button
          onClick={() => { setShowReactions(!showReactions); setShowStickers(false); }}
          className="p-2 text-white/30 hover:text-vault-gold transition-colors"
        >
          <Smile className="w-5 h-5" />
        </button>
        <button
          onClick={() => { setShowStickers(!showStickers); setShowReactions(false); }}
          className="p-2 text-white/30 hover:text-vault-gold transition-colors"
        >
          <Sticker className="w-5 h-5" />
        </button>
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
          placeholder="Type a message..."
          className="flex-1 bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm text-white placeholder:text-white/20 focus:outline-none focus:border-vault-gold/30"
        />
        <button
          onClick={handleSend}
          disabled={!input.trim()}
          className="p-2 bg-gold-sheen text-vault-black rounded-xl hover:brightness-110 transition-all disabled:opacity-30 disabled:bg-vault-gold/20 disabled:text-vault-gold"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
        </>
      )}
    </div>
  );
}
