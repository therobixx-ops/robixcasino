"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "../../lib/utils";

export type PrankType = 
  | "confetti" 
  | "explosion" 
  | "tomato" 
  | "toilet_paper" 
  | "smoke" 
  | "rainbow" 
  | "lightning" 
  | "disco" 
  | "troll_mask" 
  | "win_flex" 
  | "mvp" 
  | "chip_rain" 
  | "spotlight" 
  | "shake"
  // AI-triggered room-wide events (cosmetic only, never affect gameplay)
  | "gold_rain"
  | "confetti_burst"
  | "laser_show"
  | "lightning_storm"
  | "floating_coins"
  | "emoji_storm"
  | "fireworks"
  | "holographic";

interface PrankOverlayProps {
  activePrank: { type: PrankType; targetId?: string } | null;
  onComplete?: () => void;
}

export function PrankOverlay({ activePrank, onComplete }: PrankOverlayProps) {
  const [particles, setParticles] = useState<Array<{ id: number; x: number; delay: number; color: string; emoji?: string }>>([]);

  useEffect(() => {
    if (!activePrank) return;

    const timer = setTimeout(() => {
      onComplete?.();
    }, 4000);

    // Generate particles based on prank type
    if (
      activePrank.type === "confetti" ||
      activePrank.type === "chip_rain" ||
      activePrank.type === "gold_rain" ||
      activePrank.type === "confetti_burst" ||
      activePrank.type === "floating_coins" ||
      activePrank.type === "emoji_storm"
    ) {
      const emojiByType: Record<string, string | undefined> = {
        chip_rain: "💎",
        gold_rain: "🪙",
        floating_coins: "🪙",
        emoji_storm: ["🔥", "😂", "💀", "👀", "🎉", "💰"][Math.floor(Math.random() * 6)],
      };
      const newParticles = Array.from({ length: activePrank.type === "emoji_storm" ? 45 : 60 }, (_, i) => ({
        id: i,
        x: Math.random() * 100,
        delay: Math.random() * 2,
        color: ["#d4af37", "#10b981", "#ef4444", "#3b82f6", "#f472b6"][Math.floor(Math.random() * 5)],
        emoji:
          activePrank.type === "emoji_storm"
            ? ["🔥", "😂", "💀", "👀", "🎉", "💰"][Math.floor(Math.random() * 6)]
            : emojiByType[activePrank.type],
      }));
      setParticles(newParticles);
    }

    return () => {
      clearTimeout(timer);
      setParticles([]);
    };
  }, [activePrank, onComplete]);

  if (!activePrank) return null;

  const { type } = activePrank;

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-50 pointer-events-none overflow-hidden"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        {/* Confetti / Chip Rain */}
        {(type === "confetti" || type === "chip_rain" || type === "gold_rain" || type === "confetti_burst" || type === "floating_coins" || type === "emoji_storm") && (
          <>
            {particles.map((p) => (
              <motion.div
                key={p.id}
                className={cn("absolute", p.emoji ? "text-2xl" : "w-3 h-3 rounded-sm")}
                style={{
                  left: `${p.x}%`,
                  backgroundColor: p.emoji ? undefined : p.color,
                }}
                initial={{ y: -50, opacity: 1, rotate: 0 }}
                animate={{
                  y: "110vh",
                  opacity: [1, 1, 0],
                  rotate: Math.random() * 720,
                }}
                transition={{
                  duration: 2 + Math.random() * 2,
                  delay: p.delay,
                  ease: "linear",
                }}
              >
                {p.emoji}
              </motion.div>
            ))}
          </>
        )}

        {/* Tomato throw */}
        {type === "tomato" && (
          <motion.div
            className="absolute text-6xl"
            initial={{ x: "-10vw", y: "20vh", scale: 0.5, opacity: 0 }}
            animate={{ x: "50vw", y: "40vh", scale: 1.5, opacity: 1 }}
            transition={{ duration: 0.4, ease: "easeOut" }}
          >
            🍅
          </motion.div>
        )}

        {/* Toilet paper */}
        {type === "toilet_paper" && (
          <motion.div
            className="absolute inset-0"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            {Array.from({ length: 8 }).map((_, i) => (
              <motion.div
                key={i}
                className="absolute bg-white/90 rounded-full"
                style={{
                  width: `${20 + Math.random() * 40}px`,
                  height: `${20 + Math.random() * 40}px`,
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                }}
                initial={{ scale: 0, rotate: 0 }}
                animate={{ scale: 1, rotate: 360 }}
                transition={{ delay: i * 0.1, duration: 0.5 }}
              />
            ))}
          </motion.div>
        )}

        {/* Smoke bomb */}
        {type === "smoke" && (
          <motion.div
            className="absolute inset-0 flex items-center justify-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 0.8, 0] }}
            transition={{ duration: 3 }}
          >
            <div className="w-[600px] h-[600px] rounded-full bg-gray-400/30 blur-[100px]" />
          </motion.div>
        )}

        {/* Rainbow table */}
        {type === "rainbow" && (
          <motion.div
            className="absolute inset-0"
            animate={{
              background: [
                "linear-gradient(45deg, rgba(239,68,68,0.1), rgba(59,130,246,0.1))",
                "linear-gradient(45deg, rgba(16,185,129,0.1), rgba(245,158,11,0.1))",
                "linear-gradient(45deg, rgba(139,92,246,0.1), rgba(236,72,153,0.1))",
                "linear-gradient(45deg, rgba(239,68,68,0.1), rgba(59,130,246,0.1))",
              ],
            }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        )}

        {/* Lightning */}
        {type === "lightning" && (
          <>
            {[0, 0.3, 0.6].map((delay, i) => (
              <motion.div
                key={i}
                className="absolute inset-0 bg-white"
                initial={{ opacity: 0 }}
                animate={{ opacity: [0, 0.3, 0] }}
                transition={{ delay, duration: 0.1 }}
              />
            ))}
          </>
        )}

        {/* Disco mode */}
        {type === "disco" && (
          <motion.div
            className="absolute inset-0"
            animate={{
              background: [
                "radial-gradient(circle at 20% 20%, rgba(212,175,55,0.15), transparent)",
                "radial-gradient(circle at 80% 80%, rgba(16,185,129,0.15), transparent)",
                "radial-gradient(circle at 50% 50%, rgba(239,68,68,0.15), transparent)",
                "radial-gradient(circle at 20% 80%, rgba(59,130,246,0.15), transparent)",
              ],
            }}
            transition={{ duration: 1, repeat: Infinity }}
          />
        )}

        {/* Troll mask */}
        {type === "troll_mask" && (
          <motion.div
            className="absolute top-1/4 left-1/2 -translate-x-1/2 text-8xl"
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: "spring", stiffness: 200 }}
          >
            🎭
          </motion.div>
        )}

        {/* Win flex */}
        {type === "win_flex" && (
          <motion.div
            className="absolute inset-0 flex items-center justify-center"
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ type: "spring" }}
          >
            <div className="text-center">
              <motion.div
                className="text-8xl mb-4"
                animate={{ y: [0, -20, 0] }}
                transition={{ duration: 1, repeat: Infinity }}
              >
                💯
              </motion.div>
              <p className="text-3xl font-bold text-gold-gradient">FLEX!</p>
            </div>
          </motion.div>
        )}

        {/* MVP */}
        {type === "mvp" && (
          <motion.div
            className="absolute inset-0 flex items-center justify-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <div className="text-center">
              <motion.div
                className="text-9xl mb-4"
                animate={{ rotate: [0, 10, -10, 0], scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                🏆
              </motion.div>
              <p className="text-4xl font-bold text-gold-gradient">MVP!</p>
            </div>
          </motion.div>
        )}

        {/* Spotlight */}
        {type === "spotlight" && (
          <motion.div
            className="absolute inset-0"
            style={{
              background: "radial-gradient(circle at 50% 50%, rgba(212,175,55,0.2) 0%, transparent 60%)",
            }}
            animate={{ opacity: [0.3, 0.6, 0.3] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        )}

        {/* Screen shake */}
        {type === "shake" && (
          <motion.div
            className="absolute inset-0"
            animate={{ x: [-8, 8, -8, 8, 0], y: [-4, 4, -4, 4, 0] }}
            transition={{ duration: 0.4 }}
          />
        )}

        {/* Laser Show — sweeping color beams across the room */}
        {type === "laser_show" && (
          <>
            {[0, 1, 2, 3, 4].map((i) => (
              <motion.div
                key={i}
                className="absolute top-0 h-full w-1"
                style={{
                  left: `${10 + i * 20}%`,
                  background: ["#ff00ff", "#00ffff", "#d4af37", "#10b981", "#ff1744"][i],
                  boxShadow: `0 0 20px 4px ${["#ff00ff", "#00ffff", "#d4af37", "#10b981", "#ff1744"][i]}`,
                }}
                initial={{ scaleY: 0, opacity: 0 }}
                animate={{ scaleY: [0, 1, 1, 0], opacity: [0, 1, 1, 0], x: ["-20vw", "20vw", "-10vw", "15vw"] }}
                transition={{ duration: 3.5, delay: i * 0.15, ease: "easeInOut" }}
              />
            ))}
          </>
        )}

        {/* Lightning Storm — multiple staggered flashes, moodier than a single "lightning" prank */}
        {type === "lightning_storm" && (
          <>
            {[0, 0.25, 0.5, 0.9, 1.3, 1.7].map((delay, i) => (
              <motion.div
                key={i}
                className="absolute inset-0 bg-white"
                initial={{ opacity: 0 }}
                animate={{ opacity: [0, i % 2 === 0 ? 0.35 : 0.15, 0] }}
                transition={{ delay, duration: 0.15 }}
              />
            ))}
          </>
        )}

        {/* Fireworks */}
        {type === "fireworks" && (
          <>
            {Array.from({ length: 6 }).map((_, burst) => {
              const cx = 15 + Math.random() * 70;
              const cy = 15 + Math.random() * 40;
              const color = ["#d4af37", "#ff1744", "#00ffff", "#ff00ff", "#10b981", "#ffeb3b"][burst % 6];
              return (
                <motion.div key={burst} className="absolute" style={{ left: `${cx}%`, top: `${cy}%` }}>
                  {Array.from({ length: 16 }).map((_, i) => {
                    const angle = (i / 16) * Math.PI * 2;
                    return (
                      <motion.div
                        key={i}
                        className="absolute rounded-full"
                        style={{ width: 6, height: 6, backgroundColor: color }}
                        initial={{ x: 0, y: 0, opacity: 1 }}
                        animate={{ x: Math.cos(angle) * 90, y: Math.sin(angle) * 90, opacity: 0 }}
                        transition={{ duration: 1.2, delay: burst * 0.35, ease: "easeOut" }}
                      />
                    );
                  })}
                </motion.div>
              );
            })}
          </>
        )}

        {/* Holographic overlay */}
        {type === "holographic" && (
          <motion.div
            className="absolute inset-0"
            style={{
              background:
                "repeating-linear-gradient(100deg, rgba(0,255,255,0.08) 0px, rgba(255,0,255,0.08) 40px, rgba(212,175,55,0.08) 80px, transparent 120px)",
              mixBlendMode: "screen",
            }}
            animate={{ backgroundPositionX: ["0%", "100%"] }}
            transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
          />
        )}

        {/* Explosion */}
        {type === "explosion" && (
          <motion.div
            className="absolute inset-0 flex items-center justify-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 1, 0] }}
            transition={{ duration: 0.8 }}
          >
            <motion.div
              className="w-96 h-96 rounded-full bg-vault-gold/30 blur-[80px]"
              animate={{ scale: [0.5, 2], opacity: [1, 0] }}
              transition={{ duration: 0.8 }}
            />
          </motion.div>
        )}
      </motion.div>
    </AnimatePresence>
  );
}
