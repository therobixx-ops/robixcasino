"use client";

import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, ExternalLink } from "lucide-react";
import { AdPayload } from "../../types";

interface AdRunnerProps {
  payload: AdPayload | null;
  onComplete: (watchedMs: number, skipped: boolean, clicked: boolean) => void;
  visible: boolean;
}

export function AdRunner({ payload, onComplete, visible }: AdRunnerProps) {
  const [dismissed, setDismissed] = useState(false);
  const [canSkip, setCanSkip] = useState(false);
  const [timer, setTimer] = useState(0);
  const startTime = useRef<number>(0);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (!visible || !payload || dismissed) return;
    startTime.current = Date.now();
    setCanSkip(payload.mandatory);
    setTimer(payload.skipTimer);

    if (!payload.mandatory && payload.skipTimer > 0) {
      let remaining = payload.skipTimer;
      intervalRef.current = setInterval(() => {
        remaining -= 1;
        setTimer(remaining);
        if (remaining <= 0) {
          setCanSkip(true);
          if (intervalRef.current) clearInterval(intervalRef.current);
        }
      }, 1000);
    } else if (!payload.mandatory) {
      setCanSkip(true);
    }

    const autoDismiss = setTimeout(() => handleDismiss(false), payload.duration + 500);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      clearTimeout(autoDismiss);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visible, payload, dismissed]);

  const handleDismiss = (skipped: boolean) => {
    if (dismissed) return;
    setDismissed(true);
    const watchedMs = Date.now() - startTime.current;
    onComplete(watchedMs, skipped, false);
  };

  const handleClick = () => {
    if (payload?.destinationUrl) {
      window.open(payload.destinationUrl, "_blank");
      const watchedMs = Date.now() - startTime.current;
      onComplete(watchedMs, false, true);
    }
  };

  const animationVariants = {
    fade: { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 } },
    slide: { initial: { y: 50, opacity: 0 }, animate: { y: 0, opacity: 1 }, exit: { y: 50, opacity: 0 } },
    scale: { initial: { scale: 0.8, opacity: 0 }, animate: { scale: 1, opacity: 1 }, exit: { scale: 0.8, opacity: 0 } },
    zoom: { initial: { scale: 0.5, opacity: 0 }, animate: { scale: 1, opacity: 1 }, exit: { scale: 1.5, opacity: 0 } },
  };

  const variant = payload ? animationVariants[payload.animation] : animationVariants.fade;

  return (
    <AnimatePresence>
      {visible && payload && !dismissed && (
        <motion.div
          className="absolute inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm"
          initial={variant.initial}
          animate={variant.animate}
          exit={variant.exit}
          transition={{ duration: 0.4 }}
        >
          <div className="relative max-w-md w-full mx-4 rounded-2xl overflow-hidden border border-[#d4af37]/30 bg-[#0a0a0a] shadow-2xl">
            <div className="relative aspect-video bg-black flex items-center justify-center">
              {payload.format === "mp4" || payload.format === "webm" ? (
                <video src={payload.sourceUrl} autoPlay muted={false} loop={false} className="w-full h-full object-cover" />
              ) : payload.format === "lottie" ? (
                <div className="text-[#d4af37] text-sm">Lottie: {payload.title}</div>
              ) : (
                <img src={payload.sourceUrl} alt={payload.title} className="w-full h-full object-cover" />
              )}

              {canSkip && (
                <button
                  onClick={() => handleDismiss(true)}
                  className="absolute top-3 right-3 p-1.5 rounded-full bg-black/60 text-white hover:bg-black/80 transition"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
              {!canSkip && timer > 0 && (
                <div className="absolute top-3 right-3 px-2 py-1 rounded-full bg-black/60 text-white text-xs font-mono">
                  Skip in {timer}s
                </div>
              )}
            </div>

            <div className="p-4 space-y-3">
              <h3 className="text-lg font-bold text-white">{payload.title}</h3>
              {payload.ctaText && (
                <button
                  onClick={handleClick}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#d4af37] to-amber-600 text-black font-bold text-sm flex items-center justify-center gap-2 hover:brightness-110 transition"
                >
                  {payload.ctaText}
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
