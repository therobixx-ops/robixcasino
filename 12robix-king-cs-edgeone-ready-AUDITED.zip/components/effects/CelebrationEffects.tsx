"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Crown, Gem } from "lucide-react";

interface CelebrationEffectsProps {
  type: "win" | "streak" | null;
  data?: { name?: string; streak?: number };
  onComplete?: () => void;
}

// Royal palette — gold, ivory and deep wine, matching the rest of the
// table's identity (text-gold-gradient, vault-wine, etc.) instead of the
// generic neon confetti mix this used to fall back to.
const WIN_CHIP_COLORS = ["#d4af37", "#f4d03f", "#f4e4bc", "#b23a4a"];
const STREAK_CHIP_COLORS = ["#f4d03f", "#f97316", "#d4af37", "#f4e4bc"];

export function CelebrationEffects({ type, data, onComplete }: CelebrationEffectsProps) {
  const [particles, setParticles] = useState<
    Array<{ id: number; x: number; delay: number; color: string; size: number }>
  >([]);

  useEffect(() => {
    if (!type) return;

    const isTouch = typeof window !== "undefined" && window.matchMedia("(pointer: coarse)").matches;
    const particleCount = isTouch ? 14 : 26;
    const palette = type === "win" ? WIN_CHIP_COLORS : STREAK_CHIP_COLORS;
    const newParticles = Array.from({ length: particleCount }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      delay: Math.random() * 0.5,
      color: palette[Math.floor(Math.random() * palette.length)],
      size: 5 + Math.random() * 6,
    }));
    setParticles(newParticles);

    // A quick, confident beat rather than a lingering overlay — the game's
    // own in-panel result reveal carries the detail (amount, payouts); this
    // is just the cinematic flash that opens it. Room.tsx also clears this
    // the instant the round moves on, so this is a safety fallback timer,
    // not the primary way it ends.
    const timer = setTimeout(() => {
      onComplete?.();
      setParticles([]);
    }, 2200);

    return () => clearTimeout(timer);
  }, [type, onComplete]);

  if (!type) return null;

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-50 pointer-events-none flex items-center justify-center overflow-hidden"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0, transition: { duration: 0.25 } }}
      >
        {/* Cinematic backdrop dim — a spotlight, not a flat overlay */}
        <motion.div
          className="absolute inset-0"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          style={{ background: "radial-gradient(circle at center, rgba(0,0,0,0.4) 0%, rgba(0,0,0,0.6) 100%)" }}
        />

        {type === "win" && (
          <motion.div
            className="absolute w-[140vmin] h-[140vmin] pointer-events-none"
            initial={{ opacity: 0, rotate: 0 }}
            animate={{ opacity: [0, 0.55, 0.35], rotate: 40 }}
            transition={{ duration: 2.2, ease: "easeOut" }}
            style={{
              background:
                "conic-gradient(from 0deg, transparent 0deg, rgba(212,175,55,0.22) 8deg, transparent 20deg, transparent 160deg, rgba(212,175,55,0.16) 172deg, transparent 184deg, transparent 340deg, rgba(212,175,55,0.22) 352deg, transparent 360deg)",
            }}
          />
        )}

        {/* Falling chips */}
        <div className="absolute inset-0 overflow-hidden">
          {particles.map((p) => (
            <motion.div
              key={p.id}
              className="absolute rounded-full"
              style={{
                left: `${p.x}%`,
                width: p.size,
                height: p.size,
                background: `radial-gradient(circle at 35% 30%, ${p.color}, ${p.color}99 55%, transparent 100%)`,
                boxShadow: `0 0 6px ${p.color}77`,
              }}
              initial={{ y: -20, opacity: 1 }}
              animate={{
                y: "110vh",
                opacity: [1, 1, 0],
                rotate: Math.random() * 720,
              }}
              transition={{
                duration: 1.6 + Math.random() * 0.8,
                delay: p.delay,
                ease: "linear",
              }}
            />
          ))}
        </div>

        {/* Center content */}
        <motion.div
          initial={{ scale: 0.6, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", stiffness: 210, damping: 20 }}
          className="text-center relative z-10"
        >
          {type === "win" && <RoyalWinMark name={data?.name || "You"} />}

          {type === "streak" && (
            <>
              <motion.div
                className="text-8xl mb-4"
                animate={{ y: [0, -15, 0] }}
                transition={{ duration: 1, repeat: Infinity }}
              >
                🔥
              </motion.div>
              <h2 className="text-4xl font-bold text-orange-400 mb-2">{data?.streak || 0} WIN STREAK!</h2>
              <p className="text-white/60 text-lg">On fire! Keep it going!</p>
            </>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

/** The royal-casino win mark: an engraved gold seal ring around a crown,
 * a shimmering "ROYAL WIN" wordmark, and a quiet gold underline — replaces
 * the old trophy-emoji "WINNER!" pop. */
function RoyalWinMark({ name }: { name: string }) {
  return (
    <div>
      <motion.div
        className="relative mx-auto mb-5 w-28 h-28"
        initial={{ rotate: -8 }}
        animate={{ rotate: 0 }}
        transition={{ type: "spring", stiffness: 180, damping: 16 }}
      >
        {/* soft gold glow */}
        <div
          className="absolute inset-0 rounded-full blur-xl opacity-70"
          style={{ background: "radial-gradient(circle, rgba(212,175,55,0.55) 0%, transparent 70%)" }}
        />
        {/* outer engraved ring */}
        <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full">
          <circle cx="50" cy="50" r="47" fill="none" stroke="#d4af37" strokeOpacity="0.55" strokeWidth="1.5" />
          <motion.circle
            cx="50"
            cy="50"
            r="40"
            fill="none"
            stroke="#d4af37"
            strokeOpacity="0.3"
            strokeWidth="1"
            strokeDasharray="2 5"
            style={{ transformOrigin: "50px 50px" }}
            animate={{ rotate: 360 }}
            transition={{ duration: 18, repeat: Infinity, ease: "linear" }}
          />
        </svg>
        {/* hub with crown */}
        <div
          className="absolute inset-[14%] rounded-full flex items-center justify-center border-2"
          style={{
            borderColor: "#d4af37",
            background: "radial-gradient(circle at 40% 30%, #2a2210 0%, #0e0d0a 75%)",
            boxShadow: "0 0 25px rgba(212,175,55,0.35), inset 0 0 12px rgba(0,0,0,0.6)",
          }}
        >
          <Crown className="w-9 h-9 text-vault-gold drop-shadow-[0_0_6px_rgba(212,175,55,0.8)]" strokeWidth={1.75} />
        </div>
      </motion.div>

      <motion.div
        className="flex items-center justify-center gap-2"
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.12 }}
      >
        <Gem className="w-3.5 h-3.5 text-vault-gold/70" strokeWidth={1.5} />
        <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-[0.15em] text-gold-gradient uppercase">
          Royal Win
        </h2>
        <Gem className="w-3.5 h-3.5 text-vault-gold/70" strokeWidth={1.5} />
      </motion.div>

      <motion.div
        className="mx-auto mt-2 h-px w-40"
        initial={{ scaleX: 0, opacity: 0 }}
        animate={{ scaleX: 1, opacity: 1 }}
        transition={{ delay: 0.25, duration: 0.5 }}
        style={{ background: "linear-gradient(90deg, transparent, #d4af37, transparent)" }}
      />

      <motion.p
        className="mt-3 text-sm tracking-[0.2em] uppercase text-white/50 font-display"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        {name} wins the round
      </motion.p>
    </div>
  );
}
