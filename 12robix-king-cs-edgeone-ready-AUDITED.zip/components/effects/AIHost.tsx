"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Mic } from "lucide-react";
import { cn } from "../../lib/utils";

interface AIHostProps {
  announcement: { text: string; type: string } | null;
}

const HOST_PERSONALITIES = [
  "🎙️",
  "🎰",
  "🃏",
  "🎩",
];

export function AIHost({ announcement }: AIHostProps) {
  const [visible, setVisible] = useState(false);
  const [currentText, setCurrentText] = useState("");
  const [personality] = useState(() => HOST_PERSONALITIES[Math.floor(Math.random() * HOST_PERSONALITIES.length)]);

  useEffect(() => {
    if (!announcement) {
      setVisible(false);
      return;
    }

    setCurrentText(announcement.text);
    setVisible(true);

    const timer = setTimeout(() => {
      setVisible(false);
    }, 6000);

    return () => clearTimeout(timer);
  }, [announcement]);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0, y: -60, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -30, scale: 0.95 }}
          transition={{ type: "spring", stiffness: 300, damping: 25 }}
          className={cn(
            "fixed top-6 left-1/2 -translate-x-1/2 z-50 max-w-lg w-[90%]",
            "glass-strong px-6 py-4 rounded-2xl border",
            announcement?.type === "celebration" && "border-vault-gold/30 neon-glow",
            announcement?.type === "warning" && "border-red-500/30",
            announcement?.type === "info" && "border-blue-500/30",
            announcement?.type === "funny" && "border-purple-500/30"
          )}
        >
          <div className="flex items-start gap-3">
            <motion.div
              className="w-10 h-10 rounded-full bg-vault-gold/20 flex items-center justify-center text-xl flex-shrink-0"
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              {personality}
            </motion.div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <Mic className="w-3 h-3 text-vault-gold/60" />
                <span className="text-vault-gold/60 text-xs uppercase tracking-wider font-medium">AI Host</span>
              </div>
              <motion.p
                className="text-white font-medium leading-relaxed"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
              >
                {currentText}
              </motion.p>
            </div>
          </div>

          {/* Sound wave animation */}
          <div className="flex items-center gap-1 mt-3 ml-13">
            {[...Array(5)].map((_, i) => (
              <motion.div
                key={i}
                className="w-1 bg-vault-gold/40 rounded-full"
                animate={{ height: [4, 12, 4] }}
                transition={{
                  duration: 0.6,
                  repeat: Infinity,
                  delay: i * 0.1,
                }}
              />
            ))}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
