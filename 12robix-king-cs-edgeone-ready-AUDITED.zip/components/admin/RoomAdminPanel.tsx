"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Users, Megaphone, Timer, Trophy, Download, Ban, UserX,
  VolumeX, Gift, Minus, ScrollText, ChevronDown,
} from "lucide-react";
import { cn, formatChips } from "../../lib/utils";
import type { Room, ActivityLogEntry } from "../../types";

type Tab = "players" | "controls" | "log";

interface RoomAdminPanelProps {
  room: Room;
  activityLog: ActivityLogEntry[];
  onKick: (id: string) => void;
  onBan: (id: string) => void;
  onMute: (id: string) => void;
  onGiftChips: (id: string, amount: number) => void;
  onRemoveChips: (id: string, amount: number) => void;
  onSetTimer: (seconds: number) => void;
  onBroadcast: (message: string) => void;
  onStartTournament: () => void;
  onExportLogs: () => void;
}

export function AdminDashboard({
  room,
  activityLog,
  onKick,
  onBan,
  onMute,
  onGiftChips,
  onRemoveChips,
  onSetTimer,
  onBroadcast,
  onStartTournament,
  onExportLogs,
}: RoomAdminPanelProps) {
  const [tab, setTab] = useState<Tab>("players");
  const [chipAmounts, setChipAmounts] = useState<Record<string, string>>({});
  const [timerSeconds, setTimerSeconds] = useState("30");
  const [broadcastMsg, setBroadcastMsg] = useState("");
  const [confirmDanger, setConfirmDanger] = useState<{ id: string; action: "kick" | "ban" } | null>(null);

  const getAmount = (id: string) => parseInt(chipAmounts[id] || "0", 10) || 0;
  const setAmount = (id: string, value: string) => setChipAmounts((prev) => ({ ...prev, [id]: value }));

  const tabs: { id: Tab; label: string; icon: typeof Users }[] = [
    { id: "players", label: "Players", icon: Users },
    { id: "controls", label: "Controls", icon: Megaphone },
    { id: "log", label: "Activity", icon: ScrollText },
  ];

  return (
    <div className="glass-strong rounded-2xl p-4 metallic-gold-border">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-gold-gradient font-bold text-lg">Room Admin</h3>
        <button
          onClick={onExportLogs}
          className="flex items-center gap-1.5 text-xs text-white/50 hover:text-white/90 transition-colors px-2 py-1 rounded-lg hover:bg-white/5"
        >
          <Download className="w-3.5 h-3.5" />
          Export logs
        </button>
      </div>

      <div className="flex gap-1 mb-4 bg-black/30 rounded-xl p-1">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={cn(
              "flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-medium transition-all",
              tab === t.id ? "bg-white/10 text-vault-gold" : "text-white/40 hover:text-white/70"
            )}
          >
            <t.icon className="w-3.5 h-3.5" />
            {t.label}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {tab === "players" && (
          <motion.div key="players" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-2">
            {room.players.length === 0 && (
              <p className="text-white/30 text-sm text-center py-6">No players in this room yet.</p>
            )}
            {room.players.map((p) => (
              <div key={p.id} className="bg-white/5 rounded-xl p-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="text-white font-medium truncate">{p.name}</span>
                    {p.isHost && <span className="text-[10px] uppercase tracking-wide text-vault-gold shrink-0">Host</span>}
                  </div>
                  <span className="text-white/50 text-sm shrink-0">{formatChips(p.chips)} chips</span>
                </div>
                <div className="flex flex-wrap items-center gap-1.5">
                  <input
                    type="number"
                    placeholder="Amount"
                    value={chipAmounts[p.id] || ""}
                    onChange={(e) => setAmount(p.id, e.target.value)}
                    className="w-20 bg-black/30 border border-white/10 rounded-lg px-2 py-1 text-xs text-white placeholder:text-white/20 focus:outline-none focus:border-vault-gold/50"
                  />
                  <button
                    onClick={() => getAmount(p.id) > 0 && onGiftChips(p.id, getAmount(p.id))}
                    className="flex items-center gap-1 text-xs px-2 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 transition-colors"
                  >
                    <Gift className="w-3 h-3" /> Gift
                  </button>
                  <button
                    onClick={() => getAmount(p.id) > 0 && onRemoveChips(p.id, getAmount(p.id))}
                    className="flex items-center gap-1 text-xs px-2 py-1 rounded-lg bg-orange-500/10 text-orange-400 hover:bg-orange-500/20 transition-colors"
                  >
                    <Minus className="w-3 h-3" /> Remove
                  </button>
                  <button
                    onClick={() => onMute(p.id)}
                    className="flex items-center gap-1 text-xs px-2 py-1 rounded-lg bg-white/5 text-white/60 hover:bg-white/10 transition-colors"
                  >
                    <VolumeX className="w-3 h-3" /> Mute
                  </button>
                  <button
                    onClick={() => setConfirmDanger({ id: p.id, action: "kick" })}
                    className="flex items-center gap-1 text-xs px-2 py-1 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors"
                  >
                    <UserX className="w-3 h-3" /> Kick
                  </button>
                  <button
                    onClick={() => setConfirmDanger({ id: p.id, action: "ban" })}
                    className="flex items-center gap-1 text-xs px-2 py-1 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors"
                  >
                    <Ban className="w-3 h-3" /> Ban
                  </button>
                </div>
                {confirmDanger?.id === p.id && (
                  <div className="mt-2 flex items-center justify-between bg-red-500/10 rounded-lg px-3 py-2">
                    <span className="text-xs text-red-300">
                      {confirmDanger.action === "kick" ? "Kick" : "Ban"} {p.name}?
                    </span>
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          if (confirmDanger.action === "kick") onKick(p.id);
                          else onBan(p.id);
                          setConfirmDanger(null);
                        }}
                        className="text-xs font-medium text-red-300 hover:text-red-200"
                      >
                        Confirm
                      </button>
                      <button onClick={() => setConfirmDanger(null)} className="text-xs text-white/40 hover:text-white/70">
                        Cancel
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </motion.div>
        )}

        {tab === "controls" && (
          <motion.div key="controls" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-4">
            <div>
              <label className="text-white/50 text-xs uppercase tracking-wider mb-2 block">Broadcast message</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={broadcastMsg}
                  onChange={(e) => setBroadcastMsg(e.target.value)}
                  placeholder="Message to everyone in the room"
                  className="flex-1 bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-white/20 focus:outline-none focus:border-vault-gold/50"
                />
                <button
                  onClick={() => { if (broadcastMsg.trim()) { onBroadcast(broadcastMsg.trim()); setBroadcastMsg(""); } }}
                  className="px-4 py-2 rounded-lg bg-gold-sheen text-vault-black text-sm font-bold hover:brightness-110 transition-all shrink-0"
                >
                  Send
                </button>
              </div>
            </div>

            <div>
              <label className="text-white/50 text-xs uppercase tracking-wider mb-2 block">Round timer</label>
              <div className="flex gap-2">
                <input
                  type="number"
                  value={timerSeconds}
                  onChange={(e) => setTimerSeconds(e.target.value)}
                  className="w-24 bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-vault-gold/50"
                />
                <button
                  onClick={() => { const sec = parseInt(timerSeconds, 10); if (sec > 0) onSetTimer(sec); }}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-white/5 text-white/80 text-sm hover:bg-white/10 transition-colors"
                >
                  <Timer className="w-4 h-4" /> Set timer
                </button>
              </div>
            </div>

            <button
              onClick={onStartTournament}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-vault-gold/10 text-vault-gold text-sm font-medium hover:bg-vault-gold/20 transition-colors"
            >
              <Trophy className="w-4 h-4" /> Start tournament
            </button>
          </motion.div>
        )}

        {tab === "log" && (
          <motion.div key="log" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-1 max-h-72 overflow-y-auto">
            {activityLog.length === 0 && (
              <p className="text-white/30 text-sm text-center py-6">No activity yet.</p>
            )}
            {[...activityLog].reverse().map((entry) => (
              <div key={entry.id} className="flex items-start gap-2 py-1.5 border-b border-white/5 last:border-0">
                <ChevronDown className="w-3 h-3 text-white/20 mt-1 rotate-[-90deg] shrink-0" />
                <div className="min-w-0">
                  <p className="text-white/70 text-xs">{entry.details}</p>
                  <p className="text-white/25 text-[10px]">{new Date(entry.timestamp).toLocaleTimeString()}</p>
                </div>
              </div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
