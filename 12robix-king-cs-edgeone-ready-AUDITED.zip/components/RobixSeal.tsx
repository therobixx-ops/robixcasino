"use client";

import { Crown } from "lucide-react";
import { cn } from "../lib/utils";

interface RobixSealProps {
  size?: number;
  className?: string;
  glow?: boolean;
}

/**
 * The ROBIX KING CS mark: a thin engraved bezel (outer ring) with a slowly
 * rotating dashed inner track — a nod to a minted coin / roulette wheel rim
 * without being a literal wheel graphic. This is the one signature visual
 * element reused everywhere the brand appears (intro, lobby, room header)
 * so it reads as a considered mark rather than a stock crown icon alone.
 */
export function RobixSeal({ size = 72, className, glow = true }: RobixSealProps) {
  return (
    <div
      className={cn("relative flex items-center justify-center flex-shrink-0", className)}
      style={{ width: size, height: size }}
    >
      {glow && (
        <div
          className="absolute inset-0 rounded-full bg-vault-gold/25 blur-xl"
          aria-hidden
        />
      )}
      <svg
        viewBox="0 0 100 100"
        width={size}
        height={size}
        className="absolute inset-0"
        aria-hidden
      >
        <defs>
          <linearGradient id="seal-rim" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#fdf3c4" />
            <stop offset="22%" stopColor="#d4af37" />
            <stop offset="45%" stopColor="#9c7412" />
            <stop offset="68%" stopColor="#f6dc6b" />
            <stop offset="100%" stopColor="#8a6417" />
          </linearGradient>
          <radialGradient id="seal-dish" cx="50%" cy="42%" r="65%">
            <stop offset="0%" stopColor="#3a2a10" />
            <stop offset="70%" stopColor="#171009" />
            <stop offset="100%" stopColor="#0a0703" />
          </radialGradient>
        </defs>
        <circle cx="50" cy="50" r="46" fill="url(#seal-dish)" stroke="url(#seal-rim)" strokeWidth="1.5" />
        <circle cx="50" cy="50" r="40" fill="none" strokeWidth="1" className="seal-ring-inner" />
      </svg>
      <Crown
        className="relative"
        style={{ width: size * 0.4, height: size * 0.4, color: "#f6dc6b", filter: "drop-shadow(0 1px 2px rgba(0,0,0,0.6))" }}
        strokeWidth={1.75}
      />
    </div>
  );
}
