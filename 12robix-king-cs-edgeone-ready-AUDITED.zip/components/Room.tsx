"use client";

import { useState, useEffect, useCallback, useRef, Suspense, lazy } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Crown, Play, LogOut, Settings, Users, Copy, Check, Shield, Volume2, VolumeX, Palette, Eye, EyeOff, FlagOff } from "lucide-react";
import { useSocket } from "../hooks/useSocket";
import { useAudio } from "../hooks/useAudio";
import { PlayerCard } from "./PlayerCard";
import { Chat } from "./Chat";
import { AIHost } from "./effects/AIHost";
import { PrankOverlay, type PrankType } from "./effects/PrankOverlay";
import { CelebrationEffects } from "./effects/CelebrationEffects";
import { TypingIndicator } from "./social/TypingIndicator";
import { RoomStandings } from "./social/RoomStandings";
import { SessionSummaryModal } from "./social/SessionSummaryModal";
import { RoundHistoryPanel } from "./games/RoundHistoryPanel";
import { AdminDashboard } from "./admin/RoomAdminPanel";
import { THEMES } from "../lib/themes";
import { cn, formatChips } from "../lib/utils";
import type { Player, ActivityLogEntry, GameType } from "../types";

// Lazy load game components for code splitting
const NeonRouletteV2 = lazy(() => import("./games/NeonRouletteV2").then(m => ({ default: m.NeonRouletteV2 })));
const VaultHeistV2 = lazy(() => import("./games/VaultHeistV2").then(m => ({ default: m.VaultHeistV2 })));
const CoinFlip = lazy(() => import("./games/CoinFlip").then(m => ({ default: m.CoinFlip })));
const Dice = lazy(() => import("./games/Dice").then(m => ({ default: m.Dice })));

export function Room() {
  const {
    myId,
    room,
    gameState,
    messages,
    leaveRoom,
    setReady,
    startGame,
    stopGame,
    sendMessage,
    placeBet,
    chooseVault,
    triggerPrank,
    adminKick,
    adminBan,
    adminMute,
    adminChips,
    adminBroadcast,
    adminTimer,
    aiAnnouncement,
    activeEffect,
    typingPlayers,
    startTyping,
    stopTyping,
    sessionRounds,
    sessionSummary,
    clearSessionSummary,
    endSession,
    setSpectating,
    error,
    clearError,
  } = useSocket();

  const audio = useAudio();
  const [copied, setCopied] = useState(false);
  const [showAdmin, setShowAdmin] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [activePrank, setActivePrank] = useState<{ type: PrankType; targetId?: string } | null>(null);
  const [currentTheme, setCurrentTheme] = useState(THEMES[0]);
  const [showThemes, setShowThemes] = useState(false);
  const [celebration, setCelebration] = useState<{ type: "win" | "streak"; data?: any } | null>(null);
  const [activityLog, setActivityLog] = useState<ActivityLogEntry[]>([]);
  const [selectedGameType, setSelectedGameType] = useState<GameType>("neon-roulette");

  // Sync sound
  useEffect(() => { audio.setEnabled(soundEnabled); }, [soundEnabled, audio]);

  useEffect(() => {
    if (!error) return;
    const timer = setTimeout(() => clearError(), 4000);
    return () => clearTimeout(timer);
  }, [error, clearError]);

  // Listen for effects broadcast from the server — this covers both AI-triggered
  // room events (Gold Rain, Laser Show, Fireworks, etc.) and pranks triggered by
  // other players, so everyone in the room actually sees them, not just the sender.
  useEffect(() => {
    if (!activeEffect) return;
    setActivePrank({ type: activeEffect.effect as PrankType, targetId: activeEffect.targetId });
    if (soundEnabled) audio.playPrank(activeEffect.effect);
  }, [activeEffect]);

  // Listen for celebration triggers from game state — fires once per round
  // (on the result phase), and only for a win that's actually mine. Firing
  // it for any player's win (including bots) meant it went off almost every
  // round, stacked visually on top of the game's own inline result panel,
  // and always said "You take the pot!" even when the viewer had lost.
  const lastCelebratedRound = useRef(-1);
  useEffect(() => {
    const gs = gameState as any;
    if (gs?.phase === "result" && gs.round !== lastCelebratedRound.current) {
      // Roulette no longer uses the full-screen celebration overlay at all —
      // its own in-panel result reveal (number, amount count-up, coin burst)
      // is the entire win moment now. Only Vault Heist (which has no
      // equivalent in-panel reveal) still triggers this.
      if (room?.currentGame === "neon-roulette") return;
      lastCelebratedRound.current = gs.round;
      const myPayout = myId ? gs.results?.payouts?.[myId] ?? gs.rewards?.[myId] : undefined;
      if (!myPayout || myPayout <= 0) return;
      setCelebration({ type: "win", data: { name: "You" } });
    }
  }, [gameState, myId, room?.currentGame]);

  // Clear the celebration the moment the round actually moves on, instead of
  // a fixed timer that can outlive a (now shorter) result window and bleed
  // confetti into the next round's betting phase.
  const currentPhase = (gameState as any)?.phase;
  useEffect(() => {
    if (currentPhase && currentPhase !== "result") setCelebration(null);
  }, [currentPhase]);

  if (!room) return null;

  // Identify "me" by this client's actual socket id, not by host-ness —
  // otherwise every browser in the room renders itself as the host.
  const currentPlayer = room.players.find((p) => p.id === myId);
  const isHost = currentPlayer?.isHost ?? false;
  const allReady = room.players.length >= 1 && room.players.every((p) => p.isReady);

  const copyCode = () => {
    navigator.clipboard.writeText(`robixkingcs.app/r/${room.code}`);
    setCopied(true);
    audio.playClick();
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrank = (effect: PrankType, targetId?: string) => {
    triggerPrank(effect, targetId);
    // Visuals + audio now come from the activeEffect listener once the server
    // echoes the broadcast back — keeps every player's screen in sync instead
    // of only the sender seeing it locally.
  };

  const handleStartGame = () => { audio.playClick(); startGame(selectedGameType); };
  const handleSetReady = (ready: boolean) => { audio.playClick(); setReady(ready); };

  const handleThemeChange = (themeId: string) => {
    const theme = THEMES.find((t) => t.id === themeId);
    if (theme) setCurrentTheme(theme);
    setShowThemes(false);
    audio.playClick();
  };

  const addActivity = (entry: Omit<ActivityLogEntry, "id" | "timestamp" | "roomId">) => {
    setActivityLog((prev) => [...prev, {
      ...entry,
      id: Date.now().toString(),
      timestamp: Date.now(),
      roomId: room.id,
    }]);
  };

  return (
    <div 
      className="min-h-dvh text-white overflow-hidden relative transition-colors duration-700"
      style={{ backgroundColor: currentTheme.bg }}
    >
      {/* Celebration Overlay */}
      <CelebrationEffects 
        type={celebration?.type || null} 
        data={celebration?.data}
        onComplete={() => setCelebration(null)}
      />

      {/* AI Host */}
      <AIHost announcement={aiAnnouncement} />

      {/* Error / rejected-action toast */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-4 left-1/2 -translate-x-1/2 z-[100] glass-strong border border-red-500/40 rounded-xl px-4 py-3 text-sm text-red-200 shadow-lg max-w-sm text-center"
          >
            {error}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Prank Effects */}
      <PrankOverlay activePrank={activePrank} onComplete={() => setActivePrank(null)} />

      {/* AI Session Recap */}
      <SessionSummaryModal summary={sessionSummary} onClose={clearSessionSummary} />

      {/* Background — absolute (not fixed) + its own compositing layer so iOS
          Safari doesn't botch repainting it under the blurred glass panels
          during scroll (a known WebKit backdrop-filter + fixed-position bug
          that shows up as blank/black regions until the page repaints). */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden" style={{ contain: "strict" }}>
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] rounded-full blur-[120px]"
          style={{
            backgroundColor: currentTheme.glow.replace("0.3", "0.05"),
            transform: "translateZ(0)",
            willChange: "opacity",
            animation: "bg-glow-pulse 6s ease-in-out infinite",
          }} />
      </div>

      <div className="relative max-w-7xl mx-auto p-4 lg:p-6">
        {/* Header */}
        <header className="metallic-gold-border relative flex items-center justify-between mb-6 glass-strong rounded-2xl px-4 lg:px-6 py-4">
          <div className="flex items-center gap-3 lg:gap-4">
            <div className="flex items-center gap-2">
              <Crown className="w-5 h-5" style={{ color: currentTheme.accent }} />
              <span className="font-display font-bold text-gold-gradient animate-gradient-drift hidden sm:inline">{room.name}</span>
            </div>
            <div className="hidden sm:flex items-center gap-2 text-white/30 text-sm">
              <Users className="w-4 h-4" />
              <span>{room.players.length}/{room.maxPlayers}</span>
            </div>
          </div>

          <div className="flex items-center gap-2 lg:gap-3">
            <button
              onClick={() => { audio.playClick(); setSpectating(!currentPlayer?.isSpectator); }}
              title={currentPlayer?.isSpectator ? "Stop spectating" : "Spectate (watch without betting)"}
              className={cn("p-2 rounded-xl transition-colors", currentPlayer?.isSpectator ? "bg-vault-gold/20 text-vault-gold" : "glass text-white/60 hover:bg-white/10")}
            >
              {currentPlayer?.isSpectator ? <Eye className="w-5 h-5" /> : <EyeOff className="w-5 h-5" />}
            </button>

            <button onClick={() => setSoundEnabled(!soundEnabled)} className="p-2 glass rounded-xl hover:bg-white/10 transition-colors">
              {soundEnabled ? <Volume2 className="w-4 h-4 text-white/60" /> : <VolumeX className="w-4 h-4 text-white/30" />}
            </button>

            {isHost && (
              <button onClick={() => setShowThemes(!showThemes)} className={cn("p-2 rounded-xl transition-colors", showThemes ? "bg-vault-gold/20 text-vault-gold" : "glass text-white/60 hover:bg-white/10")}>
                <Palette className="w-5 h-5" />
              </button>
            )}

            <button onClick={copyCode} className="flex items-center gap-2 glass px-3 lg:px-4 py-2 rounded-xl hover:bg-white/10 transition-colors">
              <span className="font-mono tracking-wider text-sm" style={{ color: currentTheme.accent }}>{room.code}</span>
              {copied ? <Check className="w-4 h-4 text-vault-emerald" /> : <Copy className="w-4 h-4 text-white/40" />}
            </button>

            {isHost && (
              <button onClick={() => setShowAdmin(!showAdmin)} className={cn("p-2 rounded-xl transition-colors", showAdmin ? "bg-vault-gold/20 text-vault-gold" : "glass text-white/60 hover:bg-white/10")}>
                <Settings className="w-5 h-5" />
              </button>
            )}

            <button onClick={() => { audio.playClick(); leaveRoom(); }} className="p-2 glass rounded-xl hover:bg-red-500/20 transition-colors">
              <LogOut className="w-5 h-5 text-red-400" />
            </button>
          </div>
        </header>

        {/* Theme Selector */}
        <AnimatePresence>
          {showThemes && isHost && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden mb-6">
              <div className="glass-strong rounded-2xl p-4">
                <h3 className="text-white/60 text-sm uppercase tracking-wider mb-3">Room Theme</h3>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                  {THEMES.map((theme) => (
                    <button key={theme.id} onClick={() => handleThemeChange(theme.id)}
                      className={cn("p-3 rounded-xl border-2 transition-all text-left", currentTheme.id === theme.id ? "border-vault-gold bg-white/10" : "border-transparent bg-white/5 hover:bg-white/10")}>
                      <div className="w-8 h-8 rounded-full mb-2 mx-auto" style={{ backgroundColor: theme.accent }} />
                      <p className="text-white text-xs font-medium text-center">{theme.name}</p>
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Admin Dashboard */}
        <AnimatePresence>
          {showAdmin && isHost && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden mb-6">
              <AdminDashboard
                room={room}
                activityLog={activityLog}
                onKick={(id) => { adminKick(id); addActivity({ type: "admin", playerId: id, playerName: "Admin", details: "Kicked player" }); }}
                onBan={(id) => { adminBan(id); addActivity({ type: "admin", playerId: id, playerName: "Admin", details: "Banned player" }); }}
                onMute={(id) => { adminMute(id); addActivity({ type: "admin", playerId: id, playerName: "Admin", details: "Muted player" }); }}
                onGiftChips={(id, amount) => { adminChips(id, amount); addActivity({ type: "admin", playerId: id, playerName: "Admin", details: `Gifted ${amount} chips` }); audio.playWin(); }}
                onRemoveChips={(id, amount) => { adminChips(id, -amount); addActivity({ type: "admin", playerId: id, playerName: "Admin", details: `Removed ${amount} chips` }); }}
                onSetTimer={(sec) => { adminTimer(sec); addActivity({ type: "admin", playerId: "system", playerName: "Admin", details: `Set timer to ${sec}s` }); }}
                onBroadcast={(msg) => { adminBroadcast(msg); addActivity({ type: "admin", playerId: "system", playerName: "Admin", details: `Broadcast: ${msg}` }); }}
                onStartTournament={() => { addActivity({ type: "admin", playerId: "system", playerName: "Admin", details: "Started tournament" }); }}
                onExportLogs={() => { const data = JSON.stringify(activityLog, null, 2); const blob = new Blob([data], { type: "application/json" }); const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = `room-${room.code}-logs.json`; a.click(); }}
              />
            </motion.div>
          )}
        </AnimatePresence>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Players Column */}
          <div className="space-y-4 order-2 lg:order-1">
            <h3 className="text-white/40 text-sm font-medium uppercase tracking-wider">Players</h3>
            <div className="space-y-3">
              {room.players.map((player, i) => (
                <PlayerCard
                  key={player.id}
                  player={player}
                  index={i}
                  isCurrentPlayer={player.id === currentPlayer?.id}
                  onPrank={(effect) => handlePrank(effect as PrankType, player.id)}
                />
              ))}
            </div>

            <div className="space-y-2 pt-2">
              {!currentPlayer?.isReady && room.currentGame === null && !currentPlayer?.isSpectator && (
                <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                  onClick={() => handleSetReady(true)}
                  className="w-full py-3 bg-emerald-felt text-white border border-vault-emerald/30 rounded-xl font-semibold hover:brightness-110 neon-glow-emerald transition-all">
                  ✅ Ready Up
                </motion.button>
              )}
              {currentPlayer?.isReady && room.currentGame === null && !currentPlayer?.isSpectator && (
                <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                  onClick={() => handleSetReady(false)}
                  className="w-full py-3 bg-white/5 text-white/40 border border-white/10 rounded-xl font-semibold hover:bg-white/10 transition-colors">
                  Cancel Ready
                </motion.button>
              )}
              {currentPlayer?.isSpectator && room.currentGame === null && (
                <div className="w-full py-3 bg-white/5 text-white/40 border border-white/10 rounded-xl font-semibold text-center flex items-center justify-center gap-2">
                  <Eye className="w-4 h-4" /> Spectating — watching only
                </div>
              )}
              {isHost && room.currentGame === null && (
                <motion.button
                  whileHover={allReady ? { scale: 1.02 } : {}}
                  whileTap={allReady ? { scale: 0.98 } : {}}
                  onClick={handleStartGame}
                  disabled={!allReady}
                  className={cn("w-full py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-2 transition-all",
                    allReady ? "bg-gold-sheen text-vault-black hover:brightness-110 neon-glow" : "bg-white/5 text-white/20 cursor-not-allowed")}>
                  <Play className="w-5 h-5" />
                  {allReady
                    ? `Start ${
                        selectedGameType === "neon-roulette"
                          ? "Neon Roulette"
                          : selectedGameType === "vault-heist"
                          ? "Vault Heist"
                          : selectedGameType === "coin-flip"
                          ? "Coin Flip"
                          : "Dice"
                      }`
                    : `Waiting (${room.players.filter((p) => p.isReady).length}/${room.players.length})`}
                </motion.button>
              )}
              {isHost && sessionRounds.length > 0 && (
                <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                  onClick={() => { audio.playClick(); endSession(); }}
                  className="w-full py-2.5 glass text-white/50 border border-white/10 rounded-xl text-sm font-medium hover:bg-white/10 transition-colors flex items-center justify-center gap-2">
                  <FlagOff className="w-4 h-4" /> End Session &amp; Get Recap
                </motion.button>
              )}
            </div>

            <RoomStandings players={room.players} rounds={sessionRounds} currentPlayerId={currentPlayer?.id} />
            <RoundHistoryPanel rounds={sessionRounds} />

            <div className="glass rounded-xl p-3">
              <div className="flex items-center gap-2 text-white/30 text-xs">
                <Shield className="w-3 h-3 flex-shrink-0" />
                <span>Royal Chips: virtual entertainment only. No cash value.</span>
              </div>
            </div>
          </div>

          {/* Game Area */}
          <div className="lg:col-span-2 space-y-4 order-1 lg:order-2">
            {isHost && room.currentGame && (
              <div className="flex items-center justify-between glass rounded-xl px-4 py-2.5">
                <span className="text-white/40 text-xs flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-vault-emerald animate-pulse" />
                  Table is running — new rounds deal automatically
                </span>
                <button
                  onClick={() => { audio.playClick(); stopGame(); }}
                  className="text-xs font-semibold text-red-400/80 hover:text-red-400 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 rounded-lg px-3 py-1.5 transition-colors"
                >
                  Stop Table
                </button>
              </div>
            )}
            <AnimatePresence mode="wait">
              {room.currentGame === "neon-roulette" && gameState ? (
                <Suspense fallback={<GameLoading />}>
                  <NeonRouletteV2
                    key="roulette"
                    state={gameState}
                    playerChips={currentPlayer?.chips}
                    currentPlayerId={currentPlayer?.id}
                    audio={audio}
                    onPlaceBet={currentPlayer?.isSpectator ? undefined : placeBet}
                  />
                </Suspense>
              ) : room.currentGame === "vault-heist" && gameState ? (
                <Suspense fallback={<GameLoading />}>
                  <VaultHeistV2 key="heist" state={gameState} onChooseVault={currentPlayer?.isSpectator ? undefined : chooseVault} />
                </Suspense>
              ) : room.currentGame === "coin-flip" && gameState ? (
                <Suspense fallback={<GameLoading />}>
                  <CoinFlip
                    key="coinflip"
                    state={gameState}
                    playerChips={currentPlayer?.chips}
                    currentPlayerId={currentPlayer?.id}
                    audio={audio}
                    onPlaceBet={currentPlayer?.isSpectator ? undefined : placeBet}
                  />
                </Suspense>
              ) : room.currentGame === "dice" && gameState ? (
                <Suspense fallback={<GameLoading />}>
                  <Dice
                    key="dice"
                    state={gameState}
                    playerChips={currentPlayer?.chips}
                    currentPlayerId={currentPlayer?.id}
                    audio={audio}
                    onPlaceBet={currentPlayer?.isSpectator ? undefined : placeBet}
                  />
                </Suspense>
              ) : (
                <motion.div key="waiting" initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                  className="glass-strong rounded-2xl p-8 lg:p-12 text-center min-h-[300px] lg:min-h-[400px] flex flex-col items-center justify-center">
                  <motion.div animate={{ y: [0, -8, 0] }} transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                    className="w-24 h-24 rounded-full flex items-center justify-center mb-6"
                    style={{ backgroundColor: currentTheme.glow.replace("0.3", "0.1") }}>
                    <Crown className="w-12 h-12" style={{ color: currentTheme.accent }} />
                  </motion.div>
                  <h2 className="text-2xl font-bold text-white mb-2">Waiting for host...</h2>
                  <p className="text-white/40 mb-6">
                    {isHost ? "Pick a game, then start when everyone is ready" : "The game will start when everyone is ready"}
                  </p>
                  <div className="grid grid-cols-2 gap-4 w-full max-w-md">
                    <motion.button
                      type="button"
                      disabled={!isHost}
                      onClick={() => { setSelectedGameType("neon-roulette"); audio.playClick(); }}
                      whileHover={isHost ? { scale: 1.03 } : {}}
                      whileTap={isHost ? { scale: 0.97 } : {}}
                      className={cn(
                        "glass p-4 rounded-xl border text-left transition-all",
                        isHost ? "cursor-pointer" : "cursor-default",
                        selectedGameType === "neon-roulette" ? "ring-2 ring-vault-gold" : ""
                      )}
                      style={{ borderColor: currentTheme.glow.replace("0.3", "0.2") }}
                    >
                      <div className="text-3xl mb-2">🎡</div>
                      <h4 className="font-semibold" style={{ color: currentTheme.accent }}>Neon Roulette</h4>
                      <p className="text-white/30 text-xs mt-1">European style</p>
                      {selectedGameType === "neon-roulette" && (
                        <p className="text-vault-gold text-[10px] font-bold uppercase tracking-wider mt-2">Selected</p>
                      )}
                    </motion.button>
                    <motion.button
                      type="button"
                      disabled={!isHost}
                      onClick={() => { setSelectedGameType("vault-heist"); audio.playClick(); }}
                      whileHover={isHost ? { scale: 1.03 } : {}}
                      whileTap={isHost ? { scale: 0.97 } : {}}
                      className={cn(
                        "glass p-4 rounded-xl border text-left transition-all",
                        isHost ? "cursor-pointer" : "cursor-default",
                        selectedGameType === "vault-heist" ? "ring-2 ring-vault-gold" : ""
                      )}
                      style={{ borderColor: currentTheme.glow.replace("0.3", "0.2") }}
                    >
                      <div className="text-3xl mb-2">🏦</div>
                      <h4 className="font-semibold" style={{ color: currentTheme.secondary }}>Vault Heist</h4>
                      <p className="text-white/30 text-xs mt-1">Social strategy</p>
                      {selectedGameType === "vault-heist" && (
                        <p className="text-vault-gold text-[10px] font-bold uppercase tracking-wider mt-2">Selected</p>
                      )}
                    </motion.button>
                    <motion.button
                      type="button"
                      disabled={!isHost}
                      onClick={() => { setSelectedGameType("coin-flip"); audio.playClick(); }}
                      whileHover={isHost ? { scale: 1.03 } : {}}
                      whileTap={isHost ? { scale: 0.97 } : {}}
                      className={cn(
                        "glass p-4 rounded-xl border text-left transition-all",
                        isHost ? "cursor-pointer" : "cursor-default",
                        selectedGameType === "coin-flip" ? "ring-2 ring-vault-gold" : ""
                      )}
                      style={{ borderColor: currentTheme.glow.replace("0.3", "0.2") }}
                    >
                      <div className="text-3xl mb-2">🪙</div>
                      <h4 className="font-semibold" style={{ color: currentTheme.accent }}>Coin Flip</h4>
                      <p className="text-white/30 text-xs mt-1">Quick call, quick payout</p>
                      {selectedGameType === "coin-flip" && (
                        <p className="text-vault-gold text-[10px] font-bold uppercase tracking-wider mt-2">Selected</p>
                      )}
                    </motion.button>
                    <motion.button
                      type="button"
                      disabled={!isHost}
                      onClick={() => { setSelectedGameType("dice"); audio.playClick(); }}
                      whileHover={isHost ? { scale: 1.03 } : {}}
                      whileTap={isHost ? { scale: 0.97 } : {}}
                      className={cn(
                        "glass p-4 rounded-xl border text-left transition-all",
                        isHost ? "cursor-pointer" : "cursor-default",
                        selectedGameType === "dice" ? "ring-2 ring-vault-gold" : ""
                      )}
                      style={{ borderColor: currentTheme.glow.replace("0.3", "0.2") }}
                    >
                      <div className="text-3xl mb-2">🎲</div>
                      <h4 className="font-semibold" style={{ color: currentTheme.secondary }}>Dice</h4>
                      <p className="text-white/30 text-xs mt-1">Sum bets, high stakes</p>
                      {selectedGameType === "dice" && (
                        <p className="text-vault-gold text-[10px] font-bold uppercase tracking-wider mt-2">Selected</p>
                      )}
                    </motion.button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <Chat
              messages={messages}
              onSend={(text, type) => { audio.playClick(); sendMessage(text, type); }}
              currentPlayerId={currentPlayer?.id || ""}
              onTypingStart={startTyping}
              onTypingStop={stopTyping}
            />
            <TypingIndicator
              players={typingPlayers
                .filter((p) => p.playerId !== currentPlayer?.id)
                .map((p) => ({ name: p.playerName }))}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

function GameLoading() {
  return (
    <div className="glass-strong rounded-2xl p-12 flex items-center justify-center min-h-[300px]">
      <div className="w-8 h-8 border-2 border-vault-gold/20 border-t-vault-gold rounded-full animate-spin" />
    </div>
  );
}
