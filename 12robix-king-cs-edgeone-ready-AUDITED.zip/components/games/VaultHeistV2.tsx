"use client";

import { useSocket } from "../../hooks/useSocket";
import { AdRunner } from "../effects/AdRunner";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Lock, Sparkles, Shield, Ghost, Gift, AlertTriangle, Timer, Zap, Skull, Trophy, RotateCcw, Users } from "lucide-react";
import { cn, formatChips } from "../../lib/utils";

const EVENT_CONFIG: Record<string, { icon: any; color: string; bg: string; border: string; sound: string }> = {
  golden_vault: { icon: Sparkles, color: "text-yellow-400", bg: "bg-yellow-400/10", border: "border-yellow-400/20", sound: "celebration" },
  lucky: { icon: Gift, color: "text-pink-400", bg: "bg-pink-400/10", border: "border-pink-400/20", sound: "win" },
  lockdown: { icon: Shield, color: "text-red-400", bg: "bg-red-400/10", border: "border-red-400/20", sound: "lose" },
  double: { icon: AlertTriangle, color: "text-orange-400", bg: "bg-orange-400/10", border: "border-orange-400/20", sound: "win" },
  ghost: { icon: Ghost, color: "text-purple-400", bg: "bg-purple-400/10", border: "border-purple-400/20", sound: "click" },
  mystery: { icon: Gift, color: "text-cyan-400", bg: "bg-cyan-400/10", border: "border-cyan-400/20", sound: "win" },
};

interface VaultHeistV2Props {
  state: any;
  onChooseVault?: (vaultId: string) => void;
  onRequestReplay?: () => void;
  leaderboard?: Array<{ name: string; chips: number; wins: number }>;
}

export function VaultHeistV2({ state, onChooseVault, onRequestReplay, leaderboard }: VaultHeistV2Props) {
  const [selectedVault, setSelectedVault] = useState<string | null>(null);
  const { socket } = useSocket();
  const [adPayload, setAdPayload] = useState<any>(null);
  const [showAd, setShowAd] = useState(false);
  const [isLocked, setIsLocked] = useState(false);
  const [revealedPlayers, setRevealedPlayers] = useState<string[]>([]);

  useEffect(() => {
    if (state.phase === "choosing") {
      setSelectedVault(null);
      setIsLocked(false);
      setRevealedPlayers([]);
    }
  }, [state.round, state.phase]);

  useEffect(() => {
    if (state.phase === "revealing") {
      // Staggered reveal animation
      const players = Object.keys(state.playerChoices || {});
      players.forEach((playerId, i) => {
        setTimeout(() => {
          setRevealedPlayers((prev) => [...prev, playerId]);
        }, i * 600);
      });
    } else {
      setRevealedPlayers([]);
    }
  }, [state.phase, state.playerChoices]);

  const handleVaultSelect = (vaultId: string) => {
    if (state.phase !== "choosing" || isLocked) return;
    setSelectedVault(vaultId);
    setIsLocked(true);
    onChooseVault?.(vaultId);
  };

  const getVaultGradient = (vault: any) => {
    const gradients: Record<string, string> = {
      "Bronze Vault": "from-orange-900/40 to-amber-900/20",
      "Silver Vault": "from-slate-700/40 to-gray-600/20",
      "Gold Vault": "from-yellow-900/40 to-amber-800/20",
      "Diamond Vault": "from-cyan-900/40 to-blue-900/20",
      "Mystery Vault": "from-purple-900/40 to-indigo-900/20",
    };
    return gradients[vault.name] || "from-gray-800/40 to-gray-700/20";
  };

  const getVaultBorder = (vault: any, isSelected: boolean) => {
    if (isSelected) return "border-vault-gold shadow-[0_0_30px_rgba(212,175,55,0.3)]";
    if (vault.name.includes("Diamond")) return "border-cyan-500/30";
    if (vault.name.includes("Gold")) return "border-yellow-500/30";
    if (vault.name.includes("Silver")) return "border-slate-400/30";
    return "border-orange-500/30";
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="metallic-gold-border relative glass-strong rounded-2xl p-4 lg:p-6 space-y-6"
    >
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="text-2xl">🏦</div>
          <div>
            <h2 className="text-xl font-bold text-gold-gradient animate-gradient-drift">Vault Heist</h2>
            <p className="text-white/30 text-xs">Bluff. Predict. Profit.</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-white/25 text-xs font-mono">Round {state.round ?? 1}</span>

          <span
            className={cn(
              "px-3 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider border",
              state.phase === "choosing" && "bg-vault-emerald/20 text-vault-emerald border-vault-emerald/30",
              state.phase === "locked" && "bg-vault-gold/20 text-vault-gold border-vault-gold/30",
              state.phase === "event" && "bg-purple-500/20 text-purple-400 border-purple-500/30 animate-pulse",
              state.phase === "revealing" && "bg-blue-500/20 text-blue-400 border-blue-500/30",
              state.phase === "result" && "bg-green-500/20 text-green-400 border-green-500/30"
            )}
          >
            {state.phase}
          </span>

          {state.countdown > 0 && state.phase === "choosing" && (
            <div className="flex items-center gap-1.5 text-vault-gold bg-vault-gold/10 px-3 py-1.5 rounded-full">
              <Timer className="w-4 h-4" />
              <span className="font-mono font-bold">{state.countdown}s</span>
            </div>
          )}

          {onRequestReplay && state.phase === "result" && (
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onRequestReplay}
              className="flex items-center gap-1 px-3 py-1.5 bg-vault-gold/20 text-vault-gold rounded-full text-xs font-bold hover:bg-vault-gold/30 transition-colors"
            >
              <RotateCcw className="w-3 h-3" />
              Replay
            </motion.button>
          )}
        </div>
      </div>

      {/* Standings (mini) */}
      {leaderboard && leaderboard.length > 0 && (
        <div className="glass rounded-xl p-3">
          <div className="flex items-center gap-2 text-white/40 text-xs uppercase tracking-wider mb-2">
            <Trophy className="w-3 h-3" /> Standings
          </div>
          <div className="flex gap-3 overflow-x-auto">
            {leaderboard.slice(0, 5).map((entry, i) => (
              <div key={i} className="flex items-center gap-2 bg-white/5 rounded-lg px-3 py-2 flex-shrink-0">
                <span className={cn("text-xs font-bold", i === 0 ? "text-vault-gold" : "text-white/30")}>#{i + 1}</span>
                <span className="text-white/60 text-sm">{entry.name}</span>
                <span className="text-vault-gold font-mono text-xs">{formatChips(entry.chips)}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* AI Event Announcement */}
      <AnimatePresence>
        {state.aiEvent && (state.phase === "event" || state.phase === "revealing") && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className={cn(
              "rounded-2xl p-6 text-center border",
              EVENT_CONFIG[state.aiEvent.effect]?.bg || "bg-purple-500/10",
              EVENT_CONFIG[state.aiEvent.effect]?.border || "border-purple-500/20"
            )}
          >
            <motion.div
              animate={{ rotate: [0, 10, -10, 0], scale: [1, 1.2, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="inline-block mb-3"
            >
              {(() => {
                const Icon = EVENT_CONFIG[state.aiEvent.effect]?.icon || Sparkles;
                return <Icon className={cn("w-10 h-10 mx-auto", EVENT_CONFIG[state.aiEvent.effect]?.color || "text-purple-400")} />;
              })()}
            </motion.div>
            <h3 className={cn("text-xl font-bold mb-1", EVENT_CONFIG[state.aiEvent.effect]?.color || "text-purple-300")}>
              {state.aiEvent.name}
            </h3>
            <p className="text-white/50 text-sm">{state.aiEvent.description}</p>
            {state.aiEvent.multiplier !== 1 && (
              <div className="mt-2 inline-flex items-center gap-1 px-3 py-1 bg-white/5 rounded-full text-xs">
                <Zap className="w-3 h-3 text-vault-gold" />
                <span className="text-vault-gold">{state.aiEvent.multiplier}x Multiplier</span>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Vault Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
        {state.vaults?.map((vault: any, i: number) => {
          const isSelected = selectedVault === vault.id;
          const isRevealed = state.phase === "revealing" || state.phase === "result";
          const choiceCount = state.playerChoices ? 
            Object.values(state.playerChoices).filter((v: any) => v === vault.id).length : 0;

          return (
            <motion.button
              key={vault.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1, type: "spring", stiffness: 200 }}
              whileHover={state.phase === "choosing" && !isLocked ? { scale: 1.05, y: -5 } : {}}
              whileTap={state.phase === "choosing" && !isLocked ? { scale: 0.95 } : {}}
              onClick={() => handleVaultSelect(vault.id)}
              disabled={state.phase !== "choosing" || isLocked}
              className={cn(
                "relative p-5 lg:p-6 rounded-2xl border-2 transition-all overflow-hidden",
                "bg-gradient-to-b",
                getVaultGradient(vault),
                getVaultBorder(vault, isSelected),
                state.phase !== "choosing" && "cursor-default",
                isRevealed && choiceCount > 0 && "ring-2 ring-vault-emerald"
              )}
            >
              <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-transparent opacity-0 hover:opacity-100 transition-opacity" />

              <div className="relative z-10">
                <motion.div
                  className="text-4xl lg:text-5xl mb-3"
                  animate={isSelected ? { y: [0, -5, 0] } : {}}
                  transition={{ duration: 1, repeat: Infinity }}
                >
                  {vault.emoji}
                </motion.div>

                <h4 className="font-bold text-white text-sm lg:text-base">{vault.name}</h4>
                <p className="text-vault-gold font-mono text-sm mt-1">{formatChips(vault.baseReward)}</p>

                <div className="mt-3">
                  <div className="flex items-center justify-between text-[10px] text-white/30 mb-1">
                    <span>Risk</span>
                    <span>{Math.round(vault.risk * 100)}%</span>
                  </div>
                  <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                    <motion.div
                      className={cn(
                        "h-full rounded-full",
                        vault.risk > 0.4 ? "bg-red-500" : vault.risk > 0.2 ? "bg-yellow-500" : "bg-vault-emerald"
                      )}
                      initial={{ width: 0 }}
                      animate={{ width: `${vault.risk * 100}%` }}
                      transition={{ duration: 1, delay: i * 0.2 }}
                    />
                  </div>
                </div>

                {/* Choice count badge */}
                {isRevealed && choiceCount > 0 && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute top-2 right-2 bg-vault-emerald/20 text-vault-emerald text-xs font-bold px-2 py-1 rounded-full flex items-center gap-1"
                  >
                    <Users className="w-3 h-3" />
                    {choiceCount}
                  </motion.div>
                )}

                <AnimatePresence>
                  {isSelected && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="absolute top-2 right-2 w-6 h-6 bg-gold-sheen rounded-full flex items-center justify-center shadow-md"
                    >
                      <Lock className="w-3 h-3 text-vault-black" />
                    </motion.div>
                  )}
                </AnimatePresence>

                <AnimatePresence>
                  {state.phase === "locked" && isSelected && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="absolute inset-0 bg-black/60 flex items-center justify-center rounded-2xl"
                    >
                      <motion.div
                        animate={{ scale: [1, 1.2, 1] }}
                        transition={{ duration: 1.5, repeat: Infinity }}
                      >
                        <Lock className="w-8 h-8 text-vault-gold" />
                      </motion.div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.button>
          );
        })}
      </div>

      {/* Simultaneous Reveal */}
      <AnimatePresence>
        {state.phase === "revealing" && state.playerChoices && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            className="glass rounded-xl p-4"
          >
            <h4 className="text-white/40 text-xs uppercase tracking-wider mb-3">Revealing Choices...</h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {Object.entries(state.playerChoices).map(([playerId, vaultId]: [string, any]) => {
                const vault = state.vaults?.find((v: any) => v.id === vaultId);
                const isRevealed = revealedPlayers.includes(playerId);

                return (
                  <motion.div
                    key={playerId}
                    initial={{ opacity: 0, rotateY: 90 }}
                    animate={isRevealed ? { opacity: 1, rotateY: 0 } : { opacity: 0.3 }}
                    transition={{ duration: 0.5 }}
                    className={cn(
                      "flex items-center gap-2 rounded-lg px-3 py-2 transition-all",
                      isRevealed ? "bg-white/10" : "bg-white/5"
                    )}
                  >
                    <span className="text-lg">{isRevealed ? vault?.emoji : "❓"}</span>
                    <span className="text-white/60 text-sm">Player</span>
                    {isRevealed && <Sparkles className="w-3 h-3 text-vault-gold ml-auto" />}
                  </motion.div>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Results */}
      <AnimatePresence>
        {state.phase === "result" && state.rewards && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-3"
          >
            <h4 className="text-white/40 text-xs uppercase tracking-wider text-center">Heist Results</h4>
            <p className="text-white/25 text-xs text-center -mt-2">Next round deals automatically…</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {Object.entries(state.rewards).map(([playerId, amount]: [string, any]) => (
                <motion.div
                  key={playerId}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: Math.random() * 0.3 }}
                  className={cn(
                    "flex items-center justify-between p-4 rounded-xl border",
                    amount > 0
                      ? "bg-vault-emerald/10 border-vault-emerald/20"
                      : "bg-red-500/10 border-red-500/20"
                  )}
                >
                  <div className="flex items-center gap-2">
                    {amount > 0 ? (
                      <Zap className="w-4 h-4 text-vault-emerald" />
                    ) : (
                      <Skull className="w-4 h-4 text-red-400" />
                    )}
                    <span className="text-white/60 text-sm">Player</span>
                  </div>
                  <span
                    className={cn(
                      "font-mono font-bold text-lg",
                      amount > 0 ? "text-vault-emerald" : "text-red-400"
                    )}
                  >
                    {amount > 0 ? `+${formatChips(amount)}` : "BUSTED"}
                  </span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Instruction */}
      {state.phase === "choosing" && !isLocked && (
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center text-vault-gold/60 text-sm"
        >
          Tap a vault to lock in your choice. Choose wisely...
        </motion.p>
      )}

      {state.phase === "choosing" && isLocked && (
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center text-white/40 text-sm"
        >
          Choice locked. Waiting for other players...
        </motion.p>
      )}
    <AdRunner payload={adPayload} visible={showAd} onComplete={(ms, skipped, clicked) => {
        if (socket && adPayload?.campaignId) {
          socket.emit("ad:complete", adPayload.campaignId, ms, skipped, clicked);
        }
        setShowAd(false);
      }} />
    </motion.div>
  );
}
