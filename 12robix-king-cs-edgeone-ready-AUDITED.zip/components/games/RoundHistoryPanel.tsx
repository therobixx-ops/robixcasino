"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { History, X, RotateCcw } from "lucide-react";
import type { RoundRecord } from "../../types";
import { formatChips, cn } from "../../lib/utils";

interface RoundHistoryPanelProps {
  rounds: RoundRecord[];
}

export function RoundHistoryPanel({ rounds }: RoundHistoryPanelProps) {
  const [open, setOpen] = useState(false);
  const [replaying, setReplaying] = useState<RoundRecord | null>(null);

  if (rounds.length === 0) return null;
  const recent = [...rounds].reverse();

  return (
    <>
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center justify-between glass rounded-xl px-4 py-3 hover:bg-white/10 transition-colors"
      >
        <span className="flex items-center gap-2 text-white/60 text-sm font-medium uppercase tracking-wider">
          <History className="w-4 h-4" /> Round History ({rounds.length})
        </span>
        <span className="text-white/30 text-xs">{open ? "Hide" : "View"}</span>
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="glass rounded-xl p-2 mt-2 max-h-64 overflow-y-auto space-y-1">
              {recent.map((r) => (
                <button
                  key={r.id}
                  onClick={() => setReplaying(r)}
                  className="w-full flex items-center justify-between px-3 py-2 rounded-lg hover:bg-white/10 transition-colors text-left"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="text-white/30 text-xs w-10 flex-shrink-0">R{r.round}</span>
                    <span className="text-white/70 text-xs truncate">
                      {r.gameType === "neon-roulette"
                        ? `Landed on ${r.result.winningNumber} ${r.result.isRed ? "🔴" : "⚫"}`
                        : r.gameType === "coin-flip"
                        ? `🪙 Landed on ${r.result.coinResult ?? "—"}`
                        : r.gameType === "dice"
                        ? `🎲 Rolled ${r.result.diceTotal ?? "—"} (${r.result.diceValues?.join(", ") ?? ""})`
                        : `${r.result.vaultEmoji ?? "🏦"} ${r.result.vaultName ?? "Vault"}`}
                    </span>
                    {r.roomEvent && <span className="text-[9px] text-vault-gold flex-shrink-0">✨</span>}
                  </div>
                  <span className="text-vault-gold text-xs font-medium flex-shrink-0">
                    {r.winnerName ? `${r.winnerName} +${formatChips(r.winnerAmount || 0)}` : "No winner"}
                  </span>
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Lightweight replay modal — recreates the result, not a full physics re-simulation */}
      <AnimatePresence>
        {replaying && (
          <motion.div
            className="fixed inset-0 z-[60] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setReplaying(null)}
          >
            <motion.div
              className="glass-strong rounded-2xl p-8 max-w-sm w-full text-center relative"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
            >
              <button onClick={() => setReplaying(null)} className="absolute top-3 right-3 text-white/40 hover:text-white">
                <X className="w-5 h-5" />
              </button>
              <p className="text-white/30 text-xs uppercase tracking-wider mb-4 flex items-center justify-center gap-1">
                <RotateCcw className="w-3 h-3" /> Round {replaying.round} Replay
              </p>

              {replaying.gameType === "neon-roulette" ? (
                <motion.div
                  initial={{ rotate: 0 }}
                  animate={{ rotate: 360 * 3 }}
                  transition={{ duration: 2, ease: "easeOut" }}
                  className={cn(
                    "w-28 h-28 mx-auto rounded-full flex items-center justify-center text-3xl font-bold mb-4 border-4",
                    replaying.result.isRed ? "border-red-500 text-red-400" : "border-white/20 text-white"
                  )}
                >
                  {replaying.result.winningNumber}
                </motion.div>
              ) : replaying.gameType === "coin-flip" ? (
                <motion.div
                  initial={{ rotateY: 0 }}
                  animate={{ rotateY: 720 }}
                  transition={{ duration: 1.4, ease: "easeOut" }}
                  className="w-28 h-28 mx-auto rounded-full flex items-center justify-center text-4xl font-black mb-4 border-4 border-vault-gold text-vault-gold"
                >
                  {replaying.result.coinResult === "heads" ? "H" : "T"}
                </motion.div>
              ) : replaying.gameType === "dice" ? (
                <motion.div
                  initial={{ scale: 0.5, rotate: -10 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ type: "spring", delay: 0.2 }}
                  className="flex items-center justify-center gap-2 mb-4"
                >
                  {(replaying.result.diceValues ?? []).map((v, i) => (
                    <div key={i} className="w-16 h-16 rounded-xl border-4 border-vault-gold flex items-center justify-center text-4xl">
                      {["", "⚀", "⚁", "⚂", "⚃", "⚄", "⚅"][v]}
                    </div>
                  ))}
                </motion.div>
              ) : (
                <motion.div
                  initial={{ scale: 0.5, rotate: -10 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ type: "spring", delay: 0.3 }}
                  className="text-7xl mb-4"
                >
                  {replaying.result.vaultEmoji ?? "🏦"}
                </motion.div>
              )}

              <p className="text-white font-semibold mb-1">
                {replaying.gameType === "neon-roulette"
                  ? `${replaying.result.isRed ? "Red" : "Black"} · ${replaying.result.winningNumber}`
                  : replaying.gameType === "coin-flip"
                  ? `${replaying.result.coinResult === "heads" ? "Heads" : "Tails"}`
                  : replaying.gameType === "dice"
                  ? `Total: ${replaying.result.diceTotal}`
                  : replaying.result.vaultName}
              </p>
              <p className="text-white/40 text-sm">
                {replaying.winnerName ? `${replaying.winnerName} won ${formatChips(replaying.winnerAmount || 0)} chips` : "No one won this round"}
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
