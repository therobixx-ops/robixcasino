"use client";

import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Timer } from "lucide-react";
import { cn, formatChips } from "../../lib/utils";
import type { Bet } from "../../types";
import type { useAudio } from "../../hooks/useAudio";
import { useWalletContext } from "../../contexts/WalletContext";
import { useSocket } from "../../hooks/useSocket";
import { AdRunner } from "../effects/AdRunner";

const BET_PRESETS = [100, 500, 1000, 2500, 5000];
const DICE_FACES = ["", "⚀", "⚁", "⚂", "⚃", "⚄", "⚅"];
const EXACT_PAYOUTS: Record<number, number> = {
  2: 30, 3: 15, 4: 10, 5: 8, 6: 6, 7: 5, 8: 6, 9: 8, 10: 10, 11: 15, 12: 30,
};
const EXACT_TOTALS = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];

type DiceBet = Omit<Bet, "playerId">;

interface DiceProps {
  state: any;
  onPlaceBet?: (bet: DiceBet) => void;
  playerChips?: number;
  currentPlayerId?: string;
  audio?: ReturnType<typeof useAudio>;
}

export function Dice({ state, onPlaceBet, playerChips = 10000, currentPlayerId, audio }: DiceProps) {
  const [betAmount, setBetAmount] = useState(500);
  const [rollingFaces, setRollingFaces] = useState<[number, number]>([1, 1]);
  const { wallet } = useWalletContext();
  const { socket } = useSocket();
  const [adPayload, setAdPayload] = useState<any>(null);
  const [showAd, setShowAd] = useState(false);
  const liveChips = wallet?.balance ?? playerChips;

  useEffect(() => {
    if (state.phase !== "rolling") return;
    const interval = setInterval(() => {
      setRollingFaces([1 + Math.floor(Math.random() * 6), 1 + Math.floor(Math.random() * 6)]);
    }, 90);
    return () => clearInterval(interval);
  }, [state.phase]);

  useEffect(() => {
    if (state.adPayload && state.phase === "rolling") {
      setAdPayload(state.adPayload);
      setShowAd(true);
    }
    if (state.phase === "result") {
      setShowAd(false);
    }
  }, [state.adPayload, state.phase]);

  const prevPhaseRef = useRef<string | null>(null);
  useEffect(() => {
    if (state.phase === prevPhaseRef.current) return;
    const cameFrom = prevPhaseRef.current;
    prevPhaseRef.current = state.phase;

    if (state.phase === "rolling" && cameFrom !== "rolling") audio?.playSpin?.();
    if (state.phase === "result" && cameFrom !== "result") {
      const myPayout = currentPlayerId ? state.results?.payouts?.[currentPlayerId] : undefined;
      if (myPayout && myPayout > 0) audio?.playWin?.();
      else if (myBetsRef.current.length > 0) audio?.playLose?.();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.phase]);

  const myBets: DiceBet[] = (currentPlayerId && state.bets?.[currentPlayerId]) || [];
  const myBetsRef = useRef(myBets);
  myBetsRef.current = myBets;
  const myStake = myBets.reduce((sum: number, b: DiceBet) => sum + b.amount, 0);
  const myPayout = currentPlayerId ? state.results?.payouts?.[currentPlayerId] : undefined;
  const hasRangeBet = (side: "low" | "high") => myBets.some((b) => b.type === "dice-range" && b.value === side);
  const hasExactBet = (n: number) => myBets.some((b) => b.type === "dice-exact" && Number(b.value) === n);

  const placeBet = (bet: DiceBet) => {
    if (state.phase !== "betting" || !onPlaceBet) return;
    if (betAmount > liveChips) return;
    audio?.playChip?.();
    onPlaceBet(bet);
  };

  const shownDice: [number, number] =
    state.phase === "rolling" ? rollingFaces : state.phase === "result" && state.dice ? state.dice : [1, 1];
  const total = state.phase === "result" ? state.total : null;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="metallic-gold-border relative glass-strong rounded-2xl p-4 lg:p-6 space-y-6"
    >
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="text-2xl">🎲</div>
          <div>
            <h2 className="text-xl font-bold text-gold-gradient animate-gradient-drift">Dice</h2>
            <p className="text-white/30 text-xs">Call the roll</p>
          </div>
        </div>
        {state.phase === "betting" && (
          <div className="flex items-center gap-1.5 text-white/50 text-sm font-mono glass px-3 py-1.5 rounded-lg">
            <Timer className="w-3.5 h-3.5" />
            {state.countdown}s
          </div>
        )}
      </div>

      <div className="flex flex-col items-center justify-center py-4">
        <div className="flex items-center gap-4">
          {shownDice.map((face, i) => (
            <motion.div
              key={i}
              animate={state.phase === "rolling" ? { rotate: [0, 15, -15, 0] } : { rotate: 0 }}
              transition={{ duration: 0.15 }}
              className={cn(
                "w-20 h-20 lg:w-24 lg:h-24 rounded-2xl flex items-center justify-center text-6xl border-4",
                state.phase === "result" ? "border-vault-gold bg-vault-gold/10" : "border-white/15 bg-white/5"
              )}
            >
              {DICE_FACES[face]}
            </motion.div>
          ))}
        </div>

        <AnimatePresence mode="wait">
          {state.phase === "betting" && (
            <motion.p key="betting" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-white/40 text-sm mt-4">
              Place your bets before time runs out
            </motion.p>
          )}
          {state.phase === "rolling" && (
            <motion.p key="rolling" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-vault-gold text-sm font-semibold mt-4 uppercase tracking-widest">
              Rolling...
            </motion.p>
          )}
          {state.phase === "result" && total !== null && (
            <motion.div key="result" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="text-center mt-4 space-y-1">
              <p className="text-3xl font-black text-white">{total}</p>
              {myPayout !== undefined && (
                <p className={cn("text-sm font-bold", myPayout > 0 ? "text-emerald-400" : "text-red-400")}>
                  {myPayout > 0 ? `+${formatChips(myPayout)}` : myStake > 0 ? `-${formatChips(myStake)}` : "No bet placed"}
                </p>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {state.phase === "betting" && (
        <>
          <div className="flex items-center justify-center gap-3">
            {BET_PRESETS.map((preset) => (
              <button
                key={preset}
                onClick={() => setBetAmount(preset)}
                className={cn(
                  "px-4 py-2 rounded-xl text-sm font-bold transition border",
                  betAmount === preset
                    ? "bg-vault-gold/20 border-vault-gold text-vault-gold"
                    : "bg-white/5 border-white/10 text-white/50 hover:bg-white/10 hover:text-white"
                )}
              >
                {formatChips(preset)}
              </button>
            ))}
          </div>

          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => placeBet({ type: "dice-range", value: "low", amount: betAmount })}
                disabled={liveChips < betAmount || hasRangeBet("low")}
                className={cn(
                  "py-3 rounded-xl text-sm font-bold uppercase tracking-wider transition border-2",
                  hasRangeBet("low")
                    ? "bg-emerald-500/20 border-emerald-500 text-emerald-400"
                    : "bg-white/5 border-white/10 text-white/50 hover:bg-white/10 hover:text-white disabled:opacity-30"
                )}
              >
                Low (2-6)
              </button>
              <button
                onClick={() => placeBet({ type: "dice-range", value: "high", amount: betAmount })}
                disabled={liveChips < betAmount || hasRangeBet("high")}
                className={cn(
                  "py-3 rounded-xl text-sm font-bold uppercase tracking-wider transition border-2",
                  hasRangeBet("high")
                    ? "bg-emerald-500/20 border-emerald-500 text-emerald-400"
                    : "bg-white/5 border-white/10 text-white/50 hover:bg-white/10 hover:text-white disabled:opacity-30"
                )}
              >
                High (8-12)
              </button>
            </div>

            <div className="grid grid-cols-6 gap-2">
              {EXACT_TOTALS.map((n) => (
                <button
                  key={n}
                  onClick={() => placeBet({ type: "dice-exact", value: n, amount: betAmount })}
                  disabled={liveChips < betAmount || hasExactBet(n)}
                  className={cn(
                    "py-2 rounded-lg text-xs font-bold transition border",
                    hasExactBet(n)
                      ? "bg-vault-gold/20 border-vault-gold text-vault-gold"
                      : "bg-white/5 border-white/10 text-white/50 hover:bg-white/10 hover:text-white disabled:opacity-30"
                  )}
                >
                  {n}
                  <span className="block text-[9px] text-white/30 font-normal">{EXACT_PAYOUTS[n]}x</span>
                </button>
              ))}
            </div>
          </div>
        </>
      )}

      <div className="text-center text-white/30 text-xs">
        Range pays <span className="text-vault-gold font-bold">2x</span> • Exact pays up to <span className="text-vault-gold font-bold">30x</span>
      </div>

      <AdRunner payload={adPayload} visible={showAd} onComplete={(ms, skipped, clicked) => {
        if (socket && adPayload?.campaignId) {
          socket.emit("ad:complete", adPayload.campaignId, ms, skipped, clicked);
        }
        setShowAd(false);
      }} />
    </motion.div>
  );
}
