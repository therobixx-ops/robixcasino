"use client";

import { useEffect, useMemo, useRef } from "react";
import { motion, useMotionValue, animate, type AnimationPlaybackControls } from "framer-motion";
import { ROULETTE_NUMBERS, DEGREES_PER_POCKET, pocketColor } from "../../lib/roulette";

type Phase = "betting" | "spinning" | "result";

interface RouletteWheel2DProps {
  phase: Phase;
  winningNumber: number | null;
  /** Fires exactly once, the instant the wheel + ball have both physically
   * finished settling into place — not on a guessed timer. This is the only
   * correct signal for "the wheel actually stopped" and should drive any
   * reveal/celebration UI that wants to sync to it. */
  onSettled?: () => void;
}

// Durations in seconds (framer-motion's animate() uses seconds, not ms).
const SETTLE_S = 2.6;
const IDLE_WHEEL_S = 26;
const IDLE_BALL_S = 18;
const SPIN_WHEEL_S = 1.1;
const SPIN_BALL_S = 0.85;

const VIEW = 200;
const CENTER = VIEW / 2;
const OUTER_R = 96;
const NUMBER_R = 78;
const INNER_R = 58;
const HUB_R = 34;

// Gradient fills (defined once in <defs>) — deeper, more saturated stops than
// flat colors so the felt reads as lacquered/lit rather than a solid tint.
const POCKET_FILL: Record<string, string> = {
  green: "url(#pocketGreen)",
  red: "url(#pocketRed)",
  black: "url(#pocketBlack)",
};

/** angle 0 = straight up (the marker), increasing clockwise — matches CSS rotate(). */
function polar(angleDeg: number, radius: number) {
  const rad = ((angleDeg - 90) * Math.PI) / 180;
  return { x: CENTER + radius * Math.cos(rad), y: CENTER + radius * Math.sin(rad) };
}

function wedgePath(startDeg: number, endDeg: number, rOuter: number, rInner: number) {
  const p1 = polar(startDeg, rOuter);
  const p2 = polar(endDeg, rOuter);
  const p3 = polar(endDeg, rInner);
  const p4 = polar(startDeg, rInner);
  const large = endDeg - startDeg > 180 ? 1 : 0;
  return [
    `M ${p1.x} ${p1.y}`,
    `A ${rOuter} ${rOuter} 0 ${large} 1 ${p2.x} ${p2.y}`,
    `L ${p3.x} ${p3.y}`,
    `A ${rInner} ${rInner} 0 ${large} 0 ${p4.x} ${p4.y}`,
    "Z",
  ].join(" ");
}

export function RouletteWheel2D({ phase, winningNumber, onSettled }: RouletteWheel2DProps) {
  // Rotation lives in a framer-motion value, not the DOM — animate() always
  // knows the exact current angle via .get(), so there's no need to read it
  // back out of a computed CSS transform (which is what the previous version
  // did, and which could race the browser's paint and read "no transform yet"
  // — i.e. snap to 0 — right at the moment a round resolved).
  const wheelRotation = useMotionValue(0);
  const ballRotation = useMotionValue(0);
  const wheelControls = useRef<AnimationPlaybackControls | null>(null);
  const ballControls = useRef<AnimationPlaybackControls | null>(null);
  // Not a real Phase value on purpose — guarantees the effect below treats the
  // very first render as a transition too, so a wheel that mounts mid-spin
  // (a player joining an in-progress round) starts spinning immediately
  // instead of defaulting to idle until the next phase change.
  const prevPhase = useRef<Phase | null>(null);
  // Bumped every time a new "result" settle begins; a settle promise only
  // acts on completion if it's still the current one, so a fast re-spin
  // (or unmount) can never fire a stale onSettled after the fact.
  const settleToken = useRef(0);

  const wedges = useMemo(() => {
    const step = DEGREES_PER_POCKET;
    return ROULETTE_NUMBERS.map((num, i) => {
      const mid = i * step;
      const start = mid - step / 2;
      const end = mid + step / 2;
      const label = polar(mid, NUMBER_R);
      return {
        num,
        color: pocketColor(num),
        d: wedgePath(start, end, OUTER_R, INNER_R),
        labelX: label.x,
        labelY: label.y,
        labelRotate: mid,
      };
    });
  }, []);

  useEffect(() => {
    const startLoop = (value: typeof wheelRotation, controlsRef: typeof wheelControls, durationS: number, direction: 1 | -1) => {
      controlsRef.current?.stop();
      const from = value.get();
      controlsRef.current = animate(value, from + direction * 360, {
        duration: durationS,
        ease: "linear",
        repeat: Infinity,
      });
    };

    if (phase === "spinning" && prevPhase.current !== "spinning") {
      startLoop(wheelRotation, wheelControls, SPIN_WHEEL_S, 1);
      startLoop(ballRotation, ballControls, SPIN_BALL_S, -1);
    }

    if (phase === "result" && prevPhase.current !== "result" && winningNumber !== null) {
      wheelControls.current?.stop();
      ballControls.current?.stop();

      const myToken = ++settleToken.current;

      const idx = ROULETTE_NUMBERS.indexOf(winningNumber as any);
      const targetMod = idx >= 0 ? (((-idx * DEGREES_PER_POCKET) % 360) + 360) % 360 : 0;

      // An evenly-paced ease-out: still decelerates into the stop like a real
      // wheel losing momentum, but doesn't visually arrive early and then
      // crawl for the last second the way the old curve ([0.12, 0.65, 0.15, 1])
      // did. Motion and duration now finish together, so nothing downstream
      // has to guess when the wheel is "actually" done.
      const SETTLE_EASE: [number, number, number, number] = [0.22, 0.61, 0.36, 1];

      const wheelFrom = wheelRotation.get();
      const wheelForward = (((targetMod - (wheelFrom % 360)) % 360) + 360) % 360;
      // land a couple of extra laps past the current spin for drama, always
      // moving forward from wherever the wheel currently is — never backward.
      wheelControls.current = animate(wheelRotation, wheelFrom + wheelForward + 720, {
        duration: SETTLE_S,
        ease: SETTLE_EASE,
      });

      const ballFrom = ballRotation.get();
      const ballForward = (((0 - (ballFrom % 360)) % 360) + 360) % 360;
      ballControls.current = animate(ballRotation, ballFrom + ballForward, {
        duration: SETTLE_S - 0.25,
        ease: SETTLE_EASE,
      });

      // Fire onSettled off the real completion of both animations — whichever
      // finishes last — instead of a duration guessed by a caller elsewhere.
      Promise.all([wheelControls.current, ballControls.current]).then(() => {
        if (settleToken.current === myToken) onSettled?.();
      });
    }

    if (phase === "betting" && prevPhase.current !== "betting") {
      startLoop(wheelRotation, wheelControls, IDLE_WHEEL_S, 1);
      startLoop(ballRotation, ballControls, IDLE_BALL_S, -1);
    }

    prevPhase.current = phase;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, winningNumber]);

  // Only stop the animations on true unmount, not on every effect re-run.
  useEffect(() => {
    return () => {
      wheelControls.current?.stop();
      ballControls.current?.stop();
    };
  }, []);

  return (
    <div className="w-full flex justify-center py-2">
      <div className="relative w-[280px] h-[280px] sm:w-[320px] sm:h-[320px]">
        {/* ambient glow behind the wheel — layered gold + a hint of wine for depth */}
        <div
          className="absolute inset-0 rounded-full blur-2xl opacity-60 pointer-events-none"
          style={{ background: "radial-gradient(circle, rgba(212,175,55,0.45) 0%, rgba(122,31,43,0.18) 55%, transparent 75%)" }}
        />

        {/* slow rotating light sweep across the glass — subtle "under a
            spotlight" reflection, cheap (opacity-only, no blur) */}
        <motion.div
          className="absolute inset-0 rounded-full pointer-events-none overflow-hidden"
          animate={{ rotate: 360 }}
          transition={{ duration: 14, repeat: Infinity, ease: "linear" }}
          style={{
            background:
              "conic-gradient(from 0deg, transparent 0deg, rgba(255,255,255,0.10) 6deg, transparent 14deg, transparent 360deg)",
            mixBlendMode: "screen",
          }}
        />

        {/* top marker — brighter, pulsing */}
        <motion.div
          className="absolute left-1/2 -top-1 -translate-x-1/2 z-20"
          animate={{ filter: ["drop-shadow(0 0 4px rgba(244,208,63,0.7))", "drop-shadow(0 0 10px rgba(244,208,63,1))", "drop-shadow(0 0 4px rgba(244,208,63,0.7))"] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
        >
          <div className="w-0 h-0 border-l-[7px] border-r-[7px] border-t-[11px] border-l-transparent border-r-transparent border-t-vault-gold-light" />
        </motion.div>

        <svg viewBox={`0 0 ${VIEW} ${VIEW}`} className="w-full h-full relative z-10">
          <defs>
            {/* Metallic gold rim — bevel from bright highlight to deep bronze */}
            <linearGradient id="goldRim" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fff3c4" />
              <stop offset="20%" stopColor="#f4d03f" />
              <stop offset="50%" stopColor="#b8860b" />
              <stop offset="80%" stopColor="#f4d03f" />
              <stop offset="100%" stopColor="#fff3c4" />
            </linearGradient>

            {/* Pocket fills — richer, higher-saturation, with a lit top edge */}
            <linearGradient id="pocketRed" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#ff3d54" />
              <stop offset="45%" stopColor="#e8102b" />
              <stop offset="100%" stopColor="#8c0619" />
            </linearGradient>
            <linearGradient id="pocketBlack" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#3a3a3a" />
              <stop offset="40%" stopColor="#161616" />
              <stop offset="100%" stopColor="#000000" />
            </linearGradient>
            <linearGradient id="pocketGreen" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#22e08a" />
              <stop offset="45%" stopColor="#00a651" />
              <stop offset="100%" stopColor="#025c2d" />
            </linearGradient>

            {/* Hub — brushed bronze/gold dish with an offset highlight for depth */}
            <radialGradient id="hubGrad" cx="42%" cy="32%" r="75%">
              <stop offset="0%" stopColor="#5a4818" />
              <stop offset="45%" stopColor="#241d0c" />
              <stop offset="100%" stopColor="#050504" />
            </radialGradient>

            <radialGradient id="ballGrad" cx="35%" cy="30%" r="70%">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="60%" stopColor="#e7e7e7" />
              <stop offset="100%" stopColor="#9c9c9c" />
            </radialGradient>
          </defs>

          {/* static outer rim (doesn't rotate, purely decorative) — layered for a beveled-metal look */}
          <circle cx={CENTER} cy={CENTER} r={OUTER_R + 6} fill="none" stroke="#3a2e0a" strokeWidth="2" opacity="0.6" />
          <circle cx={CENTER} cy={CENTER} r={OUTER_R + 4} fill="none" stroke="url(#goldRim)" strokeWidth="2.5" />

          <motion.g
            style={{ rotate: wheelRotation, transformOrigin: `${CENTER}px ${CENTER}px`, willChange: "transform" }}
          >
            {wedges.map((w) => (
              <g key={w.num}>
                <path d={w.d} fill={POCKET_FILL[w.color]} stroke="#f4d03f" strokeOpacity="0.55" strokeWidth="0.75" />
                <text
                  x={w.labelX}
                  y={w.labelY}
                  transform={`rotate(${w.labelRotate}, ${w.labelX}, ${w.labelY})`}
                  fill="#fdf6e3"
                  fontSize="7.2"
                  fontWeight="800"
                  textAnchor="middle"
                  dominantBaseline="middle"
                  style={{ paintOrder: "stroke", stroke: "rgba(0,0,0,0.55)", strokeWidth: 0.6 }}
                >
                  {w.num}
                </text>
              </g>
            ))}
            <circle cx={CENTER} cy={CENTER} r={INNER_R} fill="none" stroke="url(#goldRim)" strokeWidth="2" opacity="0.85" />
          </motion.g>

          {/* static hub on top — never rotates, so the wheel always reads as "spinning under glass" */}
          <circle cx={CENTER} cy={CENTER} r={HUB_R + 2} fill="none" stroke="url(#goldRim)" strokeWidth="1" opacity="0.5" />
          <circle cx={CENTER} cy={CENTER} r={HUB_R} fill="url(#hubGrad)" stroke="url(#goldRim)" strokeWidth="2.5" />
          <circle cx={CENTER} cy={CENTER} r={HUB_R - 8} fill="none" stroke="#f4d03f" strokeWidth="0.75" opacity="0.5" />
          {/* slow independent rotation on the inner dashed ring — reads as
              "precision machinery", matching the royal-win seal motif */}
          <motion.circle
            cx={CENTER}
            cy={CENTER}
            r={HUB_R - 12}
            fill="none"
            stroke="#f4d03f"
            strokeWidth="0.6"
            strokeDasharray="1.5 3"
            opacity="0.4"
            style={{ transformOrigin: `${CENTER}px ${CENTER}px` }}
            animate={{ rotate: 360 }}
            transition={{ duration: 22, repeat: Infinity, ease: "linear" }}
          />
          <text
            x={CENTER}
            y={CENTER + 2.5}
            textAnchor="middle"
            fontSize="10"
            fill="#f4d03f"
            fontWeight="800"
            letterSpacing="1"
            style={{ paintOrder: "stroke", stroke: "rgba(0,0,0,0.6)", strokeWidth: 0.5 }}
          >
            VIP
          </text>
        </svg>

        {/* ball — orbits independently of the wheel, settles to the marker at the same moment the wheel does */}
        <motion.div
          className="absolute inset-0 z-20 pointer-events-none"
          style={{ rotate: ballRotation, transformOrigin: "50% 50%", willChange: "transform" }}
        >
          <div
            className="absolute left-1/2 top-[10%] -translate-x-1/2 w-3 h-3 rounded-full"
            style={{
              background: "radial-gradient(circle at 35% 30%, #ffffff, #d8d8d8 60%, #8f8f8f 100%)",
              boxShadow: "0 0 8px rgba(255,255,255,0.95), 0 0 3px rgba(255,255,255,1), 0 1px 2px rgba(0,0,0,0.4)",
            }}
          />
        </motion.div>
      </div>
    </div>
  );
}
