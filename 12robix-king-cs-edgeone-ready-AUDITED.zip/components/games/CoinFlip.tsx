"use client";

import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Timer, Coins } from "lucide-react";
import { cn, formatChips } from "../../lib/utils";
import type { Bet } from "../../types";
import type { useAudio } from "../../hooks/useAudio";
import { useWalletContext } from "../../contexts/WalletContext";
import { useSocket } from "../../hooks/useSocket";
import { AdRunner } from "../effects/AdRunner";

const BET_PRESETS = [100, 500, 1000, 2500, 5000];

type CoinFlipBet = Omit<Bet, "playerId">;

interface CoinFlipProps {
  state: any;
  onPlaceBet?: (bet: CoinFlipBet) => void;
  playerChips?: number;
  currentPlayerId?: string;
  audio?: ReturnType<typeof useAudio>;
}

export function CoinFlip({ state, onPlaceBet, playerChips = 10000, currentPlayerId, audio }: CoinFlipProps) {
  const [betAmount, setBetAmount] = useState(500);
  const [myCall, setMyCall] = useState<"heads" | "tails" | null>(null);
  const { wallet } = useWalletContext();
  const { socket } = useSocket();
  const [adPayload, setAdPayload] = useState<any>(null);
  const [showAd, setShowAd] = useState(false);
  const liveChips = wallet?.balance ?? playerChips;

  useEffect(() => {
    if (state.phase === "betting") setMyCall(null);
  }, [state.round, state.phase]);

  useEffect(() => {
    if (state.adPayload && state.phase === "flipping") {
      setAdPayload(state.adPayload);
      setShowAd(true);
    }
    if (state.phase === "result") {
      setShowAd(false);
    }
  }, [state.adPayload, state.phase]);

  const prevPhaseRef = useRef<string | null>(null);
  useEffect(() => {
    if (state.phase === prevPhaseRef.current) return;
    const cameFrom = prevPhaseRef.current;
    prevPhaseRef.current = state.phase;

    if (state.phase === "flipping" && cameFrom !== "flipping") {
      audio?.playSpin?.();
    }
    if (state.phase === "result" && cameFrom !== "result") {
      const myPayout = currentPlayerId ? state.results?.payouts?.[currentPlayerId] : undefined;
      if (myPayout && myPayout > 0) audio?.playWin?.();
      else if (myCall) audio?.playLose?.();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.phase]);

  const myBets: CoinFlipBet[] = (currentPlayerId && state.bets?.[currentPlayerId]) || [];
  const myStake = myBets.reduce((sum: number, b: CoinFlipBet) => sum + b.amount, 0);
  const myPayout = currentPlayerId ? state.results?.payouts?.[currentPlayerId] : undefined;

  const handleCall = (side: "heads" | "tails") => {
    if (state.phase !== "betting" || !onPlaceBet) return;
    if (betAmount > liveChips) return;
    setMyCall(side);
    audio?.playChip?.();
    onPlaceBet({ type: "coinflip", value: side, amount: betAmount });
  };

  const result = state.coinResult as "heads" | "tails" | null;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="metallic-gold-border relative glass-strong rounded-2xl p-4 lg:p-6 space-y-6"
    >
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="text-2xl">🪙</div>
          <div>
            <h2 className="text-xl font-bold text-gold-gradient animate-gradient-drift">Coin Flip</h2>
            <p className="text-white/30 text-xs">Call it in the air</p>
          </div>
        </div>
        {state.phase === "betting" && (
          <div className="flex items-center gap-1.5 text-white/50 text-sm font-mono glass px-3 py-1.5 rounded-lg">
            <Timer className="w-3.5 h-3.5" />
            {state.countdown}s
          </div>
        )}
      </div>

      <div className="flex flex-col items-center justify-center py-6">
        <motion.div
          animate={
            state.phase === "flipping"
              ? { rotateY: [0, 1800], scale: [1, 1.1, 1] }
              : { rotateY: 0, scale: 1 }
          }
          transition={state.phase === "flipping" ? { duration: 2.3, ease: "easeInOut" } : { duration: 0.3 }}
          style={{ transformStyle: "preserve-3d" }}
          className={cn(
            "w-32 h-32 lg:w-40 lg:h-40 rounded-full flex items-center justify-center text-5xl font-black border-4 shadow-[0_0_40px_rgba(212,175,55,0.25)]",
            state.phase === "result" && result === "heads" && "border-vault-gold bg-gradient-to-br from-yellow-600/40 to-amber-800/30 text-vault-gold",
            state.phase === "result" && result === "tails" && "border-slate-300 bg-gradient-to-br from-slate-500/40 to-slate-800/30 text-slate-200",
            state.phase !== "result" && "border-white/20 bg-gradient-to-br from-white/10 to-white/0 text-white/40"
          )}
        >
          {state.phase === "result" && result ? (result === "heads" ? "H" : "T") : <Coins className="w-12 h-12" />}
        </motion.div>

        <AnimatePresence mode="wait">
          {state.phase === "betting" && (
            <motion.p key="betting" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-white/40 text-sm mt-4">
              {myCall ? `You called ${myCall}` : "Place your call before time runs out"}
            </motion.p>
          )}
          {state.phase === "flipping" && (
            <motion.p key="flipping" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-vault-gold text-sm font-semibold mt-4 uppercase tracking-widest">
              Flipping...
            </motion.p>
          )}
          {state.phase === "result" && (
            <motion.div key="result" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="text-center mt-4 space-y-1">
              <p className={cn("text-2xl font-black", myPayout && myPayout > 0 ? "text-emerald-400" : "text-white")}>
                {result === "heads" ? "HEADS" : "TAILS"}
              </p>
              {myPayout !== undefined && (
                <p className={cn("text-sm font-bold", myPayout > 0 ? "text-emerald-400" : "text-red-400")}>
                  {myPayout > 0 ? `+${formatChips(myPayout)}` : myStake > 0 ? `-${formatChips(myStake)}` : "No bet placed"}
                </p>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {state.phase === "betting" && (
        <>
          <div className="flex items-center justify-center gap-3">
            {BET_PRESETS.map((preset) => (
              <button
                key={preset}
                onClick={() => setBetAmount(preset)}
                className={cn(
                  "px-4 py-2 rounded-xl text-sm font-bold transition border",
                  betAmount === preset
                    ? "bg-vault-gold/20 border-vault-gold text-vault-gold"
                    : "bg-white/5 border-white/10 text-white/50 hover:bg-white/10 hover:text-white"
                )}
              >
                {formatChips(preset)}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => handleCall("heads")}
              disabled={liveChips < betAmount}
              className={cn(
                "py-4 rounded-xl text-lg font-black uppercase tracking-wider transition border-2",
                myCall === "heads"
                  ? "bg-vault-gold/20 border-vault-gold text-vault-gold"
                  : "bg-white/5 border-white/10 text-white/50 hover:bg-white/10 hover:text-white disabled:opacity-30"
              )}
            >
              Heads
            </button>
            <button
              onClick={() => handleCall("tails")}
              disabled={liveChips < betAmount}
              className={cn(
                "py-4 rounded-xl text-lg font-black uppercase tracking-wider transition border-2",
                myCall === "tails"
                  ? "bg-vault-gold/20 border-vault-gold text-vault-gold"
                  : "bg-white/5 border-white/10 text-white/50 hover:bg-white/10 hover:text-white disabled:opacity-30"
              )}
            >
              Tails
            </button>
          </div>
        </>
      )}

      <div className="text-center text-white/30 text-xs">
        Correct call pays <span className="text-vault-gold font-bold">2x</span> your stake
      </div>

      <AdRunner payload={adPayload} visible={showAd} onComplete={(ms, skipped, clicked) => {
        if (socket && adPayload?.campaignId) {
          socket.emit("ad:complete", adPayload.campaignId, ms, skipped, clicked);
        }
        setShowAd(false);
      }} />
    </motion.div>
  );
}
