"use client";

import { useWalletContext } from "../../contexts/WalletContext";
import { useSocket } from "../../hooks/useSocket";
import { AdRunner } from "../effects/AdRunner";

import { useState, useCallback, useEffect, useRef, useMemo } from "react";
import type { ReactNode, CSSProperties } from "react";
import { motion, AnimatePresence, animate } from "framer-motion";
import { Timer, RotateCcw, BarChart3, History, Trophy, Sparkles } from "lucide-react";
import { cn, formatChips } from "../../lib/utils";
import { ROULETTE_NUMBERS, pocketColor, TABLE_ROWS } from "../../lib/roulette";
import type { Bet } from "../../types";
import { RouletteWheel2D } from "./RouletteWheel2D";
import type { useAudio } from "../../hooks/useAudio";

const BET_PRESETS = [100, 500, 1000, 2500, 5000];
const NEXT_ROUND_COUNTDOWN_S = 10;

type RouletteBet = Omit<Bet, "playerId">;

interface NeonRouletteV2Props {
  state: any;
  onPlaceBet?: (bet: RouletteBet) => void;
  playerChips?: number;
  currentPlayerId?: string;
  audio?: ReturnType<typeof useAudio>;
  /** Notifies the parent (Room) the instant the wheel has truly settled and
   * the result is being revealed — lets room-level celebration effects sync
   * to the same real completion signal instead of keeping their own guess. */
  onSettled?: () => void;
}

/** Animates a number counting up from 0 to `target` once `active` flips true.
 * Used for the winning-amount reveal so the payout feels earned rather than
 * just appearing — this is what "amazing casino win" actually reads as. */
function useCountUp(target: number, active: boolean, duration = 0.9) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    if (!active) {
      setValue(0);
      return;
    }
    const controls = animate(0, target, {
      duration,
      ease: [0.16, 1, 0.3, 1],
      onUpdate: (v) => setValue(Math.round(v)),
    });
    return () => controls.stop();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [target, active]);
  return value;
}

export function NeonRouletteV2({ state, onPlaceBet, playerChips = 10000, currentPlayerId, audio, onSettled }: NeonRouletteV2Props) {
  const [selectedBet, setSelectedBet] = useState<{ type: string; value: any } | null>(null);
  const [betAmount, setBetAmount] = useState(500);
  const [placedBets, setPlacedBets] = useState<RouletteBet[]>([]);
  const [showStats, setShowStats] = useState(false);
  const [draggedChip, setDraggedChip] = useState<number | null>(null);
  const { wallet } = useWalletContext();
  const { socket } = useSocket();
  const [adPayload, setAdPayload] = useState<any>(null);
  const [showAd, setShowAd] = useState(false);
  const liveChips = wallet?.balance ?? playerChips;

  const isRed = (n: number) => pocketColor(n) === "red";
  const isBlack = (n: number) => pocketColor(n) === "black";

  // New round's betting window opened — clear last round's bet slip so old
  // chip markers don't linger on numbers that were bet on previously.
  useEffect(() => {
    if (state.phase === "betting") {
      setPlacedBets([]);
      setSelectedBet(null);
    }
  }, [state.round, state.phase]);

  useEffect(() => {
    if (state.adPayload && state.phase === "spinning") {
      setAdPayload(state.adPayload);
      setShowAd(true);
    }
    if (state.phase === "result") {
      setShowAd(false);
    }
  }, [state.adPayload, state.phase]);

  // Sound cues + a clean, visible "next round in 3…2…1" countdown so the
  // gap between rounds always reads as intentional pacing, not a stall.
  const prevPhaseRef = useRef<string | null>(null);
  const [nextRoundIn, setNextRoundIn] = useState<number | null>(null);
  const [revealResults, setRevealResults] = useState(false);

  useEffect(() => {
    if (state.phase === prevPhaseRef.current) return;
    const cameFrom = prevPhaseRef.current;
    prevPhaseRef.current = state.phase;

    if (state.phase === "spinning" && cameFrom !== "spinning") {
      audio?.playSpin();
    }

    if (state.phase === "result" && cameFrom !== "result") {
      // Don't reveal yet — the wheel's onSettled callback (below) is what
      // actually flips revealResults on, synced to the real animation
      // finishing rather than a duration guessed here. The 10s "next round"
      // clock, though, mirrors the server's own timing exactly, so it's
      // safe to start immediately.
      setRevealResults(false);
      setNextRoundIn(NEXT_ROUND_COUNTDOWN_S);
    }

    if (state.phase === "betting") {
      setNextRoundIn(null);
      setRevealResults(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.phase]);

  /** Fired by RouletteWheel2D the instant the wheel + ball have physically
   * come to rest — the single source of truth for "the round is actually
   * over," replacing the old fixed-duration guess. */
  const handleWheelSettled = useCallback(() => {
    setRevealResults(true);
    const myPayout = currentPlayerId ? state.results?.payouts?.[currentPlayerId] : undefined;
    if (placedBets.length > 0) {
      if (myPayout && myPayout > 0) audio?.playWin();
      else audio?.playLose();
    }
    onSettled?.();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.results, currentPlayerId, placedBets, audio, onSettled]);

  useEffect(() => {
    if (nextRoundIn === null) return;
    if (nextRoundIn <= 0) return;
    const t = setTimeout(() => setNextRoundIn((n) => (n !== null ? n - 1 : n)), 1000);
    return () => clearTimeout(t);
  }, [nextRoundIn]);

  const getNumberColor = (n: number) => {
    if (n === 0) return "bg-gradient-to-br from-emerald-400 via-emerald-600 to-emerald-900 border-emerald-300";
    if (isRed(n)) return "bg-gradient-to-br from-red-500 via-red-600 to-red-900 border-red-400";
    return "bg-gradient-to-br from-zinc-700 via-zinc-900 to-black border-zinc-600";
  };

  const handlePlaceBet = useCallback(() => {
    if (!selectedBet || !onPlaceBet) return;
    const bet: RouletteBet = { ...selectedBet, amount: betAmount };
    setPlacedBets((prev) => [...prev, bet]);
    onPlaceBet(bet);
    setSelectedBet(null);
    audio?.playChip();
  }, [selectedBet, betAmount, onPlaceBet, audio]);

  const handleDragStart = (amount: number) => {
    setDraggedChip(amount);
  };

  /** Drop (or click, when a chip is already selected) a chip onto any bet
   * spot on the felt — outside bets, dozens, and columns, not just numbers. */
  const handleDropOnBet = (type: string, value: string | number) => {
    if (draggedChip === null || !onPlaceBet) return;
    onPlaceBet({ type, value, amount: draggedChip });
    setPlacedBets((prev) => [...prev, { type, value, amount: draggedChip }]);
    setDraggedChip(null);
    audio?.playChip();
  };

  const chipsOnBet = (type: string, value: string | number) =>
    placedBets.filter((b) => b.type === type && String(b.value) === String(value)).length;

  const getHotNumbers = () => {
    if (!state.history) return [];
    const counts: Record<number, number> = {};
    state.history.forEach((h: any) => {
      counts[h.winningNumber] = (counts[h.winningNumber] || 0) + 1;
    });
    return Object.entries(counts)
      .sort((a, b) => (b[1] as number) - (a[1] as number))
      .slice(0, 5)
      .map(([n]) => Number(n));
  };

  const getColdNumbers = () => {
    if (!state.history) return [];
    const counts: Record<number, number> = {};
    ROULETTE_NUMBERS.forEach((n) => (counts[n] = 0));
    state.history.forEach((h: any) => {
      counts[h.winningNumber] = (counts[h.winningNumber] || 0) + 1;
    });
    return Object.entries(counts)
      .sort((a, b) => (a[1] as number) - (b[1] as number))
      .slice(0, 5)
      .map(([n]) => Number(n));
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-strong rounded-2xl p-4 lg:p-6 space-y-4"
    >
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="text-2xl">🎡</div>
          <div>
            <h2 className="text-xl font-bold text-gold-gradient">Neon Roulette</h2>
            <p className="text-white/30 text-xs">European • Single Zero • Server-Authoritative</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowStats(!showStats)}
            className={cn(
              "p-2 rounded-xl transition-colors",
              showStats ? "bg-vault-gold/20 text-vault-gold" : "glass text-white/40 hover:bg-white/10"
            )}
          >
            <BarChart3 className="w-4 h-4" />
          </button>

          <span className={cn(
            "px-3 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider",
            state.phase === "betting" && "bg-vault-emerald/20 text-vault-emerald border border-vault-emerald/30",
            state.phase === "spinning" && "bg-vault-gold/20 text-vault-gold border border-vault-gold/30 animate-pulse",
            state.phase === "result" && "bg-blue-500/20 text-blue-400 border border-blue-500/30"
          )}>
            {state.phase}
          </span>

          <span className="text-white/25 text-xs font-mono">Round {state.round ?? 1}</span>

          {state.countdown > 0 && state.phase === "betting" && (
            <div className="flex items-center gap-1.5 text-vault-gold bg-vault-gold/10 px-3 py-1.5 rounded-full">
              <Timer className="w-4 h-4" />
              <span className="font-mono font-bold">{state.countdown}s</span>
            </div>
          )}

          {state.phase === "result" && nextRoundIn !== null && nextRoundIn > 0 && (
            <div className="flex items-center gap-1.5 text-blue-300 bg-blue-500/10 px-3 py-1.5 rounded-full">
              <Timer className="w-4 h-4" />
              <span className="font-mono font-bold">Next in {nextRoundIn}s</span>
            </div>
          )}

          {state.winningNumber !== null && (
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              className={cn(
                "w-12 h-12 rounded-full flex items-center justify-center text-xl font-bold shadow-lg border-2",
                getNumberColor(state.winningNumber)
              )}
            >
              {state.winningNumber}
            </motion.div>
          )}
        </div>
      </div>

      {/* Stats Panel */}
      <AnimatePresence>
        {showStats && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="glass rounded-xl p-4 grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <p className="text-white/40 text-xs uppercase tracking-wider mb-1">Hot Numbers</p>
                <div className="flex gap-1 flex-wrap">
                  {getHotNumbers().map((n) => (
                    <span key={n} className={cn("w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold", getNumberColor(n))}>
                      {n}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-white/40 text-xs uppercase tracking-wider mb-1">Cold Numbers</p>
                <div className="flex gap-1 flex-wrap">
                  {getColdNumbers().map((n) => (
                    <span key={n} className={cn("w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold", getNumberColor(n))}>
                      {n}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-white/40 text-xs uppercase tracking-wider mb-1">Total Bets</p>
                <p className="text-vault-gold font-mono font-bold">{placedBets.length}</p>
              </div>
              <div>
                <p className="text-white/40 text-xs uppercase tracking-wider mb-1">Chips at Risk</p>
                <p className="text-vault-gold font-mono font-bold">{formatChips(placedBets.reduce((s, b) => s + b.amount, 0))}</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Roulette Wheel */}
      <div className="flex justify-center py-2 relative">
        <RouletteWheel2D phase={state.phase} winningNumber={state.winningNumber} onSettled={handleWheelSettled} />
      </div>

      {/* History Strip */}
      {state.history && state.history.length > 0 && (
        <div className="flex items-center gap-2 overflow-x-auto pb-2">
          <History className="w-4 h-4 text-white/20 flex-shrink-0" />
          {state.history.slice(-12).map((h: any, i: number) => (
            <motion.div
              key={i}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className={cn(
                "w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 border",
                getNumberColor(h.winningNumber)
              )}
            >
              {h.winningNumber}
            </motion.div>
          ))}
        </div>
      )}

      {/* Drag & Drop Chips */}
      <AnimatePresence>
        {state.phase === "betting" && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="space-y-4"
          >
            {/* Chip Stack - Draggable */}
            <div>
              <label className="text-white/40 text-xs uppercase tracking-wider mb-2 block">Drag Chips to Bet</label>
              <div className="flex gap-3 flex-wrap">
                {BET_PRESETS.map((amount) => (
                  <motion.button
                    key={amount}
                    draggable
                    onDragStart={() => handleDragStart(amount)}
                    onDragEnd={() => setDraggedChip(null)}
                    whileHover={{ scale: 1.1, y: -5 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setBetAmount(amount)}
                    className={cn(
                      "w-14 h-14 rounded-full flex items-center justify-center font-bold text-xs cursor-grab active:cursor-grabbing transition-all border-2",
                      betAmount === amount
                        ? "bg-vault-gold text-vault-black border-vault-gold-light shadow-[0_0_20px_rgba(212,175,55,0.4)]"
                        : "bg-vault-graphite text-vault-gold border-vault-gold/30 hover:border-vault-gold/60"
                    )}
                  >
                    {amount >= 1000 ? `${amount / 1000}K` : amount}
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Felt Table — classic 3-row x 12-column grid with 2:1 column
                bets, dozens, and outside bets, matching a real roulette
                table (not wheel-spin order, which would read 0,32,15,19...). */}
            <div>
              <label className="text-white/40 text-xs uppercase tracking-wider mb-2 block">
                {draggedChip ? `Drop chip on a bet (${formatChips(draggedChip)})` : "Or click to bet"}
              </label>

              <div className="overflow-x-auto rounded-xl">
                <div
                  className="rounded-xl p-2 min-w-[520px]"
                  style={{ background: "linear-gradient(160deg, #0c3d24 0%, #072016 100%)", border: "1px solid rgba(212,175,55,0.25)" }}
                >
                  {/* Zero + number grid + column (2 to 1) buttons */}
                  <div
                    className="grid gap-[3px]"
                    style={{ gridTemplateColumns: "1.3fr repeat(12, 1fr) 1fr", gridTemplateRows: "repeat(3, minmax(30px, 1fr))" }}
                  >
                    <BetButton
                      className="row-span-3 bg-green-600 border-green-400 text-white"
                      style={{ gridColumn: 1, gridRow: "1 / span 3" }}
                      onClick={() => (draggedChip ? handleDropOnBet("number", 0) : setSelectedBet({ type: "number", value: 0 }))}
                      selected={selectedBet?.type === "number" && selectedBet?.value === 0}
                      badge={chipsOnBet("number", 0)}
                    >
                      0
                    </BetButton>

                    {TABLE_ROWS.map((row, rowIdx) =>
                      row.map((num, colIdx) => (
                        <BetButton
                          key={num}
                          className={cn("text-white", isRed(num) ? "bg-red-600 border-red-400" : "bg-zinc-900 border-zinc-700")}
                          style={{ gridColumn: colIdx + 2, gridRow: rowIdx + 1 }}
                          onClick={() => (draggedChip ? handleDropOnBet("number", num) : setSelectedBet({ type: "number", value: num }))}
                          selected={selectedBet?.type === "number" && selectedBet?.value === num}
                          badge={chipsOnBet("number", num)}
                        >
                          {num}
                        </BetButton>
                      ))
                    )}

                    {[3, 2, 1].map((col, rowIdx) => (
                      <BetButton
                        key={col}
                        className="bg-emerald-900/60 border-vault-gold/30 text-vault-gold text-[9px] sm:text-[11px]"
                        style={{ gridColumn: 14, gridRow: rowIdx + 1 }}
                        onClick={() => (draggedChip ? handleDropOnBet("column", col) : setSelectedBet({ type: "column", value: col }))}
                        selected={selectedBet?.type === "column" && Number(selectedBet?.value) === col}
                        badge={chipsOnBet("column", col)}
                      >
                        2:1
                      </BetButton>
                    ))}
                  </div>

                  {/* Dozens */}
                  <div className="grid gap-[3px] mt-[3px]" style={{ gridTemplateColumns: "1.3fr repeat(12, 1fr) 1fr" }}>
                    <div />
                    {[1, 2, 3].map((dozen) => (
                      <BetButton
                        key={dozen}
                        className="bg-emerald-900/60 border-vault-gold/30 text-vault-gold text-[9px] sm:text-[11px]"
                        style={{ gridColumn: `${2 + (dozen - 1) * 4} / span 4` }}
                        onClick={() => (draggedChip ? handleDropOnBet("dozen", dozen) : setSelectedBet({ type: "dozen", value: dozen }))}
                        selected={selectedBet?.type === "dozen" && Number(selectedBet?.value) === dozen}
                        badge={chipsOnBet("dozen", dozen)}
                      >
                        {dozen === 1 ? "1st 12" : dozen === 2 ? "2nd 12" : "3rd 12"}
                      </BetButton>
                    ))}
                    <div />
                  </div>

                  {/* Outside bets */}
                  <div className="grid gap-[3px] mt-[3px]" style={{ gridTemplateColumns: "1.3fr repeat(12, 1fr) 1fr" }}>
                    <div />
                    {[
                      { type: "halves", value: "low", label: "1-18" },
                      { type: "evenodd", value: "even", label: "EVEN" },
                      { type: "color", value: "red", label: "\u25C6", cls: "bg-red-600 border-red-400" },
                      { type: "color", value: "black", label: "\u25C6", cls: "bg-zinc-900 border-zinc-700" },
                      { type: "evenodd", value: "odd", label: "ODD" },
                      { type: "halves", value: "high", label: "19-36" },
                    ].map((bet, i) => (
                      <BetButton
                        key={`${bet.type}-${bet.value}`}
                        className={cn("text-white text-[9px] sm:text-[11px]", bet.cls || "bg-emerald-900/60 border-vault-gold/30 text-vault-gold")}
                        style={{ gridColumn: `${2 + i * 2} / span 2` }}
                        onClick={() => (draggedChip ? handleDropOnBet(bet.type, bet.value) : setSelectedBet({ type: bet.type, value: bet.value }))}
                        selected={selectedBet?.type === bet.type && selectedBet?.value === bet.value}
                        badge={chipsOnBet(bet.type, bet.value)}
                      >
                        {bet.label}
                      </BetButton>
                    ))}
                    <div />
                  </div>
                </div>
              </div>
            </div>

            {/* Place Bet */}
            <div className="flex gap-3">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                disabled={!selectedBet || liveChips < betAmount}
                onClick={handlePlaceBet}
                className={cn(
                  "flex-1 py-4 rounded-xl font-bold text-lg transition-all",
                  selectedBet
                    ? "bg-vault-gold text-vault-black hover:bg-vault-gold-light neon-glow"
                    : "bg-white/5 text-white/20 cursor-not-allowed"
                )}
              >
                {selectedBet ? `Bet ${formatChips(betAmount)} on ${selectedBet.value}` : "Select a bet type"}
              </motion.button>
              <button
                onClick={() => { setPlacedBets([]); setSelectedBet(null); }}
                className="px-4 py-4 bg-white/5 text-white/40 rounded-xl hover:bg-white/10 transition-colors"
              >
                <RotateCcw className="w-5 h-5" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Results — one cohesive reveal, timed to the wheel's real stop */}
      <AnimatePresence>
        {state.phase === "result" && state.results && revealResults && (
          <WinReveal
            results={state.results}
            myPayout={currentPlayerId ? state.results.payouts?.[currentPlayerId] : undefined}
            iBet={placedBets.length > 0}
            nextRoundIn={nextRoundIn}
            getNumberColor={getNumberColor}
          />
        )}
      </AnimatePresence>

      <AdRunner
        payload={adPayload}
        visible={showAd}
        onComplete={(ms, skipped, clicked) => {
          if (socket && adPayload?.campaignId) {
            socket.emit("ad:complete", adPayload.campaignId, ms, skipped, clicked);
          }
          setShowAd(false);
        }}
      />
    </motion.div>
  );
}

/** The full post-spin reveal: winning number, a proper count-up on the
 * player's own payout with a coin burst + gold glow for a real win, and a
 * calmer "this round" readout otherwise. Everything is one motion tree with
 * staggerChildren so it plays as a single smooth beat instead of several
 * independently-delayed pieces landing out of sync. */
function WinReveal({
  results,
  myPayout,
  iBet,
  nextRoundIn,
  getNumberColor,
}: {
  results: any;
  myPayout: number | undefined;
  iBet: boolean;
  nextRoundIn: number | null;
  getNumberColor: (n: number) => string;
}) {
  const didWin = iBet && !!myPayout && myPayout > 0;
  const isBigWin = didWin && (myPayout as number) >= 5000;
  const amount = useCountUp(didWin ? (myPayout as number) : 0, didWin, isBigWin ? 1.4 : 0.9);

  const coinBurst = useMemo(
    () =>
      didWin
        ? Array.from({ length: isBigWin ? 18 : 10 }, (_, i) => ({
            id: i,
            angle: (360 / (isBigWin ? 18 : 10)) * i + (Math.random() * 20 - 10),
            distance: 70 + Math.random() * 50,
            delay: Math.random() * 0.15,
          }))
        : [],
    [didWin, isBigWin]
  );

  return (
    <motion.div
      initial="hidden"
      animate="show"
      exit={{ opacity: 0, y: -10, transition: { duration: 0.2 } }}
      variants={{ hidden: {}, show: { transition: { staggerChildren: 0.08 } } }}
      className="relative text-center py-6 space-y-4 overflow-hidden"
    >
      {/* Ambient win glow behind everything */}
      {didWin && (
        <motion.div
          className="absolute inset-0 pointer-events-none"
          initial={{ opacity: 0 }}
          animate={{ opacity: [0, 0.9, 0.5] }}
          transition={{ duration: 1.2, ease: "easeOut" }}
          style={{ background: "radial-gradient(circle at 50% 35%, rgba(212,175,55,0.35) 0%, transparent 65%)" }}
        />
      )}

      <motion.div
        variants={{ hidden: { scale: 0, opacity: 0 }, show: { scale: 1, opacity: 1 } }}
        transition={{ type: "spring", stiffness: 220, damping: 20 }}
        className="relative"
      >
        {/* Coin burst */}
        {coinBurst.map((c) => {
          const rad = (c.angle * Math.PI) / 180;
          return (
            <motion.span
              key={c.id}
              className="absolute left-1/2 top-1/2 text-lg pointer-events-none"
              initial={{ x: 0, y: 0, opacity: 1, scale: 0.6 }}
              animate={{
                x: Math.cos(rad) * c.distance,
                y: Math.sin(rad) * c.distance - 20,
                opacity: 0,
                scale: 1,
                rotate: 180,
              }}
              transition={{ duration: 1.1, delay: c.delay, ease: "easeOut" }}
            >
              🪙
            </motion.span>
          );
        })}

        <div
          className={cn(
            "w-24 h-24 rounded-full flex items-center justify-center text-4xl font-extrabold mx-auto mb-3 shadow-2xl border-[3px] relative z-10",
            getNumberColor(results.winningNumber),
            didWin ? "ring-4 ring-vault-gold/70 ring-offset-2 ring-offset-black/40" : "ring-1 ring-white/10"
          )}
          style={{ textShadow: "0 2px 4px rgba(0,0,0,0.6)" }}
        >
          {results.winningNumber}
        </div>

        <motion.p
          variants={{ hidden: { opacity: 0, y: 6 }, show: { opacity: 1, y: 0 } }}
          className="text-3xl font-extrabold tracking-wide text-gold-gradient drop-shadow-[0_2px_6px_rgba(212,175,55,0.3)]"
        >
          {results.winningNumber === 0 ? "GREEN ZERO" : results.isRed ? "RED WINS" : "BLACK WINS"}
        </motion.p>
      </motion.div>

      {didWin ? (
        <motion.div
          variants={{ hidden: { opacity: 0, y: 12, scale: 0.9 }, show: { opacity: 1, y: 0, scale: 1 } }}
          transition={{ type: "spring", stiffness: 260, damping: 22 }}
          className={cn(
            "relative max-w-xs mx-auto rounded-2xl p-[2px] overflow-hidden",
            isBigWin ? "neon-glow" : "neon-glow-emerald"
          )}
          style={{
            background: isBigWin
              ? "linear-gradient(135deg, #fff3c4 0%, #d4af37 30%, #8a6d1a 50%, #d4af37 70%, #fff3c4 100%)"
              : "linear-gradient(135deg, #d4af37 0%, #b8860b 50%, #d4af37 100%)",
          }}
        >
          {/* Lacquered interior — near-black with a wine undertone, so gold
              type and borders read at full contrast instead of sitting on
              a washed-out translucent panel. */}
          <div
            className="relative rounded-[14px] px-5 py-5 overflow-hidden"
            style={{ background: "radial-gradient(140% 100% at 50% -10%, #241a08 0%, #120c05 45%, #08050f 100%)" }}
          >
            {/* one-shot shimmer sweep across the card face */}
            <motion.div
              className="absolute inset-0 pointer-events-none"
              initial={{ x: "-120%" }}
              animate={{ x: "120%" }}
              transition={{ duration: 1.1, delay: 0.2, ease: "easeInOut" }}
              style={{
                background: "linear-gradient(100deg, transparent 30%, rgba(255,255,255,0.18) 50%, transparent 70%)",
                width: "60%",
              }}
            />

            <div className="relative flex items-center justify-center gap-1.5 text-vault-gold text-[11px] font-bold uppercase tracking-[0.25em] mb-1.5">
              <Sparkles className="w-3.5 h-3.5" /> You Won <Sparkles className="w-3.5 h-3.5" />
            </div>
            <motion.p
              animate={isBigWin ? { scale: [1, 1.07, 1] } : undefined}
              transition={{ duration: 0.6, repeat: isBigWin ? 2 : 0 }}
              className="relative text-5xl font-extrabold text-gold-gradient font-mono tabular-nums tracking-tight drop-shadow-[0_2px_8px_rgba(212,175,55,0.35)]"
            >
              +{formatChips(amount)}
            </motion.p>
            {isBigWin && (
              <p className="relative mt-1.5 text-[10px] font-bold uppercase tracking-[0.3em] text-vault-gold-light/80">
                Big Win
              </p>
            )}
          </div>
        </motion.div>
      ) : (
        iBet && (
          <motion.p
            variants={{ hidden: { opacity: 0 }, show: { opacity: 1 } }}
            className="text-white/40 text-sm"
          >
            No win this round — good luck next spin
          </motion.p>
        )
      )}

      <motion.p variants={{ hidden: { opacity: 0 }, show: { opacity: 1 } }} className="text-white/30 text-xs">
        {nextRoundIn && nextRoundIn > 0 ? `Next round in ${nextRoundIn}…` : "Dealing next round…"}
      </motion.p>

      {results.payouts && Object.keys(results.payouts).length > 0 && (
        <motion.div
          variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0 } }}
          className="glass rounded-xl p-4 max-w-sm mx-auto"
        >
          <h4 className="text-white/40 text-xs uppercase tracking-wider mb-2 flex items-center gap-1">
            <Trophy className="w-3 h-3" /> Payouts
          </h4>
          {Object.entries(results.payouts).map(([playerId, amt]: [string, any]) => (
            <div key={playerId} className="flex justify-between items-center py-1">
              <span className="text-white/60 text-sm">Player</span>
              <span className="text-vault-emerald font-mono font-bold">+{formatChips(amt)}</span>
            </div>
          ))}
        </motion.div>
      )}
    </motion.div>
  );
}

/** One clickable/droppable spot on the felt — a number, a column (2:1), a
 * dozen, or an outside bet. Shared so every spot gets the same selection
 * ring and chip-count badge behavior without repeating markup. */
function BetButton({
  children,
  className,
  style,
  onClick,
  selected,
  badge,
}: {
  children: ReactNode;
  className?: string;
  style?: CSSProperties;
  onClick: () => void;
  selected?: boolean;
  badge?: number;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={style}
      className={cn(
        "relative flex items-center justify-center rounded-[4px] border text-[10px] sm:text-xs font-bold transition-all min-h-[28px] active:scale-95",
        selected ? "ring-2 ring-vault-gold z-10 shadow-lg scale-105" : "hover:brightness-125",
        className
      )}
    >
      {children}
      {!!badge && (
        <span className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-vault-gold rounded-full text-[8px] text-vault-black font-bold flex items-center justify-center border border-vault-black/40">
          {badge}
        </span>
      )}
    </button>
  );
}
