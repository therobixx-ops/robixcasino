"use client";

// Thin re-export: the actual socket connection now lives in a single
// shared SocketProvider (see contexts/SocketContext.tsx) so that room
// and game state survive client-side navigation between pages instead
// of resetting every time a component calling useSocket() mounts.
export { useSocketContext as useSocket } from "../contexts/SocketContext";
export type { SocketContextValue } from "../contexts/SocketContext";
