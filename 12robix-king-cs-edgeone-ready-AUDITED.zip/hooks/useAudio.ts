"use client";

import { useRef, useCallback, useEffect } from "react";

// Web Audio API-based sound engine
// No external files needed — synthesizes sounds in-browser

export function useAudio() {
  const ctxRef = useRef<AudioContext | null>(null);
  const masterGainRef = useRef<GainNode | null>(null);
  const enabledRef = useRef(true);

  const getCtx = useCallback(() => {
    if (!ctxRef.current) {
      ctxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      masterGainRef.current = ctxRef.current.createGain();
      masterGainRef.current.gain.value = 0.3;
      masterGainRef.current.connect(ctxRef.current.destination);
    }
    return ctxRef.current;
  }, []);

  const setEnabled = useCallback((enabled: boolean) => {
    enabledRef.current = enabled;
    if (masterGainRef.current) {
      masterGainRef.current.gain.setTargetAtTime(enabled ? 0.3 : 0, getCtx().currentTime, 0.1);
    }
  }, [getCtx]);

  const playTone = useCallback((freq: number, duration: number, type: OscillatorType = "sine") => {
    if (!enabledRef.current) return;
    const ctx = getCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, ctx.currentTime);

    gain.gain.setValueAtTime(0.3, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + duration);

    osc.connect(gain);
    gain.connect(masterGainRef.current!);

    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + duration);
  }, [getCtx]);

  const playChip = useCallback(() => {
    // High-pitched glass-like chip sound
    playTone(1200, 0.08, "sine");
    setTimeout(() => playTone(1800, 0.06, "sine"), 40);
  }, [playTone]);

  const playWin = useCallback(() => {
    // Celebration arpeggio
    const notes = [523, 659, 784, 1047];
    notes.forEach((freq, i) => {
      setTimeout(() => playTone(freq, 0.3, "sine"), i * 80);
    });
  }, [playTone]);

  const playLose = useCallback(() => {
    // Sad descending tone
    playTone(400, 0.3, "sawtooth");
    setTimeout(() => playTone(300, 0.4, "sawtooth"), 150);
  }, [playTone]);

  const playSpin = useCallback(() => {
    // Roulette wheel spin — white noise sweep
    if (!enabledRef.current) return;
    const ctx = getCtx();
    const bufferSize = ctx.sampleRate * 4; // 4 seconds
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);

    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * (1 - i / bufferSize); // Decaying noise
    }

    const noise = ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.setValueAtTime(800, ctx.currentTime);
    filter.frequency.exponentialRampToValueAtTime(100, ctx.currentTime + 4);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.2, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 4);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(masterGainRef.current!);

    noise.start(ctx.currentTime);
    noise.stop(ctx.currentTime + 4);
  }, [getCtx]);

  const playClick = useCallback(() => {
    playTone(800, 0.05, "sine");
  }, [playTone]);

  const playVaultLock = useCallback(() => {
    // Heavy mechanical lock sound
    playTone(200, 0.2, "square");
    setTimeout(() => playTone(150, 0.3, "square"), 100);
  }, [playTone]);

  const playPrank = useCallback((type: string) => {
    switch (type) {
      case "confetti":
        playWin();
        break;
      case "explosion":
        playTone(100, 0.5, "sawtooth");
        break;
      case "tomato":
        playTone(600, 0.1, "sine");
        setTimeout(() => playTone(400, 0.15, "sine"), 80);
        break;
      default:
        playClick();
    }
  }, [playTone, playWin]);

  // Resume context on first interaction (browser policy)
  useEffect(() => {
    const resume = () => {
      if (ctxRef.current?.state === "suspended") {
        ctxRef.current.resume();
      }
    };
    window.addEventListener("click", resume, { once: true });
    return () => window.removeEventListener("click", resume);
  }, []);

  return {
    setEnabled,
    playChip,
    playWin,
    playLose,
    playSpin,
    playClick,
    playVaultLock,
    playPrank,
  };
}
