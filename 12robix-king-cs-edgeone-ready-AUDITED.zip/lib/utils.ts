import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function generateRoomCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 6; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
}

export function formatChips(amount: number): string {
  return `₹${amount.toLocaleString("en-IN")}`;
}

export function getRandomAvatar(): string {
  const avatars = ["🦁", "🦊", "🐼", "🐯", "🦅", "🐺", "🦉", "🐉", "🦋", "🦄", "🐍", "🦎"];
  return avatars[Math.floor(Math.random() * avatars.length)];
}

export function getRandomTitle(): string {
  const titles = ["Rookie", "High Roller", "Vault Cracker", "Lucky Charm", "Night Owl", "Golden Touch", "Shadow", "VIP"];
  return titles[Math.floor(Math.random() * titles.length)];
}

export function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function shuffle<T>(array: T[]): T[] {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}
