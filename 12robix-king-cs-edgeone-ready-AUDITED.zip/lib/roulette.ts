// European roulette wheel layout — pocket order and colors.
// This MUST stay identical between the server (which uses the index to
// pick a winner) and any client-side wheel visualization, or the ball
// could visually land on a different number than the one that actually paid out.

export const ROULETTE_NUMBERS = [
  0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24,
  16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26,
] as const;

export const RED_NUMBERS = [
  1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36,
] as const;

export type PocketColor = "green" | "red" | "black";

export function pocketColor(n: number): PocketColor {
  if (n === 0) return "green";
  return (RED_NUMBERS as readonly number[]).includes(n) ? "red" : "black";
}

/** Degrees per pocket — used to place numbers around the wheel and to
 * translate a winning number into a resting rotation angle. */
export const DEGREES_PER_POCKET = 360 / ROULETTE_NUMBERS.length;

// --- Felt table layout -----------------------------------------------------
// The BETTING GRID is arranged in straight ascending order (the classic
// three-row table), which is completely different from ROULETTE_NUMBERS
// above (that's wheel/pocket order, only used for the spinning wheel).
// Mixing the two up is what makes a roulette table look "wrong" — numbers
// should read 1,2,3...36 in columns, not in wheel order.

/** Three rows, top to bottom, 12 numbers each — e.g. TABLE_ROWS[0] is the
 * top row (3, 6, 9 ... 36), TABLE_ROWS[2] is the bottom row (1, 4, 7 ... 34). */
export const TABLE_ROWS: number[][] = [
  Array.from({ length: 12 }, (_, i) => (i + 1) * 3),
  Array.from({ length: 12 }, (_, i) => (i + 1) * 3 - 1),
  Array.from({ length: 12 }, (_, i) => (i + 1) * 3 - 2),
];

/** Which "2 to 1" column bet (1, 2, or 3) a number belongs to. Column 3 is
 * the top row (3,6,...36), column 1 is the bottom row (1,4,...34). */
export function tableColumn(n: number): 1 | 2 | 3 {
  const mod = n % 3;
  return (mod === 0 ? 3 : mod) as 1 | 2 | 3;
}

/** Which dozen (1st/2nd/3rd 12) a number belongs to. */
export function dozenOf(n: number): 1 | 2 | 3 {
  return Math.ceil(n / 12) as 1 | 2 | 3;
}
