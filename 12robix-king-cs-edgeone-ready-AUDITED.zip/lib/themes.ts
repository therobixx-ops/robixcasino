export interface Theme {
  id: string;
  name: string;
  bg: string;
  accent: string;
  secondary: string;
  glow: string;
  description: string;
}

export const THEMES: Theme[] = [
  {
    id: "midnight",
    name: "Midnight Gold",
    bg: "#0a0a0a",
    accent: "#d4af37",
    secondary: "#10b981",
    glow: "rgba(212,175,55,0.3)",
    description: "Classic luxury",
  },
  {
    id: "neon",
    name: "Cyber Neon",
    bg: "#050510",
    accent: "#ff00ff",
    secondary: "#00ffff",
    glow: "rgba(255,0,255,0.3)",
    description: "Tokyo nights",
  },
  {
    id: "emerald",
    name: "Emerald City",
    bg: "#001a0f",
    accent: "#00ff88",
    secondary: "#ffd700",
    glow: "rgba(0,255,136,0.3)",
    description: "Green velvet",
  },
  {
    id: "ruby",
    name: "Ruby Lounge",
    bg: "#1a0005",
    accent: "#ff1744",
    secondary: "#ff9100",
    glow: "rgba(255,23,68,0.3)",
    description: "Red carpet",
  },
  {
    id: "ocean",
    name: "Deep Ocean",
    bg: "#000a1a",
    accent: "#00b0ff",
    secondary: "#7c4dff",
    glow: "rgba(0,176,255,0.3)",
    description: "Underwater luxury",
  },
  {
    id: "disco",
    name: "Disco Fever",
    bg: "#0a0a0a",
    accent: "#ffeb3b",
    secondary: "#ff4081",
    glow: "rgba(255,235,59,0.3)",
    description: "Saturday night",
  },
];

export function getThemeCSS(theme: Theme): string {
  return `
    :root {
      --vault-black: ${theme.bg};
      --vault-gold: ${theme.accent};
      --vault-emerald: ${theme.secondary};
    }
  `;
}
