// Solo Mode engine.
//
// Runs entirely in the browser tab — no Socket.IO / server required. This lets
// the app be genuinely playable the moment it's deployed as a static/edge
// site (e.g. EdgeOne Pages), even if the separate realtime server
// (server/index.ts) hasn't been deployed anywhere yet.
//
// It reuses the exact same game-logic classes the real server uses
// (RouletteGame / VaultHeistGame) since those classes have no server-only
// dependencies (no express/socket.io imports) — just pure TypeScript that
// works fine in a browser. Bots are simple, randomized "players" that place
// bets / choose vaults on a short random delay so a lone player always has
// a full table.

import { RouletteGame } from "../server/games/roulette";
import { VaultHeistGame } from "../server/games/vaultHeist";
import { CoinFlipGame } from "../server/games/coinFlip";
import { DiceGame } from "../server/games/dice";
import type { Player, Room, GameType, RouletteState, VaultHeistState, CoinFlipState, DiceState, Bet } from "../types";

const BOT_NAMES = ["Nova", "Ace", "Raven", "Jax", "Luna", "Kai", "Zara", "Rex", "Vex", "Milo", "Echo", "Sable"];
const BOT_AVATARS = ["🦁", "🦊", "🐯", "🦅", "🐺", "🦉", "🐉", "🦋", "🦄", "🐍", "🦎", "🦖"];

export function makeBotName(index: number): string {
  return `${BOT_NAMES[index % BOT_NAMES.length]} (Bot)`;
}

export function makePlayer(overrides: Partial<Player> & { id: string; name: string }): Player {
  return {
    avatar: "🎭",
    chips: 10000,
    isReady: true,
    isHost: false,
    ping: 0,
    winStreak: 0,
    ...overrides,
  };
}

export function buildSoloRoom(data: { name: string; avatar: string; roomName?: string; totalPlayers: number }): Room {
  const totalPlayers = Math.max(1, Math.min(12, data.totalPlayers));
  const you = makePlayer({
    id: "you",
    name: data.name || "You",
    avatar: data.avatar || "🎭",
    chips: 25000,
    isHost: true,
    isReady: false,
  });

  const bots: Player[] = [];
  for (let i = 0; i < totalPlayers - 1; i++) {
    bots.push(
      makePlayer({
        id: `bot-${i}`,
        name: makeBotName(i),
        avatar: BOT_AVATARS[i % BOT_AVATARS.length],
        chips: 10000 + Math.floor(Math.random() * 10000),
        isReady: true,
      })
    );
  }

  const code = "SOLO" + Math.random().toString(36).slice(2, 6).toUpperCase();

  return {
    id: `solo-${code}`,
    code,
    name: data.roomName || `${data.name || "Your"}'s Solo Table`,
    hostId: "you",
    players: [you, ...bots],
    maxPlayers: totalPlayers,
    isLocked: true,
    currentGame: null,
    gameState: null,
    chat: [],
    settings: { maxPlayers: totalPlayers, roundTimer: 30, enableEffects: true, theme: "dark" },
    createdAt: Date.now(),
  };
}

const ROULETTE_BET_TYPES: Array<{ type: string; values: (string | number)[] }> = [
  { type: "color", values: ["red", "black"] },
  { type: "evenodd", values: ["even", "odd"] },
  { type: "halves", values: ["low", "high"] },
  { type: "number", values: Array.from({ length: 37 }, (_, i) => i) },
];

function randomBet(chips: number): Omit<Bet, "playerId"> {
  const pick = ROULETTE_BET_TYPES[Math.floor(Math.random() * ROULETTE_BET_TYPES.length)];
  const value = pick.values[Math.floor(Math.random() * pick.values.length)];
  const amount = Math.min(chips, [50, 100, 200, 500][Math.floor(Math.random() * 4)]);
  return { type: pick.type, value, amount };
}

/** Runs a solo Neon Roulette table — bots bet automatically, every round, until stop() is called. */
export function runSoloRoulette(
  room: Room,
  onUpdate: (state: RouletteState) => void
): { game: RouletteGame; cancel: () => void } {
  const game = new RouletteGame(room.id, room.players);
  let timers: ReturnType<typeof setTimeout>[] = [];

  const scheduleBotBets = () => {
    timers.forEach(clearTimeout);
    timers = [];
    for (const p of room.players) {
      if (p.id === "you") continue;
      const delayMs = 1500 + Math.random() * 12000;
      timers.push(
        setTimeout(() => {
          // A bot places 1-2 small bets.
          const bets = 1 + Math.floor(Math.random() * 2);
          for (let i = 0; i < bets; i++) game.placeBet(p.id, randomBet(p.chips));
        }, delayMs)
      );
    }
  };

  game.start(onUpdate, scheduleBotBets);

  return {
    game,
    cancel: () => {
      game.stop();
      timers.forEach(clearTimeout);
    },
  };
}

/** Runs a solo Vault Heist table — bots pick vaults automatically, every round, until stop() is called. */
export function runSoloVaultHeist(
  room: Room,
  onUpdate: (state: VaultHeistState) => void
): { game: VaultHeistGame; cancel: () => void } {
  const game = new VaultHeistGame(room.id, room.players);
  let timers: ReturnType<typeof setTimeout>[] = [];

  const scheduleBotChoices = () => {
    timers.forEach(clearTimeout);
    timers = [];
    const vaults = game.getState().vaults;
    for (const p of room.players) {
      if (p.id === "you") continue;
      const delayMs = 800 + Math.random() * 8000;
      timers.push(
        setTimeout(() => {
          const vault = vaults[Math.floor(Math.random() * vaults.length)];
          game.makeChoice(p.id, vault.id);
        }, delayMs)
      );
    }
  };

  game.start(onUpdate, scheduleBotChoices);

  return {
    game,
    cancel: () => {
      game.stop();
      timers.forEach(clearTimeout);
    },
  };
}

function randomCoinFlipBet(chips: number): Omit<Bet, "playerId"> {
  const value = Math.random() > 0.5 ? "heads" : "tails";
  const amount = Math.min(chips, [50, 100, 200, 500][Math.floor(Math.random() * 4)]);
  return { type: "coinflip", value, amount };
}

/** Runs a solo Coin Flip table — bots call heads/tails automatically, every round, until stop() is called. */
export function runSoloCoinFlip(
  room: Room,
  onUpdate: (state: CoinFlipState) => void
): { game: CoinFlipGame; cancel: () => void } {
  const game = new CoinFlipGame(room.id, room.players);
  let timers: ReturnType<typeof setTimeout>[] = [];

  const scheduleBotBets = () => {
    timers.forEach(clearTimeout);
    timers = [];
    for (const p of room.players) {
      if (p.id === "you") continue;
      const delayMs = 500 + Math.random() * 6000;
      timers.push(setTimeout(() => game.placeBet(p.id, randomCoinFlipBet(p.chips)), delayMs));
    }
  };

  game.start(onUpdate, scheduleBotBets);

  return {
    game,
    cancel: () => {
      game.stop();
      timers.forEach(clearTimeout);
    },
  };
}

function randomDiceBet(chips: number): Omit<Bet, "playerId"> {
  const amount = Math.min(chips, [50, 100, 200, 500][Math.floor(Math.random() * 4)]);
  if (Math.random() > 0.4) {
    return { type: "dice-range", value: Math.random() > 0.5 ? "low" : "high", amount };
  }
  return { type: "dice-exact", value: 2 + Math.floor(Math.random() * 11), amount };
}

/** Runs a solo Dice table — bots bet automatically, every round, until stop() is called. */
export function runSoloDice(
  room: Room,
  onUpdate: (state: DiceState) => void
): { game: DiceGame; cancel: () => void } {
  const game = new DiceGame(room.id, room.players);
  let timers: ReturnType<typeof setTimeout>[] = [];

  const scheduleBotBets = () => {
    timers.forEach(clearTimeout);
    timers = [];
    for (const p of room.players) {
      if (p.id === "you") continue;
      const delayMs = 500 + Math.random() * 8000;
      const bets = 1 + Math.floor(Math.random() * 2);
      for (let i = 0; i < bets; i++) {
        timers.push(setTimeout(() => game.placeBet(p.id, randomDiceBet(p.chips)), delayMs + i * 300));
      }
    }
  };

  game.start(onUpdate, scheduleBotBets);

  return {
    game,
    cancel: () => {
      game.stop();
      timers.forEach(clearTimeout);
    },
  };
}

export function pickRandomGameType(preferred?: GameType): GameType {
  const ALL: GameType[] = ["neon-roulette", "vault-heist", "coin-flip", "dice"];
  if (preferred && ALL.includes(preferred)) return preferred;
  return ALL[Math.floor(Math.random() * ALL.length)];
}
