import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./features/**/*.{js,ts,jsx,tsx,mdx}",
    "./games/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        vault: {
          black: "var(--vault-black, #08070a)",
          graphite: "#17151a",
          charcoal: "#1f1c22",
          gold: "var(--vault-gold, #d4af37)",
          "gold-light": "#f6dc6b",
          "gold-dark": "#8a6d1a",
          "gold-deep": "#8a6417",
          emerald: "var(--vault-emerald, #10b981)",
          "emerald-dark": "#064e3b",
          "emerald-deep": "#063d2c",
          wine: "var(--vault-wine, #7a1f2b)",
          "wine-light": "#b23a4a",
          "wine-deep": "#3a0d14",
          glass: "rgba(255,255,255,0.05)",
          glassBorder: "rgba(255,255,255,0.1)",
        },
        ink: "var(--ink, #f2ece0)",
      },
      backgroundImage: {
        "gold-bevel": "linear-gradient(135deg, #fdf3c4 0%, #d4af37 22%, #9c7412 45%, #f6dc6b 68%, #8a6417 88%, #d4af37 100%)",
        "gold-sheen": "linear-gradient(120deg, #f6dc6b 0%, #d4af37 45%, #fdf3c4 55%, #d4af37 70%, #8a6417 100%)",
        "card-lacquer": "linear-gradient(160deg, #14110a 0%, #0c0a06 55%, #100c07 100%)",
        "wine-lacquer": "linear-gradient(155deg, #b23a4a 0%, #7a1f2b 45%, #3a0d14 100%)",
        "emerald-felt": "linear-gradient(155deg, #1fcf94 0%, #10b981 40%, #063d2c 100%)",
      },
      fontFamily: {
        display: ["var(--font-display)", "Georgia", "serif"],
        body: ["var(--font-body)", "system-ui", "-apple-system", "sans-serif"],
        mono: ["var(--font-mono)", "ui-monospace", "monospace"],
      },
      animation: {
        "spin-slow": "spin 8s linear infinite",
        "pulse-glow": "pulse-glow 2s ease-in-out infinite",
        "float": "float 3s ease-in-out infinite",
        "shimmer": "shimmer 2s linear infinite",
        "gradient-drift": "gradient-drift 6s ease-in-out infinite",
      },
      keyframes: {
        "pulse-glow": {
          "0%, 100%": { boxShadow: "0 0 20px rgba(212,175,55,0.3)" },
          "50%": { boxShadow: "0 0 40px rgba(212,175,55,0.6)" },
        },
        float: {
          "0%, 100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-10px)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
        "gradient-drift": {
          "0%, 100%": { backgroundPosition: "0% 50%" },
          "50%": { backgroundPosition: "100% 50%" },
        },
      },
    },
  },
  plugins: [],
};

export default config;
